# Split-Flap Display PCB v2 — Handoff Bundle (ChatGPT review form)

> **Entry point for external review** — flattened bundle of the v2 design brief.
>
> **Revision state**: post-#76 architecture pivot (2026-04-25) → post-#80 pass-1 review refactor (2026-04-25) → **post-#82 pass-2 review refactor (2026-04-25)**.
>
> This is the **8-file consolidated bundle** for ChatGPT upload. The full split (19 per-section files) lives in the repo at `PCB/v2/` — see https://github.com/lvschouwen/split-flap/tree/pcb-v2-rs485-48v/PCB/v2.

This bundle contains the complete design brief for the v2 redesign of the split-flap display electronics. It supersedes v1 entirely (v1 lives in `pcb_v1.zip` — frozen at tag `v-esp8266-final`).

## What changed in pass-2 (latest)

**One real "this won't work" finding** plus remaining `CHECK` row resolutions:

- **Master per-bus eFuse voltage-rating blocker.** The pre-pass-2 selection (`TPS259827YFFR` + `TPS25981QWRPVRQ1` fallback) is **electrically invalid on the 48 V bus** — both are 24 V/30 V abs-max class. Active candidate: `TPS26600PWPR` (LCSC `C544399`, HTSSOP-16-EP, 4.2-60 V industrial eFuse). Not drop-in: schematic + footprint + I_LIM + dV/dt rework required. The DSBGA manufacturability concern is now moot (HTSSOP-16-EP is standard).
- **MAX14830ETJ+** confirmed unsourceable on JLC (`MAX14830ETM+T C2653202` is package-mismatched, must not substitute). Now `MANUAL_FEEDER` with three open architectural options.
- **Verified** at JLC: `INA237 → C2864837` (master), `SM712 → C172881` (unit). Candidate substitutes (not drop-in): `LMR36015FSC3RNXRQ1 C1850344` (master U2 fixed-output VQFN-12), `TLV803SDBZR C132016` (master U_POR SOT-23-3), `SQJ148EP C727381` (verify-before-order).
- **Unsourceable / global-source / manual-feeder** explicitly tagged: master `J1` barrel, `J4-J7` RJ45, `L2-L5` CM choke, backplane `J_RJ45_*` and slot/inter-segment connectors, unit `J_BP` and `L1` inductor.
- **AS5600 datum gate** sharpened from "signoff" to **eleven explicit dimensional values** the mech freelancer must hand over before the unit PCB enters layout.
- **Backplane harness alternative**: pre-draw a DNP keyed-harness landing footprint in parallel with the rigid 2×3 inter-segment connector, or freeze backplane layout until mech review chooses.
- **DRC class tables** added to all three DECISIONS docs (48V / RS-485+USB / I²C+Logic / General).

`CHANGELOG_V1_TO_V2.md` §4 has been re-triaged: the eFuse voltage-rating blocker is now the top Critical item; MAX14830 sourcing is a new Critical pre-tape-out item; old DSBGA / K_ILIM concerns are superseded by the swap.

## System overview

The display is a wall-mountable split-flap sign built from physical "cases" of 16 modules each. Each module is a small mechanical assembly (stepper + flap drum + per-module electronics PCB). Multiple cases chain together to form a longer display.

**v2 is a three-PCB system:**

| Board | Quantity | Role |
|---|---|---|
| **Master** | 1 per system | ESP32-S3 controller. WiFi + USB-C service port. 4× RJ45 ports, each driving an RS-485 chain of cases. 48 V DC barrel input. |
| **Backplane** | 4 segments per case (16 slots) | Passive distribution: V48 + RS-485 to 16 unit-slots, with per-slot polyfuse. Two case-level RJ45s (chain in/out) on the outer segments. |
| **Unit** | 1 per split-flap module (16 per case) | STM32G030 + AS5600 closed-loop control + TPL7407L stepper drive. Slots into the backplane via a 2×3 box header. |

**Bus**: RS-485 half-duplex, 500 kbaud 8N1. Wire format: COBS+CRC16-BE per `firmware/lib/common/`. Address discovery: master-driven UID-based binary-tree search (no DIP switches, no wake pins).

**Power**: 48 V DC at the master, distributed over CAT6 patch cables to each case backplane (paralleled pairs). Per-bus eFuse on master (60 V-class candidate `TPS26600PWPR`), per-slot polyfuse on backplane.

**Max system size**: 4 RS-485 chains × 2 cases per chain × 16 units per case = **128 units total**.

## Bundle file map (this ZIP — 8 files)

| File | Contains |
|---|---|
| `README.md` | This file. System overview, bundle map, scope, pass-2 highlights. |
| `CONNECTOR_PINOUTS.md` | Single canonical cross-board pinout contract (master ↔ backplane ↔ unit). |
| `MASTER.md` | Master PCB design brief: DECISIONS (source of truth, with pass-2 BOM/sourcing-gates + LAYOUT_CONSTRAINT (DRC table, stackup, fiducials, panelization, U12 decision-gate) + REVIEW_STRONG_OPINION + REVIEW_SAFETY) + POWER_DESIGN + DIGITAL_DESIGN + MECHANICAL_DESIGN + BRINGUP. Pass-2 banners flag where the eFuse swap supersedes prior text. |
| `MASTER_BOM.csv` | JLC-native BOM, post-pass-2. |
| `BACKPLANE.md` | Backplane PCB design brief: DECISIONS (with segment-joint mechanical reliability + LAYOUT_CONSTRAINT (DNP harness alternative + DRC table + stackup) + REVIEW_STRONG_OPINION) + DESIGN + MECHANICAL + BRINGUP. |
| `BACKPLANE_BOM.csv` | JLC-native BOM, post-pass-2. |
| `UNIT.md` | Unit PCB design brief: DECISIONS (with AS5600 11-value hard-numbers gate + TPS54360 thermal plan + SWD pogo geometry + LAYOUT_CONSTRAINT (DRC table, stackup, panelization) + REVIEW_STRONG_OPINION) + POWER_DESIGN + DIGITAL_DESIGN + MECHANICAL_DESIGN + BRINGUP. |
| `UNIT_BOM.csv` | JLC-native BOM, post-pass-2. |

## Recommended reading order

1. `README.md` (this file).
2. `CHANGELOG_V1_TO_V2.md` §4.1 (Critical issues — start with the eFuse voltage blocker) and §5 (BOM status table).
3. `CONNECTOR_PINOUTS.md` — cross-board contracts.
4. `MASTER.md`, `BACKPLANE.md`, `UNIT.md` — first section of each is the locked DECISIONS source-of-truth.
5. `*_BOM.csv` — JLC-native, ready for upload (see §5 of changelog for the LCSC-status legend).

## Pre-fab gates (must clear before tape-out)

1. **60 V-class eFuse swap finalised at schematic capture** (master U3-U6 candidate `TPS26600PWPR C544399`). Pin layout, footprint, I_LIM network, and inrush network all change. Pass-2 surfaced this as the top blocker.
2. **MAX14830 sourcing decision** — manual-feeder ETJ+, swap to two dual-UART bridges, or reopen scope to a 2-bus master.
3. **AS5600 mech freelancer hand-off** — 11 explicit dimensional values per `UNIT.md`.
4. **Backplane segment-joint mechanical decision** — rigid keyed/latching connector OR keyed wire harness OR DNP-both-footprint approach.
5. **MAX14830 SPI-mode strap pin handling** — confirm against datasheet at schematic capture.

## Audit history

- **#76 (2026-04-25)**: 7 parallel agents reviewed the pre-pivot v2 bundle and flagged ~80 issues; major findings drove the architectural pivot to a backplane and the part-swaps to TPS54360 / STM32G030K6T6 LQFP-32 / SM712.
- **scottbez1 audit (2026-04-25)**: 3 parallel agents validated the architecture and adopted tactical wins.
- **#80 (2026-04-25, pass-1)**: BOM verification + open-issue reclassification + layout-readiness gates. Source of all `REVIEW_VERIFIED`, `REVIEW_BLOCKER`, `LAYOUT_CONSTRAINT`, `REVIEW_STRONG_OPINION`, `REVIEW_SAFETY`, `REVIEW_COST_WARNING` notes from pass-1.
- **#82 (2026-04-25, pass-2 — this revision)**: 60 V eFuse blocker, MAX14830 unsourceable, remaining `CHECK` rows resolved into explicit non-CHECK statuses, AS5600 hard-numbers gate, DRC tables, harness-alternative layout constraint. Source of all `REVIEW_PASS2_*` notes.

See `CHANGELOG_V1_TO_V2.md` (alongside this bundle, top-level) for the full v1→v2 review brief and open-issue triage.
