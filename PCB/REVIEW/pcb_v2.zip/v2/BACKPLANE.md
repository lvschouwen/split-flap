# Backplane PCB — Consolidated Design Brief

> Concatenated for the ChatGPT review bundle. Original split (per-section files) lives in the repo at `PCB/v2/` (`BACKPLANE_DECISIONS.md`, `BACKPLANE_DESIGN.md`, `BACKPLANE_MECHANICAL.md`, `BACKPLANE_BRINGUP.md`).

**Reading order below: Decisions (source of truth) → Design → Mechanical → Bring-up.**

---

# Section 1 — BACKPLANE_DECISIONS.md (source of truth)

# Backplane PCB v2 — locked design decisions

> **Single source of truth for the backplane PCB.** Design agents bind to this file ONLY.
>
> Created: 2026-04-25 (post-review backplane pivot per #76).
>
> Peer documents: `MASTER_DECISIONS.md` (master), `UNIT_DECISIONS.md` (unit). The backplane sits between master and units in the bus topology — anything in conflict between docs defers to `MASTER_DECISIONS.md` for system shape and `UNIT_DECISIONS.md` for the per-slot connector contract.

## System shape

- **One backplane per case**, hosting 16 unit-slots and 2 case-level RJ45s (chain in / chain out).
- **Backplane is split into 4 segments × 4 slots each**, each segment 320 mm × ~35 mm. A single 1280 mm continuous board exceeds JLC's standard fab limit (400 mm); 4 × 320 mm segments fit comfortably.
- **Inter-segment connection**: 6-pin board-to-board header pair (matching the per-slot connector pinout), carrying V48/V48/GND/GND/A/B between adjacent segments. 3 inter-segment joints per case.
- **Outer-segment ends host the case-level RJ45s** (segment-1 upstream end carries one RJ45; segment-4 downstream end carries the other).
- **2-layer PCB**, 1.6 mm FR-4, 1 oz / 1 oz copper, HASL finish.
- **No active silicon on the backplane.** Pure passive distribution: 16 connectors + 16 polyfuses + 2 RJ45s + 3 inter-segment connectors + caps + test points + (optional populated) terminator + ESD on the case-level RJ45s.

## Per-slot connector (mates with unit)

| Pin | Net | Notes |
|---|---|---|
| 1 | +48V | Paralleled with pin 3 for current capacity |
| 2 | RS-485 A | Differential pair with pin 4 |
| 3 | +48V | Paralleled with pin 1 |
| 4 | RS-485 B | Differential pair with pin 2 |
| 5 | GND | Paralleled with pin 6 |
| 6 | GND | Paralleled with pin 5 |

Connector type: **2×3 box header, 2.54 mm pitch, FEMALE (socket)** on the backplane (mates with the male pin header on the unit). Polarised/keyed shroud to prevent reverse insertion. Standard SMD or THT 2×3 part.

## Per-slot fault isolation

- **0.2 A resettable polyfuse on V48 inline to each slot.** Trips when a single unit's stepper coil shorts; rest of bus stays up. Auto-reset after fault clears. Adds ~€1.60 per backplane (16 slots × ~€0.10).
- **No per-slot data-line fuses or ESD** — the case-level RJ45 carries the externally-induced-fault risk; per-slot ESD already lives on each unit's SM712.

## Case-level RJ45 (chain in / chain out)

| Pin | T568B color | Net |
|---|---|---|
| 1 | white-orange | NC reserved |
| 2 | orange | NC reserved |
| 3 | white-green | RS-485 A (true twisted pair with pin 6) |
| 4 | blue | +48V (paralleled) |
| 5 | white-blue | +48V (paralleled) |
| 6 | green | RS-485 B |
| 7 | white-brown | GND (paralleled) |
| 8 | brown | GND (paralleled) |

Same pinout as master. Case-level RJ45s are **shielded THT** (matches master/RJ45 part choice — to be harmonised at BOM-finalize).

**Pin-1 indicator** silkscreen mark on each case-level RJ45 (consistent with master).

**Cable spec**: shielded CAT5e or CAT6 (S/FTP or F/UTP), straight-through, T568B. Max 32 m total per chain, max 3 m per hop.

## Termination & bias

- **Termination: 120 Ω footprint at the chain-end of the bus**, on segment-4 of the chain-end case. **PCBA stuffing variant**: populated only on the chain-end case backplane; DNP on all other case backplanes. Single PCB design, two BOM variants at JLC PCBA. Same pattern used for the per-board-role differentiation as scottbez1's PCBA flow.
- **No failsafe bias on the backplane.** Master is the sole bias point (1 kΩ each leg, master-side only).

## Cable shield bond

- **Backplane shield floats.** RJ45 shield can pads on backplane connect to nothing (DNP both R and C). Master is the sole shield-bond point system-wide (locked 2026-04-25 to avoid ground-loop hunting).

## Inter-segment connector

- **6-pin board-to-board, 2.54 mm pitch**, same pinout as per-slot connector (V48/V48/GND/GND/A/B) — same SKU as per-slot for inventory consolidation.
- **Mating direction**: female on segment N's downstream end mates with male on segment N+1's upstream end. Or both-female on segments + male jumper between (simpler stocking — pick at schematic capture).
- **Spacing rule**: inter-segment joint adds ~3 mm of tolerance — segment-end alignment is enforced by the case mechanical structure (bracket from mech freelancer).

## Test points (per segment)

- **4× 1 mm SMD test pads per segment**: V48, GND, RS-485 A, RS-485 B.
- Accessible from the back side (motor-side) of the case for in-situ probe access during bring-up.

## Mechanical decisions

- **Segment dimensions: 320 mm × 35 mm** (each).
- **Layer count: 2** (1.6 mm FR-4, 1 oz / 1 oz, HASL).
- **Slot pitch: 80 mm** (matches case unit-pitch from MiddleFrame remix).
- **Mounting**: 2–4× M3 isolated through-holes per segment at defined positions (e.g. 10 mm from each end + mid-points). **Mech freelancer designs the 3D-printed brackets** that screw the segment to the MiddleFrame.

## Prototype / production target

- **Prototype run: 4 segments per case × 1 case = 4 segments**, JLC PCBA assembly. Allows full-case bring-up.
- **Production**: 4 segments × N cases per system.
- **Schematic capture path**: KiCad preferred to enable KiBot + kikit pipeline.

## Design artifacts (in this directory)

- `BACKPLANE_DECISIONS.md` (this file) — source of truth.
- `BACKPLANE_DESIGN.md` — schematic-level detail.
- `BACKPLANE_MECHANICAL.md` — placement brief + mounting + segment geometry.
- `BACKPLANE_BOM.csv` — JLC-native BOM (per-segment + case-level totals).
- `BACKPLANE_BRINGUP.md` — bring-up sequence.

## Open issues (non-blocking)

- **B1** — Inter-segment connector mating-direction (M-F vs F + jumper). Decide at schematic capture.
- **B2** — Mounting hole exact positions: pending mech freelancer's bracket design.
- **B3** — Whether to put the terminator on segment-4 or on a separate small "chain-end cap" PCB. Default: segment-4 PCBA stuffing variant. Revisit if cost-of-stuffing-variant exceeds ~€5/segment.
- **B4** — Optional case-level INA219 current monitor on each backplane segment for telemetry. Per scottbez1 audit, his Chainlink Base does this. Costs ~€0.80 + 1 GPIO on master per case. Defer to v2.1 if telemetry granularity becomes an operational need.

---

# Section 2 — BACKPLANE_DESIGN.md

# Backplane PCB v2 — Schematic-level design

> Complement to `BACKPLANE_DECISIONS.md`. Schematic-level detail for the layout designer. Created 2026-04-25 (#76 backplane pivot).
>
> Backplane is **passive** (no active silicon). This doc is short.

## Per-segment block diagram (one of 4 identical)

```
Inter-segment IN connector (6-pin 2.54mm): V48|A|V48|B|GND|GND
  │
  ├──── V48 trace (TOP layer, 2 mm wide, 1 oz Cu)
  │       │
  │       ├── 0.2A polyfuse ── slot-1 V48 pin (and pin 3 paralleled)
  │       ├── 0.2A polyfuse ── slot-2 V48 pin
  │       ├── 0.2A polyfuse ── slot-3 V48 pin
  │       ├── 0.2A polyfuse ── slot-4 V48 pin
  │       │
  │       └── pass-through to inter-segment OUT connector
  │
  ├──── GND trace (BOT layer, 2 mm wide, 1 oz Cu) — paralleled GND pins
  │
  └──── A/B differential pair (TOP layer, 120Ω diff impedance over BOT GND)
        │     ↓ tap to each slot's pins 2, 4
        ↓
        Inter-segment OUT connector (6-pin)

Per slot (×4 per segment):
  Slot N socket (2×3 box header female, 2.54mm)
    pin 1 ── V48 (after polyfuse)
    pin 2 ── A (bus tap)
    pin 3 ── V48 (paralleled with pin 1, same polyfuse output)
    pin 4 ── B (bus tap)
    pin 5 ── GND
    pin 6 ── GND

Test points (one set per segment, edge-accessible):
  TP_V48, TP_GND, TP_A, TP_B (1 mm SMD pads)

Outer-segment-only:
  Case-level RJ45 (shielded THT) on the outer end of segment-1 (chain-IN)
  and segment-4 (chain-OUT). Pinout per BACKPLANE_DECISIONS §"Case-level
  RJ45". RJ45 shield pads DNP (no shield bond on backplane).

End-of-chain-segment-only (segment-4 of chain-end case, PCBA stuffing variant):
  R_TERM 120Ω across A/B near the case-level RJ45 (chain electrical end).
```

## Component selection

| Ref | Function | Part | Footprint | Notes |
|---|---|---|---|---|
| F1..F4 | Per-slot V48 polyfuse 0.2A hold / 0.4A trip | nanoSMDC020F | 1812 SMD | One per unit-slot; auto-reset; trip on stuck stepper coil |
| J_SLOT1..4 | Unit-slot socket | 2×3 2.54 mm box header female | 2×3 SMD or THT | Polarised shroud preferred |
| J_SEG_IN, J_SEG_OUT | Inter-segment connector | 2×3 2.54 mm pin header | Same as J_SLOT (mirrored polarity) | OR all-female + jumper plug — TBD at capture (B1) |
| J_RJ45_IN | Case-level RJ45 chain IN | Shielded THT 8P8C no-mag | THT shielded | Outer-segment-1 only |
| J_RJ45_OUT | Case-level RJ45 chain OUT | Shielded THT 8P8C no-mag | THT shielded | Outer-segment-4 only |
| R_TERM | RS-485 termination 120Ω 1% | 0805 | 0805 | DNP except chain-end case backplane (PCBA stuffing variant) |
| C_BULK | V48 bulk smoothing 22µF/100V X7R | 1210 | 1210 | One per segment near inter-segment IN connector |
| C_BYP | V48 HF decap 100nF/100V X7R | 0603 | 0603 | One per slot near polyfuse output |
| TP_V48, TP_GND, TP_A, TP_B | Test pads 1 mm SMD | — | 1 mm SMD pad | Per segment, edge-accessible |

## Differential routing

- A/B pair routed as **120 Ω differential impedance over a solid GND reference plane**.
- Trace width / gap calculated against JLC's 2-layer 1.6 mm stack (typical: ~0.35 mm trace / 0.4 mm gap; layout designer confirms).
- **Continuous solid GND on bottom layer** under the A/B pair across the whole 320 mm segment.
- Each slot is a stub tap; stub length from main A/B trace to socket pin ≤ 5 mm.
- Inter-segment connector imposes a controlled discontinuity — keep its pad geometry tight to maintain impedance.

## V48 power distribution

- 2 mm trace width on TOP layer (1 oz Cu) for V48 main bus across segment.
- Per IPC-2221: 1 oz × 2 mm trace at 10 °C rise carries ~3 A — comfortably above the segment's ~0.4 A worst-case (4 slots × ~100 mA).
- GND return: BOT-layer plane — solid pour, also 2 mm minimum width where it bridges through inter-segment connectors.

## Open issues

- **B1** — Inter-segment connector mating direction (M-F vs F+jumper). Capture-time decision.
- **B5** — Slot connector vendor (generic 2×3 box header from JLC Basic library vs Wurth/Molex named parts). Cost difference ~€0.05/slot. Defer to BOM-finalize.
- **B6** — Whether to add LEDs per slot for "slot powered" / "slot data" indication. Saves debug time at scale; adds ~€0.30/slot. Defer to v2.1.

---

# Section 3 — BACKPLANE_MECHANICAL.md

# Backplane PCB v2 — Mechanical brief

> Complement to `BACKPLANE_DECISIONS.md`. Placement brief and segment geometry for the layout designer. Created 2026-04-25.

## Segment dimensions

- **320 mm × 35 mm × 1.6 mm FR-4**, 2-layer, 1 oz / 1 oz copper, HASL finish.
- 4 identical segments per case (with one variant difference: outer segments host the case-level RJ45, mid segments do not).

## Slot pitch

- **80 mm slot center-to-center**, matching the case unit-pitch derived from the user's MiddleFrame remix.
- Per segment: 4 slots × 80 mm = 320 mm — the full segment length.
- First slot center at x = 40 mm from segment edge; last slot at x = 280 mm.
- Inter-segment joint adds zero pitch — slots line up across the case as 16 × 80 mm = 1280 mm centerline-to-centerline.

## Floorplan (per segment, top view)

```
           320 mm
   +------------------------------+
   |  J_SEG_IN [V48|A|V48|B|G|G]  |  ← inter-segment in (mid+outer segments)
   |                              |
   |  C_BULK                      |
   |                              |
   |  [F1] [F2] [F3] [F4]         |  ← per-slot polyfuses
   |                              |
   |  [J_SLOT1] [J_SLOT2] ...     |  ← 4 unit slots at 80 mm pitch
   |                              |
   |  TP_V48 TP_GND TP_A TP_B     |  ← test pads (edge-accessible)
   |                              |
   |  J_SEG_OUT [V48|A|V48|B|G|G] |  ← inter-segment out (mid+outer)
   +------------------------------+

For OUTER SEGMENTS, replace one J_SEG connector with J_RJ45 (case-level):
   - segment-1: J_SEG_IN replaced by J_RJ45_IN (chain IN to next-case-upstream)
   - segment-4: J_SEG_OUT replaced by J_RJ45_OUT (chain OUT to next-case-downstream)
   On segment-4 of the CHAIN-END case backplane only:
   - R_TERM 120Ω stuffed (PCBA variant) across A/B near J_RJ45_OUT
```

35 mm depth gives sufficient clearance for:
- The 2×3 box header socket (~10 mm protrusion above board)
- The inter-segment / RJ45 connector on opposing edge
- Polyfuses + bulk caps + V48 trace + GND pour

## Mounting holes

- **2× M3 isolated through-holes per segment** at minimum (4 if the segment shows mid-span sag in mech freelancer's bracket review).
- Default positions: x = 10 mm and x = 310 mm (10 mm from each end), centered on y = 17.5 mm. Adjust per mech freelancer's bracket design.
- Plated-through, 3.2 mm hole, 6 mm pad isolated from GND (DNP 0 Ω chassis-bond pattern available).

## Connector orientation

- **Per-slot box headers** point UP (perpendicular to backplane) — units slide vertically into them.
- **Inter-segment connectors** point HORIZONTALLY toward the adjacent segment (along the segment's long axis). 
- **Case-level RJ45s** point HORIZONTALLY OUT from the case (segment-1 outward in one direction, segment-4 outward in the other).

## Bracket interface (handed off to mech freelancer)

The PCB designer hands off the following to the mech freelancer:
1. STEP file of the assembled segment (including socket protrusion heights).
2. Mounting hole positions (x, y, diameter).
3. Inter-segment connector geometry (so brackets can leave a slot for the connector pair).
4. Case-level RJ45 face dimensions and position.

The mech freelancer then designs:
- The 3D-printed bracket that mounts each backplane segment to the MiddleFrame.
- The case-level RJ45 escapements in the case wall.
- Any cable-management features for the case-level patch cable.

## Silkscreen requirements

Top side:
- **Slot numbers**: `1` `2` `3` `4` next to each unit socket (per-segment numbering).
- **Polyfuse polarity** is N/A (resettable, non-polarized) but include trip rating: `0.2A`.
- **Test pads labeled**: `V48`, `GND`, `A`, `B`.
- **Pin-1 indicator** on case-level RJ45 (consistent with master).
- **Termination location marker**: silkscreen `R_TERM (DNP except chain-end)` near the R_TERM footprint on segment-4.
- **Title block** top-right: `SPLIT-FLAP BACKPLANE v2 SEG-N REV A`, git SHA placeholder, date placeholder.
- **Inter-segment polarity marker**: silkscreen arrow showing data-flow direction (→ chain-OUT direction).
- **Pin-1 indicator on every 2×3 box header.**

Bottom side: minimal — git SHA, fab tier note.

## Open issues

- **BM1** — Mounting hole positions and bracket geometry: pending mech freelancer.
- **BM2** — Whether segment edges should be V-cut grooves for break-off panelization at JLC, or routed-out: defer to JLC ordering.
- **BM3** — Whether the 320 mm segment length warrants additional mid-span supports (depends on bracket rigidity): defer to mech freelancer.

---

# Section 4 — BACKPLANE_BRINGUP.md

# Backplane PCB v2 — Bring-up procedure

> Per-segment + per-case bring-up sequence. Created 2026-04-25.

## Pre-power inspection

1. Visual: verify all 4 unit-slot 2×3 box-header sockets are populated and oriented correctly (pin 1 silkscreen).
2. Verify 4× 0.2 A polyfuses populated (one per slot).
3. Outer segments: verify J_RJ45 case-level RJ45 is populated (segment-1 has J_RJ45_IN, segment-4 has J_RJ45_OUT).
4. **Chain-end case backplane segment-4 only**: verify R_TERM (120 Ω) is populated. **All other case backplanes**: verify R_TERM is DNP.
5. Verify 4× test pads (V48, GND, A, B) are accessible per segment.

## Step 1 — Per-segment standalone (V48 only, no units)

For each segment in turn:
1. Apply 48 V to the upstream connector (J_SEG_IN or J_RJ45_IN for outer-segment-1).
2. Verify TP_V48: 47.5 V ± 0.5 V at the test pad.
3. Verify each polyfuse output: 47.5 V (within polyfuse R_DCmax × 0 A drop, i.e. essentially identical).
4. Verify TP_GND: 0 V (relative to PSU GND).
5. Verify there is NO 3.3 V or 12 V present (backplane is fully passive).
6. Verify A/B test pads: idle voltage depends on master bias — without master connected, expect floating (high-Z, possibly drifting).

## Step 2 — Inter-segment chain test

Connect 4 segments in a row via 6-pin inter-segment headers:
1. Apply 48 V to segment-1's upstream connector.
2. Verify TP_V48 on each subsequent segment (2, 3, 4): all 47.5 V (V48 traces are pass-through with negligible drop at no load).
3. Verify GND continuity across all 4 segments with a multimeter.
4. Verify A/B continuity: probe TP_A on segment-1, expect electrical continuity to TP_A on segment-4 (single shared net across the case).

## Step 3 — Termination check (chain-end case backplane only)

On the chain-end case backplane (the one with R_TERM populated on segment-4):
1. Disconnect everything. Measure resistance across TP_A and TP_B on segment-4.
2. Expected: 120 Ω ± 1 % (the populated R_TERM).
3. On non-chain-end case backplanes: TP_A↔TP_B should be open (R_TERM DNP, so >> 100 kΩ).

## Step 4 — Polyfuse trip test (optional, destructive on the test cable)

For each slot in turn:
1. With segment energized at 48 V, briefly short the slot's V48 pin to GND through a current-limited bench supply (or an inline 1 Ω test resistor).
2. Verify the polyfuse trips within ~1 s (current → 0 mA, slot V48 drops to ~0 V).
3. Remove short; polyfuse auto-resets within ~30 s.
4. Verify other slots on the same segment remained energized during the fault (rest of bus stays up).

## Step 5 — Full-case bring-up (with master + units)

1. Connect master's bus-1 RJ45 to chain-end case J_RJ45_IN (or first case J_RJ45_IN if multi-case).
2. Populate one unit in slot-1 of segment-1; leave other slots empty.
3. Power up master.
4. Verify master's INA237 reads steady ~25 mA on bus-1 after enable + settle (single populated unit at idle).
5. Verify the unit's STATUS LED enters 2 Hz blink (awaiting address).
6. Master discovers UID; unit transitions to solid LED.
7. Master sends test step command; unit moves the stepper.

Repeat with units in slots 2, 3, 4 — verify each enumerates with a unique address.

## Step 6 — Multi-segment + multi-unit

Populate all 16 slots (4 segments × 4 units each). Verify:
1. Master's INA237 on bus-1 reads ~400 mA at idle (16 × 25 mA).
2. Master's UID discovery enumerates all 16 units within ~10 s cold first-boot, ~100 ms warm.
3. Issue a `BROADCAST_SET_POSITION` command — all 16 units acknowledge within one bus round-trip.

## Common bring-up faults

| Symptom | Likely cause |
|---|---|
| TP_V48 reads 0 V despite 48 V applied | Polyfuse open or input connector mis-mated |
| One slot's V48 reads 0 V, others fine | That slot's polyfuse tripped (check for short on the unit) |
| Master sees 0 mA on bus despite units plugged in | Bus A/B continuity broken — check inter-segment connector mating |
| Unit enumerates but loses bus after a few seconds | Termination missing on chain-end (R_TERM not stuffed when it should be) — reflections eventually corrupt frames |
| All units disappear when one unit's polyfuse trips | Bus shouldn't be affected — if it is, polyfuse is shorting V48 to GND on trip somehow; check polyfuse footprint orientation |
| Heat localized on one polyfuse | That slot's unit is drawing > 200 mA continuously — check stepping behavior |

## Open verification items

1. **Inter-segment connector durability** — JLC PCBA 2×3 box headers are rated for ~50 mate cycles. For a permanent install, this is fine. For repeated bring-up testing, consider locking the inter-segment joint with a small screw bracket from the mech freelancer.
2. **Cable shield bond verification** — confirm the J_RJ45 shield can pads on the backplane are actually NC (not silently bonded to GND through a residual trace). Probe with a multimeter between RJ45 metal can and TP_GND — should be open.
