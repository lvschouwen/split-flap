# UNIT PCB — Consolidated Design Brief

> Concatenated for the ChatGPT review bundle. Original split lives in the repo at `PCB/v2/` (UNIT_DECISIONS.md, UNIT_POWER_DESIGN.md, UNIT_DIGITAL_DESIGN.md, UNIT_MECHANICAL_DESIGN.md, UNIT_BRINGUP.md).

**Reading order below: Decisions (source of truth) → Power → Digital → Mechanical → Bring-up.**

---

# Section 1 — UNIT_DECISIONS.md
(source of truth)

# Unit PCB v2 — locked design decisions

> **Single source of truth for the unit PCB.** Design agents bind to this file ONLY. No other file in this repo is authoritative for the v2 unit design.
>
> Last edited: 2026-04-25 (post-review backplane pivot + scottbez1 audit; see issue #76).
>
> Peer documents: `MASTER_DECISIONS.md` (master), `BACKPLANE_DECISIONS.md` (backplane). The unit **consumes** power + bus from the **backplane** (not from another unit) — anything in conflict between docs defers to `MASTER_DECISIONS.md` for system-level shape and `BACKPLANE_DECISIONS.md` for the per-slot connector contract.

## System shape (revised 2026-04-25)

- **One unit PCB per split-flap module.** 16 modules per case sit on a backplane PCB (4×4-slot segments, 320 mm each); the unit drops onto a per-slot 2×3 box header on the backplane.
- **Single MCU**: STM32G030K6T6 (Cortex-M0+, 32 KB flash / 8 KB RAM, **LQFP-32** at 7×7 mm). Was TSSOP-20 pre-2026-04-25 but pin map referenced PA12 / PB0 / PB1 which TSSOP-20 does not bond.
- **Stepper motor**: 12 V 28BYJ-48 unipolar, mechanical carry-over from v1. Off-board via 5-wire flying lead to a JST-XH 5-pin jack on the PCB.
- **Motor driver**: **TPL7407L** (TI, 7-channel low-side MOSFET array, ~0.1 Ω R_DS(on)) in SOIC-16. 4 of 7 channels drive the stepper coils; unused channels grounded. Replaces ULN2003A (Darlington, ~1.4 V Vce drop) per scottbez1 audit — pin-compatible drop-in, ~0.5 W less heat per unit at 300 mA stepping current.
- **Position sensing**: AS5600 absolute magnetic encoder on I²C (address 0x36) with **small RC filter on SDA/SCL** (100 Ω series + 100 pF shunt) to suppress buck-switching-node coupling. On-axis diametral magnet glued to the 28BYJ-48 output shaft. **No homing sweep** on boot; firmware detects + corrects missed steps using closed-loop feedback.
- **Bus**: RS-485 half-duplex at **500 kbaud 8N1** via SN65HVD75D transceiver (3.3 V, matches master). STM32G030 USART1 with hardware-assisted DE/RE via the USART DE alternate function. Wire format = COBS(payload || CRC16-BE) 0x00 per `firmware/lib/common/`.
- **Addressing (locked 2026-04-25): UID-based binary-tree discovery** driven by the master. Each unit's STM32G030 96-bit factory UID is the identity. Master broadcasts prefix-match queries; matching units echo their UID; collisions resolved by the master narrowing the prefix. Once enumerated, master assigns a 1-byte short address per unit which is stored in flash (wear-leveled ring, last 2 KB sector). **No DIP switches. No wake-pin scheme.** Pre-2026-04-25 the unit referenced a single-ended wake signal on RJ45 pin 1 — that scheme is deleted.
- **Firmware update path**: **OTA over RS-485** (master pushes images to each unit's application bootloader). First programming via SWD test pads using a pogo-pin jig. Test/bring-up alternative: **standalone UART debug mode** — when the SWD pogo-jig is connected without an active SWD interface, the unit firmware exposes a text protocol (`home`, `step N`, `angle?`) on the SWD pads' UART repurposing, allowing single-unit bench bring-up without the master/backplane (pattern adopted from scottbez1 #76 audit). **No USB** on the unit PCB.
- **Protection**: SMAJ51A TVS (matches master rail clamp class), per-unit P-channel MOSFET reverse-block on 48 V input, RS-485-rated SM712 ESD array on bus pins (matches master).
- **Status indicator**: 1 MCU-driven LED encoding state via blink pattern.
- **Fault reporting**: RS-485 polling only — unit sets status bits in its reply; master polls. No hardware back-channel.

## Backplane connector (replaces RJ45 IN/OUT)

> Per-unit RJ45 jacks are obsoleted by the backplane architecture. Each unit connects to the backplane through a single board-to-board header.

| Pin | Net | Notes |
|---|---|---|
| 1 | +48V | Paralleled with pin 3 for current capacity |
| 2 | RS-485 A | Differential pair with pin 4 |
| 3 | +48V | Paralleled with pin 1 |
| 4 | RS-485 B | Differential pair with pin 2 |
| 5 | GND | Paralleled with pin 6 |
| 6 | GND | Paralleled with pin 5 |

Connector type: **2×3 box header, 2.54 mm pitch** (male on unit, female on backplane). Standard SMD or THT 2.54 mm 2×3 part. Unit pins ~0.5 mm long after PCB; backplane socket polarised (keyed) to prevent reverse insertion.

Cable spec doesn't apply — this is a board-to-board interface inside the case.

## Power architecture

| Item | Decision |
|---|---|
| Input | 48 V from backplane connector pins 1, 3 (paralleled), GND on pins 5, 6 |
| Per-slot fuse | 0.2 A polyfuse on backplane (not on unit) |
| Input TVS | **SMAJ51A** bidirectional (V_BR ≈ 56.7 V; matches master rail clamp; pre-2026-04-25 used SMBJ58CA which would not have clamped before TPS54308's 60 V abs-max during master-side surge events) |
| Reverse-polarity | **Per-unit P-channel MOSFET reverse-block on +48 V**. Topology: source on input side, drain on load side, gate pulled high through 10 kΩ, gate-to-source Zener (12 V) clamp. Body diode points input → load (conducts at first power-up; channel then enhances). **Drain/source labels were reversed pre-2026-04-25**. Part: AO3401 (SOT-23, V_DS ≥ 30 V, R_DS(on) ~50 mΩ at V_GS=−10 V) — sufficient at 30 mA steady. Pre-2026-04-25 doc listed "SQ4953AEY or AO3401" with conflicting SOT-23/SO-8 footprints; AO3401 SOT-23 locked. |
| Motor rail (12 V) | **TPS54360DDA** (TI 60 V / 3.5 A sync buck, **HSOP-8 PowerPAD**). Replaces TPS54308DBV (SOT-23-6 with no thermal pad — its ≤80 °C/W spec was physically unachievable; #76 audit). V_ref = 0.8 V; FB divider populated for 12 V. |
| Logic rail (3.3 V) | **HT7833** LDO (SOT-89, ~500 mA rated, ~0.5 V dropout). Dissipates ~0.4 W at ~50 mA logic load — within SOT-89 thermal budget. |
| Per-unit OCP | Backplane per-slot 0.2 A polyfuse (not on unit). |

**Bus current budget** (12 V 28BYJ-48 motor + ~50 mA logic):
- Per unit steady-state at 48 V input: ~25 mA estimated (10 mA motor-hold + 15 mA logic-path through LDO, buck efficiency ~90%). **Re-measure on first prototype** — scottbez1 audit flagged that 28BYJ-48 stepping current is closer to 300 mA peak at 12 V than the 74 mA hold-current assumption.
- 16 units × 25 mA per case = ~400 mA per case at 48 V — well within backplane polyfuse budget.

## Inter-chip communication

| Path | Signal | Notes |
|---|---|---|
| RS-485 bus | STM32 USART1 ↔ SN65HVD75D ↔ backplane connector A/B | 500 kbaud, hardware DE via USART, COBS+CRC16-BE framing |
| Sensor | STM32 I²C1 ↔ 100 Ω series ↔ 100 pF shunt ↔ AS5600 | 400 kHz fast mode, addr 0x36, RC filter added 2026-04-25 |
| Stepper | STM32 4 GPIO ↔ TPL7407L IN1–IN4 → 28BYJ-48 coils | 8-step half-step sequencing in firmware |
| Status LED | STM32 GPIO → 1 kΩ → LED → GND | ~1.3 mA drive |
| Debug | 4 test pads (SWDIO, SWCLK, NRST, GND) | Pogo-pin jig (1.5 mm pads on 2.54 mm pitch) |

## GPIO budget (STM32G030K6T6, LQFP-32)

LQFP-32 exposes 28 GPIOs minus VDD/VSS/NRST → **~25 usable application GPIOs**.

| Function | Pins |
|---|---|
| USART1 TX / RX / DE | 3 |
| I²C1 SDA / SCL | 2 |
| TPL7407L IN1–IN4 | 4 |
| Status LED | 1 |
| **Total assigned** | **10** |
| **Spare** | **≥15** |

AS5600 DIR pin tied to GND or VCC — does not consume a GPIO.

### GPIO allocation policy (locked)

1. **SWD pair (PA13/PA14) reserved** for programming + debug. Not remapped at runtime.
2. **BOOT0 tied LOW** via 10 kΩ pull-down. No hardware bootloader entry path — OTA is firmware-initiated.
3. **NRST conditioning**: 100 nF cap NRST→GND + 10 kΩ pull-up to 3V3. Standard reset hygiene.
4. **USART1 DE uses hardware AF** — do NOT implement software RS-485 direction toggling.
5. **Specific pin numbers** documented in `UNIT_DIGITAL_DESIGN.md` preferred map. With LQFP-32, all map entries (PA12, PB0, PB1) are now bonded.

## LED set (1 total)

| # | Label | Driven by | Color | Encoding |
|---|---|---|---|---|
| 1 | STATUS | MCU GPIO | green or blue 0603 | off = dead · 2 Hz = awaiting address · solid = enumerated/idle · 4 Hz burst = stepping · 2× fast blink w/ pause = fault |

Single LED by design — saves BOM, area, and MCU pins across 128 units.

## Connectors

| Connector | Part class | Count |
|---|---|---|
| Backplane | 2×3 box header 2.54 mm pitch (male on unit) | 1 |
| Motor | JST-XH 5-pin vertical, 2.5 mm pitch | 1 |
| SWD | 4 test pads (SWDIO, SWCLK, NRST, GND) — 1.5 mm pads, 2.54 mm pitch | — |

No USB. No RJ45. No debug header (pads only). No auxiliary connectors.

## Termination (revised 2026-04-25 — moves to backplane)

> **Important architectural change**: with the backplane pivot, the chain ends at the case-level RJ45 on the chain-end backplane segment, NOT on a unit. Therefore the per-unit termination + jumper + shunt scheme from the pre-2026-04-25 design is **removed from the unit**. Termination lives on the backplane (PCBA stuffing variant; populated only on chain-end case backplane).

The unit has **no termination components**. The bus presents as a 6-pin board-to-board header to the backplane; termination is the backplane's responsibility.

Failsafe bias is provided **at the master only** (1 kΩ each leg); unit and backplane add no bias.

## Mechanical decisions

- **Board dimensions: target 75 × 35 mm** (revised 2026-04-25 from 65 × 35 mm — accommodates the larger STM32G030 LQFP-32 footprint, the AS5600 ferrous keep-out plus motor connector, and the TPS54360 HSOP-8 PowerPAD with adequate thermal pour).
- **Layer count: 2** (1.6 mm FR-4, 1 oz outer, HASL finish acceptable).
- **AS5600 placement**: on-axis with the 28BYJ-48 output shaft. Origin at AS5600 IC center (0,0). **Mechanical bracket designed by mech freelancer**; PCB hands off the AS5600 coordinate + magnet keep-out + mounting-hole positions in a STEP file. PCB does not constrain the bracket geometry.
- **Mounting**: 2× M3 isolated through-holes — final positions coordinated with the mechanical bracket via STEP exchange.
- **Backplane connector orientation**: 2×3 box header on the back-edge of the unit PCB so the unit slides perpendicular into the backplane along the case-back wall.

## Prototype / production target

- **Prototype run: 10 boards** via JLC PCBA. Enables 4 unit chain tests (one case worth) + spares for mechanical and destructive testing.
- Not production-ready. BOM items flagged "CHECK" at freeze time are acceptable substitutions for the prototype.
- **Schematic capture path**: KiCad preferred to enable the **KiBot + kikit production pipeline** (CI-driven JLCPCB output, LCSC alt-part fields). Adopted post-#76 audit from scottbez1.

## Design artifacts (in this directory)

- `UNIT_DECISIONS.md` (this file) — source of truth; agents bind to this only.
- `UNIT_POWER_DESIGN.md` — power subsystem schematic-level detail.
- `UNIT_DIGITAL_DESIGN.md` — digital subsystem + GPIO map + protocol-level notes.
- `UNIT_MECHANICAL_DESIGN.md` — placement brief, floorplan, AS5600 integration.
- `UNIT_BOM.csv` — JLC-native BOM.
- `UNIT_BRINGUP.md` — per-board bring-up sequence including standalone UART test mode.

## Resolved issues (2026-04-25 #76 audit)

- ~~U1 LDO P/N~~ — locked to HT7833 SOT-89.
- ~~U2 ESD array~~ — locked to SM712-02HTG (matches master; replaces SP0504BAATG which would clamp legitimate RS-485 traffic at 5 V).
- ~~U4 GPIO-to-pin assignments~~ — finalised in `UNIT_DIGITAL_DESIGN.md` against LQFP-32.
- ~~U5 RJ45 jack P/N~~ — N/A; unit no longer carries RJ45s.
- ~~U7 WAKE_OUT drive style~~ — N/A; UID-based discovery.
- ~~U8 AS5600 DIR pin level~~ — confirmed at bring-up; default GND (CW). Non-blocking.
- ~~U9 master-bias cross-check~~ — confirmed; master 1 kΩ each leg, unit/backplane no bias.
- ~~U10 termination jumper pitch~~ — N/A; termination on backplane.

## Still deferred (non-blocking)

- **U3 — Diametral magnet P/N + grade.** 6×2.5 mm N35 vs N42. Validate with an AS5600 breakout first. Off-board item.
- **U6 — Mounting hole positions.** Determined alongside 3D bracket design (mech freelancer).
- **U_STEP — Stepping current real-world measurement.** First-prototype task. Re-spec backplane polyfuse sizing if 28BYJ-48 stepping pulls > 300 mA peak.

## AS5600 datum problem (pass-2 sharpened)

AS5600 placement is **not a PCB placement note — it is a mechanical datum problem**. The unit is **not layout-ready** until the mech freelancer's STEP/dimensioned-drawing hand-off contains **hard numbers**, not a "signoff." Required values (every one explicit, no "TBD"):

| # | Value | Where it lands | Notes |
|---|---|---|---|
| 1 | **Motor shaft XY datum** relative to PCB origin | drawing | mm, ±tolerance |
| 2 | **AS5600 IC package-center coordinate** + tolerance | drawing | nominally on the motor-shaft axis — quote the offset, not "centered" |
| 3 | **Magnet diameter** | drawing + BOM `MAGNET` row | typ. 6 mm |
| 4 | **Magnet thickness** | drawing + BOM | typ. 2.5 mm |
| 5 | **Diametral magnetization requirement** | BOM Notes | explicitly *diametral*, not axial — silent killer if wrong |
| 6 | **Target air gap** | drawing | nominal, e.g. 1.5 mm |
| 7 | **Min air gap** + **max air gap** guarantee | drawing | bracket tolerance stack-up must enforce 0.5 mm < gap < 3.0 mm |
| 8 | **Allowed radial magnet offset** | drawing | typ. ≤ 0.25 mm at full resolution |
| 9 | **Allowed axial tilt / wobble** (if known) | drawing | shaft + magnet-glue tolerance |
| 10 | **Board mounting hole tolerance** | drawing | M3 oversize + locating-feature spec |
| 11 | **Motor connector / harness clearance envelope** | drawing | so JST-XH harness doesn't foul the bracket |

Without these eleven values explicit in a single dimensioned drawing or STEP exchange, **the unit PCB does not enter layout.** The electronics can be perfect and the unit can still fail to read absolute angle if any one of these is wrong or missing.

## TPS54360 thermal plan (post external review)

TPS54360DDA HSOP-8 PowerPAD thermal copper / via plan must be specified **before layout**, not discovered during fab. Decisions:

- Exposed pad copper pour ≥ 200 mm² on the bottom layer with thermal stitching (≥ 6× 0.3 mm vias under the pad on the top, drawing heat to the bottom pour).
- Top-side copper relief around the pad to prevent solder-paste pull-off during reflow.
- Switch-node copper kept compact (≤ 100 mm² to limit EMI radiation) and away from AS5600 / I²C traces.

## SWD pogo + standalone UART access (post external review)

The unit's bring-up depends on:

- **SWD pogo fixture geometry** documented (4× 1.5 mm pads on 2.54 mm pitch, edge-accessible, oriented for jig insertion direction). Not negotiated at fab time.
- **Standalone UART test mode pad access** documented — the SWD pads (PA13/PA14) repurposed as UART RX/TX when no SWD master is present. Bring-up jig must be able to drive both modes from the same pogo footprint.

## LAYOUT_CONSTRAINT: unit pre-layout checklist (pass-2 sharpened)

### Encoder + sensitive-net layout

- **AS5600 IC center tied to motor shaft datum** with explicit tolerance (per the mech freelancer's STEP — see the 11-value table above).
- **Magnet gap target** (1.5 mm nominal) and min/max guarantee from the bracket assembly.
- **Buck switch node** kept compact and **away from AS5600 / I²C traces** — keep ≥ 5 mm separation and route AS5600 I²C on the opposite layer with GND pour between.
- **AS5600 I²C local RC filter (100 Ω series + 100 pF shunt)** placed close to the AS5600 side of the I²C net, not close to the MCU side, so the filter rejects buck-switching coupling at the encoder.
- **RS-485 ESD (SM712-02HTG)** placed close to the backplane connector entry, not close to the SN65HVD75 — protect the connector entry, not the transceiver.

### Power + driver layout

- **TPL7407 IN5–IN7 hard-tied to GND** (not via 10 kΩ — false-turn-on risk during MCU reset).
- **TPS54360 PowerPAD copper / via thermal plan**: thermal pad ≥ 200 mm² ground pour on the bottom layer with ≥ 6× 0.3 mm thermal vias under the package. Top-side relief around the pad to prevent solder-paste pull-off during reflow. Switch-node copper kept compact (≤ 100 mm² to limit EMI radiation).

### Test points + mechanical

- **Test pads** for: 12 V (post-buck), 3V3, V48 after reverse-FET, NRST, SWDIO, SWCLK, UART/test-mode RX, UART/test-mode TX, RS-485 A, RS-485 B, RS-485 DE, RS-485 TX, RS-485 RX (where space allows).
- **SWD pogo pad geometry**: 4× **1.5 mm round pads** on **2.54 mm pitch**, edge-accessible, oriented so the jig can insert without colliding with the magnet bracket or motor connector. Document the pogo footprint + jig clearance envelope in the layout brief.
- **Motor connector orientation and pinout** must match the actual 28BYJ-48 harness/motor variant supplied — verified at first-prototype mechanical fit.

### Stackup + DRC class table (pass-2 added)

- **Stackup**: 2-layer FR-4, 1.6 mm, **1 oz outer copper**, **HASL** finish acceptable.
- **Fiducials**: 3 (two diagonal corners + asymmetric third), 1 mm copper / 3 mm soldermask, on top side. Per-board, not per-panel.
- **Panelization**: 10-up panel for prototype run. Mouse-bite tabs preferred; V-score acceptable. Tooling holes 3.2 mm at panel rails (not on the board).
- **Test pad size**: 1 mm round SMD where bench-probe access is needed; 0.5 mm round for compact pogo points.

| Class | 48 V net | RS-485 | I²C / Logic | General |
|---|---|---|---|---|
| Trace-to-trace clearance | ≥ 0.40 mm | ≥ 0.15 mm | ≥ 0.15 mm | ≥ 0.15 mm |
| Trace-to-edge clearance | ≥ 0.50 mm | ≥ 0.30 mm | ≥ 0.30 mm | ≥ 0.30 mm |
| Min drill | 0.30 mm | 0.30 mm | 0.20 mm | 0.20 mm |
| Min annular ring | 0.15 mm | 0.10 mm | 0.10 mm | 0.10 mm |
| Drill-to-copper (other net) | ≥ 0.30 mm | ≥ 0.20 mm | ≥ 0.20 mm | ≥ 0.20 mm |
| Silkscreen-to-copper | ≥ 0.10 mm | ≥ 0.10 mm | ≥ 0.10 mm | ≥ 0.10 mm |
| Edge-cuts to copper | ≥ 0.50 mm | ≥ 0.30 mm | ≥ 0.30 mm | ≥ 0.30 mm |

## REVIEW_STRONG_OPINION: AS5600 alignment is the unit's hardest problem

If AS5600 / magnet alignment is not specified as a drawing with tolerances, the electronics can be perfect and the unit can still fail. Treat the mech freelancer hand-off as a critical-path layout-readiness blocker, not a parallel workstream.

---

# Section 2 — UNIT_POWER_DESIGN.md

# Unit PCB v2 — Power subsystem design

Complement to `UNIT_DECISIONS.md` §Power architecture. Schematic-level detail for the designer. Last edited 2026-04-25 (#76 backplane pivot + part-swap to TPS54360 + TPL7407L + SM712).

## Block diagram

```
Backplane connector pins 1, 3 (paralleled +48V), 5, 6 (paralleled GND)
     │
     │  Input filter: 10 µF / 100 V X7R 1210 + 100 nF
     │  TVS: SMAJ51A (+48V ↔ GND, near connector — matches master rail clamp class)
     │
     └── Q_REV  P-channel MOSFET (AO3401, V_DS ≥ 30V, R_DS(on) ~50 mΩ at V_GS=−10V)
            │   Reverse-polarity block — source on input, drain on load (corrected 2026-04-25);
            │   gate pulled high through 10 kΩ; gate-source Zener (12 V) clamp.
            │   Body diode conducts at first power-up; channel then enhances.
            │
            └── TPS54360DDA buck  (48V → 12V @ 3 A max — sized for 28BYJ-48 stepping)
             │ HSOP-8 PowerPAD (replaces TPS54308 SOT-23-6 which had no thermal pad)
             │ 22 µH inductor (Isat ≥ 1 A — bumped from 600 mA per scottbez1 audit
             │                 stepping-current re-measurement flag)
             │ 22 µF / 50 V X7R 1210 output
             │ EN tied to VIN via divider; internal soft-start ~3 ms
             │ V_ref = 0.8 V; FB divider populated for 12 V (R_top = 140 kΩ, R_bot = 10 kΩ)
             │
             └─→ 12V rail ─── TPL7407L COM pin (flyback return)
                           └── HT7833 LDO input

12V rail (~300 mA motor peak)
     │
     └── HT7833 LDO (12V → 3.3V @ ≤ 100 mA)
              │ 1 µF / 25 V X7R 0603 in
              │ 1 µF / 10 V X7R 0603 out (separate LCSC from input cap — corrected 2026-04-25)
              │
              └─→ 3.3V rail
                       ├── STM32G030 VDD / VDDA
                       ├── AS5600 VDD + VDD3V3 (with RC filter on SDA/SCL)
                       ├── SN65HVD75 VCC
                       └── LED via 1 kΩ current limit
```

## Buck — TPS54360DDA

> **Replacement (2026-04-25)**: was TPS54308DBV. SOT-23-6 has no thermal pad — its θ_JA spec of ≤80 °C/W was physically unachievable (real value ~165 °C/W). #76 audit. TPS54360DDA in HSOP-8 PowerPAD has a true exposed thermal pad and reaches the spec via standard via-stitched copper pour.

- **VIN range**: 4.5 – 60 V. 48 V input well within spec (12 V headroom vs 60 V abs-max allows for master-side transient ringing).
- **VOUT**: 12.0 V set by feedback divider (V_ref = 0.8 V internal):
  - R_top = 140 kΩ, R_bot = 10 kΩ → VOUT = 0.8 × (1 + 140/10) = **12.0 V**. Both 1 % 0603.
- **Switching frequency**: 600 kHz (R_T = 200 kΩ; pin-adjustable on the DDA variant — pick a value that doesn't fall on AS5600 sample-rate sub-harmonics).
- **Inductor**: 22 µH, Isat ≥ **1 A** (bumped from 600 mA per scottbez1 audit; 28BYJ-48 stepping pulls ~300 mA peak per phase, two phases simultaneous = 600 mA worst case). Candidates: Coilcraft XAL4030-223 or Sunlord SWPA4030S220MT (verify Isat).
- **Output cap**: 22 µF / 50 V X7R 1210 (derated to ~16 µF effective at 12 V — within TPS54360 stability window).
- **Input cap**: 10 µF / 100 V X7R 1210, derated to ~4 µF at 48 V — sufficient.
- **Bootstrap**: BOOT pin requires 100 nF / 25 V X7R 0402 to SW pin (per datasheet).
- **Layout**:
  - Switch-node loop ≤ 5 mm end-to-end.
  - Input cap within 2 mm of VIN pin.
  - Output cap between inductor and VOUT sense path.
  - Feedback trace kept away from switch-node.
  - Thermal pad → ≥ 6× 0.3 mm thermal vias dropped into ≥ 200 mm² bottom GND pour + ≥ 100 mm² top GND pour (UNIT_MECHANICAL §Thermal). Target θ_JA ≤ 40 °C/W (HSOP-8 PowerPAD with proper pour, vs 80 °C/W spec — comfortable margin).

## LDO — HT7833

- **Dropout**: ≤ 0.5 V at 100 mA.
- **Thermal** (worst-case): (12 V − 3.3 V) × 50 mA = **0.435 W**.
  - HT7833 SOT-89 θ_JA ~150 °C/W on a 2-layer board with copper pour → rise ~65 °C.
  - Ambient 40 °C → T_J ~105 °C. Within 125 °C max. Acceptable.
- **Alternative**: AP2127K-3.3 in SOT-23-5 is also a candidate but θ_JA ~220 °C/W pushes T_J to ~120 °C — too marginal. **HT7833 preferred for thermal headroom**.
- **Bypass**: 1 µF input + 1 µF output ceramic (X7R 0603).

## Protection

- **Reverse-polarity P-MOSFET (per-unit, defense-in-depth)** — backplane is keyed and the case-level RJ45 carries the externally-induced reverse-polarity risk; per-unit P-FET still belt-and-suspenders against a hand-wired backplane fault.
  - **Topology (corrected 2026-04-25)**: in-line **P-channel MOSFET on +48 V** — **source on input side, drain on load side**. Body diode points input → load (conducts at first power-up). Gate pulled high through 10 kΩ; gate-to-source 12 V Zener clamp to keep V_GS within ±20 V abs-max. Correct polarity: source at +48 V, gate at GND via 10 kΩ → V_GS = −48 V (clamped to −12 V) → channel enhances → conducts. Reversed polarity: source at GND, body diode reverse-biased → no current path → unit safe. Pre-2026-04-25 doc had drain/source labels reversed — corrected per #76 audit.
  - **Part (locked 2026-04-25)**: **AO3401** (SOT-23, V_DS = −30 V, R_DS(on) ≈ 50 mΩ at V_GS = −10 V), ~€0.10. SOT-23 acceptable at the unit's ≤ 30 mA steady-state load. SQ4953AEY (SO-8 dual) is no longer an alternate — single-package, single-footprint.
  - **Placement**: between the input TVS and the rest of the unit. TVS upstream so it clamps surges before they reach the MOSFET.
- **SMAJ51A TVS (revised 2026-04-25 from SMBJ58CA)** — bidirectional, 51 V standoff, ~57 V V_BR at low-end tail current, 400 W pulse rating. Matches master's V48_RAIL clamp class; ensures unit-side clamping at ~57 V if a master-side surge propagates onto the cable. SMBJ58CA (V_BR ≈ 64.4 V, V_C ≈ 93 V) was inadequate — would not have fired before the buck's 60 V abs-max during a master-side surge event.
  - One SMAJ51A between +48 V and GND, located ≤ 10 mm from the backplane connector entry, upstream of the reverse-polarity P-MOSFET.
- **ESD array on RS-485 lines (revised 2026-04-25 from SP0504BAATG to SM712-02HTG)** — RS-485-rated, transient-only clamp. Working voltage ±7 V/±12 V — does not fire on legitimate bus traffic (SP0504BAATG clamped at 5 V working, would have fired on normal RS-485 common-mode swings). Same part used on master for inventory consolidation.
  - Location: ≤ 5 mm from the backplane connector A/B pin entry, before trace reaches SN65HVD75.

## Grounding (revised 2026-04-25 with explicit zone separation)

- Single GND net but **two layout zones**: motor-return GND vs signal/sensor GND.
- **Motor-return zone**: TPL7407L pin 8 (GND) + JST-XH pin 5 return current path bonded to the buck output cap GND pad via a single short trace. This is the high-di/dt zone (stepper coil flyback through TPL's clamp diodes).
- **Signal/sensor zone**: STM32, AS5600, SN65HVD75, LDO output return path stitched to the same star point near the buck output cap on a separate path — does NOT share copper with the motor-return zone except at the star point.
- 2-layer board with solid GND pour on bottom layer in BOTH zones; the zoning is enforced by component placement and short-trace return paths on top, not by physical splits in the bottom pour.
- AS5600 GND to its bypass cap via short direct trace; **no motor-return current flows under AS5600 IC body** (TPL7407L OUT return traces clustered away from AS5600 keepout).
- No RJ45 / cable shield to manage on the unit (backplane handles the case-level shield bond at master only — see `BACKPLANE_DESIGN.md`).

## Bus current budget (sanity check)

Per unit at 48 V input, steady-state:
- Motor hold (2 phases energized at 12 V, ~74 mA): 12 × 0.074 / (48 × 0.90) = **20.5 mA**.
- Logic (3.3 V × ~50 mA via 12V buck + LDO): ≈ 12 × 0.050 / (48 × 0.90) ≈ **13.9 mA** (LDO's extra heat means the 48V-input-side draw is actually the full 12V-side current, so add 50 mA × (12/48) = 12.5 mA instead. Use 12.5 mA as the buck-side draw).
- **Total: ~25 mA per unit, 48 V input, steady-state.**

32 units × 25 mA = 800 mA per bus → 47 % of 1.7 A eFuse trip. **53 % headroom** for transient motor pulls (stepping current briefly ~2× hold current).

Master's 4 buses × 0.8 A = 3.2 A at 48 V = 154 W at full load before 3.3 V/12 V conversion overhead — within the master's 48 V input supply budget (see `MASTER_DECISIONS.md`).

## Open issues (non-blocking)

- **P1** — Buck inductor value verified against TPS54308 datasheet equation for 500 kHz switching at 12 V output. 22 µH is conservative; 15 µH datasheet-compliant as well. Lock at schematic capture.
- **P2** — ESD array exact P/N locked at BOM freeze based on JLC basic-library stock.
- **P3** — LDO escalation path: if a future unit revision grows logic current beyond 100 mA (e.g. adds an RGB LED array or Wi-Fi module), replace HT7833 with a second TPS54308 configured for 3.3 V. No PCB change other than the IC + one resistor.
- ~~**P4**~~ **Resolved 2026-04-25.** Buck thermal spec locked in `UNIT_MECHANICAL_DESIGN.md` §Thermal considerations: ≥ 6 thermal vias, ≥ 200 mm² bottom pour, ≥ 100 mm² top pour, θ_JA ≤ 80 °C/W. Fallback to TPS54360 if layout cannot hit spec.
- **P5** — 48V→12V efficiency at 250 mA load: TPS54308 datasheet shows ~85 % at this operating point. If the efficiency measured during bring-up is < 80 %, revisit inductor DCR + output cap ESR contributions.

---

# Section 3 — UNIT_DIGITAL_DESIGN.md

# Unit PCB v2 — Digital subsystem design

Complement to `UNIT_DECISIONS.md` §Inter-chip communication. Schematic-level detail, GPIO map, and protocol-level notes. Last edited 2026-04-25 (#76 backplane pivot + UID discovery + part swaps).

## Block diagram

```
Backplane connector (2×3 box header, 2.54 mm)
  │  pins 1, 3: +48V (paralleled)
  │  pins 5, 6: GND (paralleled)
  │  pin 2: RS-485 A
  │  pin 4: RS-485 B
  │
  ├── A/B ─── SM712 ESD clamp ── SN65HVD75D ── DI / RO / DE ── STM32 USART1 (500 kbaud, COBS+CRC16-BE)
  │
  └── 48V → SMAJ51A TVS → AO3401 P-FET reverse-block → TPS54360DDA buck → 12V
                                                                            │
                                                                          HT7833 LDO → 3V3
                                                                            │
                                            STM32 I²C1 ── 100Ω+100pF RC filter ── AS5600 (addr 0x36)
                                            STM32 4× GPIO ── TPL7407L IN1-4 ── 28BYJ-48 (via JST-XH)
                                            STM32 1× GPIO ── STATUS LED
                                            STM32 SWD pads (1.5 mm pads, 2.54 mm pitch) ── pogo-pin jig
```

## RS-485 bus wiring (one transceiver, one backplane connector)

The unit taps across A/B (backplane connector pins 2, 4) via a single SN65HVD75D near the MCU. There is no IN/OUT pair on the unit — the bus is presented by the backplane already and the unit is a single stub on the multi-drop bus.

- **No termination on the unit.** Termination lives on the backplane (PCBA stuffing variant; populated only on the chain-end case backplane segment per `BACKPLANE_DECISIONS.md`).
- **No failsafe bias on the unit.** Bias is at the master only (1 kΩ each leg).
- The unit-side stub from connector to SN65HVD75 A/B pins is ≤ 30 mm — well within RS-485 stub-length limits at 500 kbaud.

## SN65HVD75D (RS-485 transceiver)

| SN65HVD75 pin | Connected to | Notes |
|---|---|---|
| D (DI) | STM32 USART1_TX (PA9) | Drives bus when DE asserted |
| DE | STM32 USART1_DE (PA12, AF1) | Hardware RS-485 direction control (PA12 is bonded on LQFP-32) |
| /RE | Tied to DE | Half-duplex; RX when DE low |
| R (RO) | STM32 USART1_RX (PA10) | Receive from bus |
| A | Backplane connector pin 2 | Bus A (multi-drop stub) |
| B | Backplane connector pin 4 | Bus B (multi-drop stub) |
| VCC | 3.3 V | 100 nF local bypass |
| GND | GND | — |

Baud: **500 kbaud 8N1**. Wire format: COBS(payload || CRC16-BE) 0x00 framing per `firmware/lib/common/`. SN65HVD75 slew-rate-limited driver matches the rate comfortably; no additional common-mode choke or ferrite needed at this speed.

## I²C1 / AS5600 (RC filter added 2026-04-25)

| AS5600 pin | Connected to | Notes |
|---|---|---|
| VDD (1) | 3.3 V | 100 nF local bypass |
| VDD3V3 (8) | internal 3.3V node | Tie to VDD per datasheet when powered from 3.3 V |
| OUT (2) | NC | Not using analog/PWM output |
| GND (3, 7) | GND | — |
| DIR (4) | GND (CW default) | Pick orientation at bring-up; tie to VCC if reversed |
| SDA (5) | 100 Ω series → STM32 I2C1_SDA (PB7) | 4.7 kΩ pull-up to 3.3 V within 5 mm; 100 pF shunt on AS5600 side |
| SCL (6) | 100 Ω series → STM32 I2C1_SCL (PB6) | Same RC topology |

I²C clock: **400 kHz fast mode**. AS5600 default address: **0x36**.

**RC filter rationale (added 2026-04-25 per #76 audit)**: with a 600 kHz buck switch node ~10 mm from the I²C bus on a 75×35 mm board, common-mode noise can couple onto SDA/SCL. 100 Ω + 100 pF gives a low-pass corner at ~16 MHz — well above 400 kHz I²C operation but rejects buck-harmonic edges. Cost: 4 passives, ~€0.04. Routes SDA/SCL away from the switch node loop regardless.

## TPL7407L / stepper drive (replaces ULN2003 — 2026-04-25 per scottbez1 audit)

> **Replacement**: TPL7407L is a pin-compatible MOSFET drop-in for ULN2003 (TI's modern equivalent). R_DS(on) ~0.1 Ω vs ULN2003's ~1.4 V Vce(sat) Darlington saturation — saves ~0.5 W per unit at 300 mA stepping current. Same SOIC-16 footprint.

| TPL7407L pin | Connected to | Notes |
|---|---|---|
| IN1–IN4 (1–4) | STM32 GPIO PA0–PA3 | 3.3 V GPIO direct drive — TPL7407L Vih ≈ 2.0 V, OK |
| IN5–IN7 (5–7) | GND | **Hard-tied directly to GND copper, NOT through 10 kΩ** (corrected 2026-04-25 — pre-existing R_ULN_PD removed) |
| OUT1–OUT4 (13–16) | JST-XH 5-pin connector pins 1–4 | Motor coil drives |
| COM (9) | 12 V rail | Provides flyback return through internal MOSFET body diodes |
| GND (8) | GND (motor-return zone) | — |

JST-XH 5-pin pinout (matches 28BYJ-48 factory connector):
- Pin 1: Coil 1 (blue)
- Pin 2: Coil 2 (pink)
- Pin 3: Coil 3 (yellow)
- Pin 4: Coil 4 (orange)
- Pin 5: Common (red) → 12 V rail

**Stepping mode**: 8-step half-stepping (phase sequence A, AB, B, BC, C, CD, D, DA) in firmware. Smoother than full-step and standard for 28BYJ-48.

## Status LED

- STM32 GPIO → 1 kΩ series resistor → LED anode → cathode to GND (sink, GPIO drives HIGH to light).
- Alternative: source-drive with LED to VCC via 1 kΩ (GPIO LOW to light). Pick whichever matches firmware idle state preference.
- Current: (3.3 − 2.0) / 1000 ≈ **1.3 mA** — bright enough indoors, well under MCU GPIO limits.

## SWD programming interface (revised 2026-04-25)

Four **1.5 mm pads on 2.54 mm pitch** (industry-standard Tag-Connect TC2030 footprint or simple 0.05" pads), single row, on one edge of the board:
- **SWDIO** ↔ STM32 PA13
- **SWCLK** ↔ STM32 PA14
- **NRST** ↔ STM32 NRST pin (with 100 nF cap NRST→GND + 10 kΩ pull-up to 3V3)
- **GND** ↔ GND

No header. Pogo-pin jig touches pads during factory programming. Field updates go over RS-485. Pre-2026-04-25 spec was 2 mm pads on 1.5 mm spacing — too tight (0.5 mm clearance is below most pogo-jig design rules); corrected per #76 audit.

**Standalone test mode (added 2026-04-25 per scottbez1 audit)**: when the SWD pogo-jig connects without an active SWD master, unit firmware exposes a text protocol on PA13/PA14 repurposed as UART-RX/TX. Commands: `home`, `step <N>`, `angle?`, `id?`. Allows single-unit bench bring-up without master/backplane. Documented in `UNIT_BRINGUP.md`.

**BOOT0** on STM32G030 is tied LOW via 10 kΩ pull-down. No hardware bootloader entry — OTA is firmware-initiated via RS-485 command.

## Preferred GPIO pin map (STM32G030K6T6, LQFP-32)

| Pin | Signal | Rationale |
|---|---|---|
| PA0 | TPL_IN1 | GPIO, no AF conflict |
| PA1 | TPL_IN2 | — |
| PA2 | TPL_IN3 | — |
| PA3 | TPL_IN4 | — |
| PA6 | STATUS_LED | TIM3_CH1 available for optional brightness PWM |
| PA9 | USART1_TX | AF1 — RS-485 DI |
| PA10 | USART1_RX | AF1 — RS-485 RO |
| PA12 | USART1_DE | AF1 — hardware RS-485 direction (bonded on LQFP-32) |
| PA13 | SWDIO / standalone-mode UART RX | Mandatory + dual-purpose |
| PA14 | SWCLK / standalone-mode UART TX | Mandatory (also BOOT0 alt-func — tied LOW externally) |
| PB6 | I2C1_SCL | AF6 — default |
| PB7 | I2C1_SDA | AF6 — default |
| PB0 | spare | Test pad — bonded on LQFP-32 (was unbonded on TSSOP-20 pre-2026-04-25) |
| PB1 | spare | Test pad — bonded on LQFP-32 |
| PA4, PA5, PA7, PA8, PA11, PA15, PB2-PB5, PB8, PB9 | spare | Reserved + test pads (LQFP-32 bonds many more pins than TSSOP-20) |

Spare GPIO pool: ≥ 15 — generous future-proofing on LQFP-32. The pre-2026-04-25 TSSOP-20 map referenced PA12, PB0, PB1 which were unbonded on that package — corrected by package upgrade.

## Auto-enumeration protocol (revised 2026-04-25 — UID-based binary tree)

> **Architectural change**: pre-2026-04-25 spec used a single-ended wake signal on RJ45 pin 1 to serialise enumeration. With the backplane pivot (no per-unit RJ45) and per `MASTER_DECISIONS.md` system-shape, enumeration is now **UID-based binary-tree search over RS-485** — pure firmware, no per-unit hardware support.

Master-driven binary tree search adapted from 1-Wire ROM search:

1. **Boot**: unit reads its 96-bit factory UID from STM32 system memory. Sets `address = stored-or-none` from flash. Drives bus output high-Z when DE not asserted.
2. **Master broadcasts `SEARCH_PREFIX(prefix_bits, prefix_value)`**: all unaddressed units whose UID matches the prefix respond with their full UID + a CRC.
3. **Master listens**:
   - 1 unit responded with valid CRC → master records the UID.
   - Multiple units responded → bus collision → CRC fails → master narrows the prefix by one bit and recurses.
   - 0 responses → no units in this branch.
4. **Master assigns a 1-byte short address** to each discovered UID via `ASSIGN(uid, addr=N)` — the addressed unit stores N in flash (wear-leveled ring, last 2 KB sector — see D5).
5. **Master persists the UID→address map in NVS** (also UID→physical-slot map for calibration continuity across re-flashes).

Cold first-ever boot: ~5–20 s for 32 units (scales as binary depth × per-bit RTT). Warm boot (UIDs already known): ~100 ms.

Re-enumeration: master can broadcast `RESET_ADDR` to clear all addresses, then restart the search. Hot-replace: master sees one un-claimed UID after periodic re-search → assigns next available address.

## Open issues (non-blocking)

- ~~**D1**~~ **Closed 2026-04-25.** WAKE_OUT scheme deleted; UID-based discovery replaces it.
- **D2** — AS5600 DIR level (CW = GND, CCW = VCC) confirmed at bring-up. Default GND.
- ~~**D3**~~ **Closed 2026-04-25.** Termination moved to backplane.
- **D4** — Unused spare GPIOs: ≥ 15 spares on LQFP-32. Test pads on a few selected (PB0, PB1, PA4, PA8) for future rework.
- **D5** — STM32G030 wear-leveling: ≤ 100 enumeration events lifetime expected; flash endurance ~10k → ~100× margin. Wear-leveled ring in last 2 KB sector with 256 B records; rewrite only on address change or fault latch. Locked spec, non-blocking.
- **D6** — OTA security: master-unit authentication for firmware-push is a firmware-level concern. Hardware does not enforce signature verification — firmware must.
- ~~**D7**~~ **Closed 2026-04-25.** Standalone test mode locked (UART repurpose on SWD pads — see SWD section).

---

# Section 4 — UNIT_MECHANICAL_DESIGN.md

# Unit PCB v2 — Mechanical design

Complement to `UNIT_DECISIONS.md` §Mechanical decisions. Placement brief, AS5600 integration, and mounting sketch. Last edited 2026-04-25 (#76 backplane pivot).

## Board specification

- **Dimensions target: 75 × 35 mm** (revised 2026-04-25 from 65 × 35 mm — accommodates LQFP-32 STM32G030 + HSOP-8 PowerPAD TPS54360 + AS5600 ferrous keep-out + motor connector + backplane connector). 80 mm pitch case allows a small mechanical clearance around the unit board.
- **Layer stack**: 2-layer, 1.6 mm FR-4, 1 oz / 1 oz copper, HASL finish (ENIG only if signal-integrity review flags the RS-485 differential routing — unlikely at 500 kbaud over an internal stub).
- **Corner treatment**: 1 mm outside radius — pick-and-place friendly, avoids sharp corners snagging bracket walls.
- **Silkscreen**: white on top; minimal bottom (reference designators only if needed).

## Floorplan (sketch — not final layout)

```
 +-------------------------------------------------------------+
 |                  [AS5600 + magnet keepout 10×10]            |
 |                  [STM32G030 LQFP-32]                        |
 |  [TPL7407L]                  [SN65HVD75]                    |
 | [Buck + L + C]                                              |
 | [LDO]    [TVS + SM712 ESD]                                  |
 | [JST-XH 5-pin]                  [Backplane 2×3 box header]  |
 | [SWD pogo pads (4×)]                                        |
 +-------------------------------------------------------------+
   ← 75 mm →
    ↑
   35 mm
    ↓
```

## Key placement rules

1. **Backplane connector on the back-edge of the unit PCB.** Single 2×3 box header (2.54 mm pitch) carries V48/V48/GND/GND/A/B from backplane to unit. Unit slides perpendicular into backplane — no cables. Replaces the pre-2026-04-25 IN/OUT RJ45 scheme.
2. **AS5600 IC origin (0,0) reference point.** Mechanically defined by the 28BYJ-48 output shaft position on the final assembly. **The mechanical bracket is designed by the mech freelancer**, who hands the PCB designer a STEP file showing AS5600-to-shaft alignment. PCB designer hands back a STEP showing AS5600 IC center coordinate + mounting hole positions.
3. **Magnet keepout: 10 × 10 mm copper-free** zone on both layers around the AS5600 IC body. No ferrous material (screws, inductor cores, motor body) within 5 mm radial of the IC. With the backplane pivot, RJ45 shield cans are no longer on the unit — eliminates the closest pre-2026-04-25 ferrous-clearance concern.
4. **TPL7407L adjacent to JST-XH motor connector.** Short, direct traces to the stepper coils keep noise off the rest of the board.
5. **TPS54360DDA buck + inductor tightly grouped**, input cap within 2 mm of VIN, output cap between inductor and VOUT sense. Switch-node loop ≤ 5 mm. **Thermal pad on PowerPAD must connect to ≥ 6 vias into a ≥ 200 mm² bottom GND pour and ≥ 100 mm² top GND pour** (locked spec — TPS54360 in HSOP-8 PowerPAD comfortably hits ≤ 40 °C/W vs the 80 °C/W spec, unlike pre-2026-04-25 TPS54308 which had no thermal pad at all).
6. **TVS (SMAJ51A) near backplane connector +48 V pin entry.** Within 10 mm.
7. **ESD array (SM712) ≤ 5 mm from backplane connector A/B pin entry**, before trace reaches SN65HVD75.
8. **No termination on the unit** (was 120 Ω + jumper pre-2026-04-25). Termination lives on the backplane chain-end segment (PCBA stuffing variant).

## AS5600 integration

| Spec | Value |
|---|---|
| Magnet | 6 mm × 2.5 mm diametral cylinder, neodymium N35 or N42 |
| Position | Glued to a stub shaft extension on the 28BYJ-48 output shaft back-side |
| Airgap | 0.5 – 3 mm between magnet face and AS5600 IC face (target 1.5 mm) |
| Orientation | N-S axis perpendicular to rotation axis (diametral, not axial) |
| Ferrous exclusion | No ferrous material within 5 mm of IC |
| Calibration | First-boot stores "home angle" — the AS5600 reading when flap #0 is in home position |

The AS5600 reads absolute angle [0, 4095] per rotation, which means:
- **No magnetic sweep needed at boot** — position is known instantly.
- **Missed-step detection is continuous** — firmware compares commanded angle vs measured angle on every tick.
- **Recovery from power loss** — position is intrinsically re-established without mechanical homing.

The 28BYJ-48 output shaft is geared 64:1, so its rotation over the AS5600 corresponds to drum rotation directly. For a 45-flap drum, 1 flap = 360 / 45 = 8° of output-shaft rotation = 91 AS5600 counts. Sufficient angular resolution to distinguish every flap position with ~45× headroom.

## Mounting

- **2× M3 isolated through-holes**, diagonally placed near opposite corners.
- No copper connection to mounting holes (prevents ground-loop issues if bracket is conductive in a later revision).
- **Hole positions handed off via STEP exchange with mech freelancer** — they design the bracket-to-PCB interface and the bracket-to-MiddleFrame interface. PCB designer is downstream of bracket geometry. Default during PCB layout: holes on opposite short edges, midline-aligned, ≥ 5 mm from board edge.

## Motor cable entry

- JST-XH 5-pin vertical connector on the side of the PCB facing the motor body.
- Cable exits parallel to motor axis — length chosen for drum clearance without stress.
- Alternative right-angle variant available if a flat cable-exit is required by the bracket (same part family, different mount angle).

## Thermal considerations

| Source | Dissipation | θ_JA (locked) | Rise (ambient 40 °C) | T_J |
|---|---|---|---|---|
| TPL7407L SOIC-16 | ~50 mW (MOSFET R_DS(on) ~0.1 Ω × 300² mA) | 95 °C/W | 5 °C | 45 °C |
| HT7833 LDO SOT-89 | ~435 mW (worst-case logic) | 150 °C/W (with ≥80 mm² pad pour) | 65 °C | 105 °C |
| TPS54360DDA | ~440 mW (~88 % eff at 300 mA avg) | **≤ 40 °C/W (achievable on HSOP-8 PowerPAD with proper pour)** | 18 °C | **58 °C — comfortable margin** |

**Buck thermal spec — LOCKED 2026-04-25 with TPS54360DDA:**

- Minimum **6× thermal vias** (0.3 mm drill, 0.6 mm pad) directly under the TPS54360DDA's HSOP-8 PowerPAD thermal pad, dropped to a continuous ground pour on the bottom layer.
- Bottom-layer GND pour ≥ **200 mm²** contiguous around the thermal-via cluster.
- Top-layer GND pour around the buck IC ≥ **100 mm²**, connected to the bottom pour through ≥ 4 stitching vias at the perimeter.
- Both pours must reach all the way to the unit's mounting holes (additional thermal sink into the bracket if metallic).
- Resulting θ_JA target: **≤ 40 °C/W** (HSOP-8 PowerPAD with proper pour comfortably hits 30–40 °C/W). T_J at 300 mA avg + 40 °C ambient ≈ 58 °C. Massive headroom vs 125 °C abs-max — handles 60 °C ambient with no concern.

**Pre-2026-04-25 design specced TPS54308DBV (SOT-23-6) at "≤ 80 °C/W"** — that target was physically unachievable since SOT-23-6 has no exposed thermal pad (real θ_JA ≈ 165 °C/W → T_J ≈ 140 °C, exceeding abs-max). #76 audit caught the error; TPS54360DDA replacement resolves it.

No heatsinks needed. Natural convection sufficient at the projected duty cycle (flap units are idle most of the time).

## Enclosure assumptions

- 3D-printed plastic bracket carries the PCB behind the 28BYJ-48 motor.
- Plastic = no electromagnetic shielding, no ferrous interference with AS5600.
- LED visible through a small aperture on the enclosure (~2 mm) or via a light pipe. Placement of LED in floorplan should consider visibility.
- RJ45 connectors may or may not be flush with enclosure openings — depends on bracket design. Floor-plan assumes opposing-edge placement gives bracket-designer flexibility.

## Open issues (non-blocking)

- **M1** — Final mounting-hole positions pending 3D bracket design (mech freelancer hand-off via STEP).
- ~~**M2**~~ **Closed 2026-04-25.** With backplane pivot, the unit no longer carries RJ45s — the AS5600-to-RJ45-shield-can clearance concern is eliminated.
- ~~**M3**~~ **Closed 2026-04-25.** Buck swapped to TPS54360DDA (HSOP-8 PowerPAD). θ_JA ≤ 40 °C/W target with standard pour spec, vs the unachievable ≤ 80 °C/W on TPS54308DBV SOT-23-6.
- **M4** — Enclosure + flap-drum access + cable management — mech freelancer scope, out of PCB doc.
- ~~**M5**~~ **Closed 2026-04-25.** LED placement: handed off to mech freelancer with bracket STEP. PCB places LED on the back-edge of the unit so any case-back aperture can see it.
- **M6** — Panelization for 10-unit prototype: defer to JLC ordering. Break-off tabs preferred for hand-rework.
- ~~**M7**~~ **Closed 2026-04-25.** Termination moved to backplane; no shunt clearance needed on unit.

---

# Section 5 — UNIT_BRINGUP.md

# Unit PCB v2 — Bring-up procedure

> First-power sequence + per-test-point readings + standalone test mode. Created 2026-04-25.

## Pre-power inspection

1. Visual: verify the 2×3 backplane connector orientation matches the unit silkscreen (pin 1 marked).
2. Verify Q_REV (AO3401) source-on-input / drain-on-load orientation (corrected 2026-04-25 — pre-2026 had labels reversed).
3. Verify TPS54360DDA's HSOP-8 PowerPAD has the thermal-via cluster + ≥ 200 mm² bottom GND pour around it.
4. Verify TPL7407L is populated (NOT ULN2003 — the v2 spec is the MOSFET array).
5. Verify the AS5600's 10 × 10 mm magnet keep-out is genuinely free of copper / vias / ferrous components.
6. Verify SM712 ESD array on RS-485 lines (NOT SP0504BAATG — v2 spec).

## Standalone test (recommended) — bench-test a single unit without master/backplane

This mode exercises the unit using only a bench PSU and a USB-UART jig on the SWD pads.

### Setup
- Apply 48 V from a bench PSU directly to the unit's backplane connector pins 1, 3 (V48) and pins 5, 6 (GND). Use a 0.2 A current-limited supply to mimic the polyfuse.
- Plug a 28BYJ-48 motor (with magnet glued to the shaft end) into J_MOTOR.
- Connect a USB-UART (3.3 V) to the SWD pogo pads:
  - Pad 1 (PA13) → USB-UART RX
  - Pad 2 (PA14) → USB-UART TX
  - Pad 4 (GND) → USB-UART GND
  - Leave NRST floating (pull-up keeps it high).
- Open a serial terminal at 115200 baud.

### Expected
- 3.3 V rail comes up: STATUS LED enters 2 Hz blink (firmware running, awaiting address).
- Hold NRST low briefly to enter standalone test mode (firmware detects no SWD master and falls back to UART text protocol on the same pads).
- Terminal shows a banner: `UNIT v2 standalone mode. Type 'help' for commands.`

### Commands
- `id` → prints the STM32 96-bit UID (canonical address identity).
- `home` → spins motor until AS5600 detects the home reference angle; prints the angle reading.
- `step <N>` → advances motor by N steps (signed).
- `angle?` → prints the current AS5600 angle reading.
- `coil <N>` → energizes a single TPL7407L OUT_N for inspection.
- `reset` → soft-resets the unit.

### Pass criteria
- `id` returns a unique 96-bit UID.
- `home` completes within 3 s and reports a stable home angle.
- `step 100` rotates the motor smoothly without lost steps (verify by reading `angle?` before and after).
- `coil 1` through `coil 4` each energize one motor coil distinctly.
- I²C transactions to AS5600 succeed (no NACK errors).

## In-system test (with master + backplane)

1. Slot the unit into a backplane slot.
2. Power up the master and trigger UID-based discovery.
3. Verify the unit's status LED transitions: 2 Hz (awaiting address) → solid (enumerated/idle).
4. Master sends a `step` command; unit responds within ~100 ms.
5. Verify INA237 on master reports the unit's current draw is ~25 mA at idle, ~100 mA peak during stepping.

## Common bring-up faults

| Symptom | Likely cause |
|---|---|
| 3.3 V missing, 12 V present | LDO HT7833 fault — check SOT-89 thermal pad pour, check input/output 1 µF caps are NOT the same LCSC (pre-2026-04-25 bug) |
| 3.3 V missing, 12 V also missing | Buck not switching — verify C_BOOT_BUCK (100 nF / 25 V X7R) is populated CBOOT-to-SW within 2 mm; verify Q_REV is conducting (gate pulled to GND through 10 kΩ) |
| Unit draws current with reversed V48 polarity | Q_REV labels reversed — check AO3401 source vs drain on schematic against 2026-04-25 corrected topology |
| AS5600 NACKs on every I²C read | DIR pin floating, or RC filter wrong, or buck switch noise coupling — verify 100 Ω + 100 pF RC filter is between MCU and AS5600 SDA/SCL |
| AS5600 readings noisy (>10 LSB jitter) | Magnet too far from IC face (>3 mm air gap), or ferrous component in the keep-out zone |
| Stepper hums but doesn't advance | TPL7407L unused inputs IN5–IN7 floating — verify they're hard-tied to GND copper, NOT through 10 kΩ |
| Unit doesn't enumerate over RS-485 | Verify SN65HVD75 VCC = 3.3 V, A/B differential at idle should be ≈ 200–400 mV (master bias driving) |
| RS-485 traffic visible on scope but unit ignores it | UART baud wrong (must be 500 kbaud 8N1) or COBS framing decoder error |

## Stepping current measurement (mandatory at first prototype)

Per scottbez1 audit, the v1 estimate of 74 mA hold current may underestimate stepping peaks. With a current probe (or by measuring across a low-side shunt added temporarily in series with the V48 input), capture:
- Idle current (motor not stepping): expect ~25 mA.
- Stepping current peak: expect 200–400 mA (vs the 74 mA assumption).
- Stepping current average over a full rotation: expect 80–150 mA.

If stepping peak exceeds ~600 mA, the unit's buck inductor (Isat ≥ 1 A spec) and the backplane's 0.2 A polyfuse are inadequate — escalate to firmware for current-limited stepping or to a higher-rated inductor + 0.5 A polyfuse.

