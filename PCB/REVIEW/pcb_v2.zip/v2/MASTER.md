# Master PCB — Consolidated Design Brief

> Concatenated for the ChatGPT review bundle. Original split (per-section files) lives in the repo at `PCB/v2/` (`MASTER_DECISIONS.md`, `POWER_DESIGN.md`, `DIGITAL_DESIGN.md`, `MECHANICAL_DESIGN.md`, `MASTER_BRINGUP.md`).

**Reading order below: Decisions (source of truth) → Power → Digital → Mechanical → Bring-up.**

---

# Section 1 — MASTER_DECISIONS.md (source of truth)

# Master PCB v2 — locked design decisions

> **Single source of truth for the master PCB.** Design agents bind to this file ONLY. No other file in this repo is authoritative for the v2 master design.
>
> Last edited: 2026-04-25 (post-review pivot to backplane architecture; see issue #76).

## System shape

- **Single MCU**: ESP32-S3-WROOM-1-N16R8 (16 MB flash, 8 MB Octal PSRAM), soldered SMD.
- **No second MCU / radio coprocessor on the master board.** S3's native Wi-Fi + BLE covers connectivity needs; no Zigbee/Thread on-board.
- **No decorative LED bar.** Health indicators only.
- **4 RJ45 ports on master**, each driving an RS-485 chain of cases. **One case = 16 units on a backplane** (see `BACKPLANE_DESIGN.md`). Max 2 cases per chain (per the bus inrush budget at C_dVdT = 100 nF), so 4 × 2 × 16 = **128 units max** across the master.
- **Architecture pivot (2026-04-25):** units are no longer daisy-chained jack-to-jack via CAT6. Each case carries a backplane that distributes the bus to its 16 unit-slots; only the case has external RJ45s. Master ↔ backplane and case-to-case use shielded CAT5e/6 patch cables. Unit-side termination, IN/OUT polarity, per-unit RJ45s are obsolete.
- **Address discovery: UID-based.** Each unit's STM32G030 96-bit factory UID is the identity. Master broadcasts a 1-Wire-style binary-tree search over RS-485, persists the resulting UID→short-address map in NVS (warm boot ~100 ms; cold first-ever boot 5–20 s for 32 units). DIP switches and wake-pin schemes are explicitly rejected. RJ45 pin 1 is `NC reserved` on both master and case.
- **Cabling standard**: shielded CAT5e or CAT6 (S/FTP or F/UTP), straight-through, T568B. RJ45 shielded connectors, no magnetics. **Max 32 m total per chain, max 3 m per hop, ≤7 V worst-case IR drop** at full bus current.

## RJ45 pinout (passive PoE-compatible — 802.3at Mode B convention)

This board follows the **IEEE 802.3at Mode B pinout convention** for power delivery, so it uses standard PoE-style pin assignments. It is NOT a true PoE PSE — there is no detection/classification handshake. A real 802.3af/at/bt switch will refuse to energize the cable (no PD signature present), which is safe behavior. Power is supplied by the master itself, always on (within eFuse limits).

| Pin | T568B wire color | Net | Notes |
|---|---|---|---|
| 1 | white-orange | NC (reserved) | Standard Mode B leaves pair 1/2 for Ethernet data — not used in this design |
| 2 | orange | NC (reserved) | " |
| 3 | white-green | RS-485 A | Green pair (3/6) is a true twisted pair in CAT6 — suitable for differential |
| 4 | blue | +48V | Blue pair (4/5) = Mode B V+ (paralleled for ~3 A conductor capacity) |
| 5 | white-blue | +48V | paralleled with pin 4 |
| 6 | green | RS-485 B | paired with pin 3 |
| 7 | white-brown | GND | Brown pair (7/8) = Mode B V− (paralleled) |
| 8 | brown | GND | paralleled with pin 7 |

**Cable requirement**: straight-through only (pin N → pin N). Crossover cables will short +48V to GND and damage both master and the first unit. All cables shipped/recommended with the system must be straight-through CAT5e/CAT6 patch cables.

**Current capacity over CAT6 (24 AWG)**: each conductor ~1.5 A; paralleled pair ~3 A. eFuse trip at 1.7 A per bus leaves ~75% headroom on the power pairs.
- **Max 128 units per master** (4 buses × 32 units).

## Power architecture

| Item | Decision |
|---|---|
| Input | 48 V DC barrel jack, 5.5 / 2.5 mm, 60 V rated |
| Reverse-polarity & ideal-diode | LM74700-Q1 ideal-diode controller + external N-MOSFET (Q1 = SQJ148EP, 100 V / 9 mΩ). FAULT pin → ESP32 GPIO via PROT_FAULT_OR. **1 kΩ series on GATE** (per TI SLUA975) for stability against Q1 Q_g ringing. |
| Input TVS | SMDJ58CA bidirectional (3 kW / 1 ms) at the barrel jack. The earlier R_SERIES + D_SEC secondary-clamp chain is **deleted (2026-04-25)** — its 47 Ω in series with the main rail dissipated ~950 W steady at 4.5 A, an architectural error. Replaced by reliance on LM74700-Q1's native overvoltage-protection behaviour per TI app note SLVA936. |
| V48_RAIL clamp | **Single SMAJ51A on V48_RAIL** (post-Q1 source), within 10 mm of Q1, sinking the surge-tail current that flows forward through Q1's body during a SMDJ58CA clamp event. Holds V48_RAIL ≤ ~57 V at low-end tail current — within LMR36015 V_IN abs-max (65 V), TPS259827 V_IN abs-max (60 V transient 65 V), and INA237 V_CM (85 V). |
| FAULT LED isolation | **BSS138 N-MOSFET inverter** drives FAULT LED from PROT_FAULT_OR, so the wired-OR line sinks only the 10 kΩ pull-up (~0.33 mA) — stays within LM74700's 1 mA FAULT I_OL spec. Locked 2026-04-25 (was open issue P4). |
| Rail architecture | **Single buck 48V → 3V3** via **LMR36015 (adjustable, FDDA = HSOIC-8 PowerPAD)** (60 V sync buck, 1.5 A, 2.1 MHz). FB divider populated for 3.3 V (P2 resolved: FDDA suffix is package code, base part is adjustable). **C_BOOT = 100 nF / 25 V X7R 0402** mandatory from CBOOT to SW pin within 2 mm. No 5 V rail. Every IC (ESP32-S3, MAX14830, SN65HVD75, INA237) is 3V3-native. USB-VBUS isolated from board rails. |
| Per-bus protection | **TPS259827YFFR eFuse per bus (×4)**. 60 V rated, adjustable I_LIM (~1.7 A), ENABLE + FAULT + PGOOD. Package = DSBGA-10 (0.4 mm pitch chip-scale). Hard pre-fab gate retained: confirm JLC standard-tier PCBA on DSBGA-10 0.4 mm pitch, else use fallback TPS25981QWRPVRQ1 (WQFN-12 3×3 mm) — layout includes both footprints, choice at BOM-freeze. **C_dVdT per bus = 100 nF** (was 10 nF pre-2026-04-25; bumped to give 28 ms ramp / ~1.4 A inrush against 1.7 A trip on a 32-unit bus with ~800 µF aggregate input cap). |
| Per-bus current telemetry | INA237AIDGSR per bus (×4), 50 mΩ high-side shunt, I²C. Addresses 0x40–0x43. **VBUS divider = 10 kΩ / 1 kΩ** (was 100 kΩ / 10 kΩ pre-2026-04-25; bumped to preserve 16-bit accuracy from INA237 input bias). 8 mW dissipation per bus at 48 V — acceptable. |
| Per-bus enable sequencing | At master boot, firmware sequences each bus enable serially: assert EFUSE_EN_n, wait for PGOOD, read INA237 settling current (≤ 200 mA after 50 ms = healthy). Refuse to leave bus enabled if INRUSH_NOT_SETTLED. Pattern adopted from scottbez1 Chainlink Base supervisor (#76 audit). |

**Cost note (flagged by user):** per-bus eFuse is ~€10 total across 4 buses. Accepted for safety. **Revisit candidate** if a later cost-trim pass is needed — fallback would be polyfuse + INA237-ALERT-driven software cutoff.

## Inter-chip communication

- **RS-485 UART expansion**: **1× MAX14830** (4 UARTs over SPI). All 4 bus UARTs live on this chip, NOT on the S3 native UARTs.
  - Shared SPI bus to S3: MOSI / MISO / SCK / CS / IRQ = 5 ESP32 GPIOs
  - **VEXT pin tied to 3V3** (I/O level reference) with its own 100 nF decoupling. Locked 2026-04-25.
- **RS-485 transceivers**: 4× SN65HVD75D (3.3 V, half-duplex), one per bus. DE/RE driven by MAX14830 per-channel DE pin (hardware-assisted, no firmware per-byte toggling).
- **RS-485 wire format (locked 2026-04-25):**
  - **Baud: 500 kbaud 8N1** (matches unit-side SN65HVD75 capability and 32 m chain SI margin).
  - **Framing: COBS(payload || CRC16-BE) 0x00**, reusing `firmware/lib/common/` from the v1→v2 firmware split. 4-byte header `[ver][type][addr_hi][addr_lo]`.
  - **Failsafe bias: 1 kΩ each leg** (master side only; unit/backplane do NOT bias). Idle differential ~280 mV — comfortably above SN65HVD75 200 mV failsafe threshold. Bias resistance bumped from 390 Ω (pre-2026-04-25) to reduce bus loading and idle current to 1.6 mA per bus.
  - **Termination: 120 Ω at master and at chain-end backplane** (PCBA stuffing variant on backplane).
  - **Message-type design includes broadcast + batched-update frames from day one** (post-#76 audit): `BROADCAST_SET_POSITION`, `BATCH_UPDATE` (start..end address range, single payload). Enables future sync animation across all units without a protocol rev.
  - **Loopback integrity frame**: master can send a special address-N loopback frame; the addressed unit echoes back. Allows end-to-end chain validation at boot. Pattern adopted from scottbez1's SR loopback bits.
- **Address discovery (locked 2026-04-25): UID-based binary-tree search over RS-485.** Each STM32G030 unit's 96-bit factory UID is its identity. Master broadcasts prefix-match queries; collisions show up as CRC fails and master narrows the prefix. Once enumerated, master assigns a 1-byte short address per unit and persists the UID→short-address map in NVS (also: UID→physical-slot map for calibration continuity across re-flashes). Cold first-ever boot ~5–20 s for 32 units; warm boot ~100 ms. RJ45 pin 1 is `NC reserved` on both master and case-side backplane — there is no wake-pin scheme.
- **Telemetry**: 4× INA237 on I²C bus (internal to the master — not exposed off-board). Addresses 0x40–0x43.
- **eFuse control**: 4× eFuse ENABLE pins driven by **direct ESP32-S3 GPIOs** (one per bus, firmware sequences bus-on at boot, waits for PGOOD + INA237 inrush settle, refuses if INRUSH_NOT_SETTLED). Each EN line is gated by a **TPS3839L33 3V3 POR supervisor** via 4× BAT54 Schottky diodes plus a 100 nF RC filter — eFuses are held OFF during 48 V brown-in until 3V3 is healthy AND firmware drives the GPIO. See `DIGITAL_DESIGN.md` §3j. **BAT54 polarity (corrected 2026-04-25): anode at /RESET, cathode at EFUSE_EN_n** (was reversed in pre-audit revision).
- **Fault aggregation**:
  - **PROT_FAULT_OR** — wired-OR of LM74700-Q1 FAULT + 4× eFuse FAULT → 1 ESP32 GPIO (IRQ). Drives FAULT LED via BSS138 inverter (so OR line only sinks the pull-up). Firmware reads individual status via INA237 voltage readback correlation + eFuse state knowledge.
  - **TELEM_ALERT_OR** — wired-OR of 4× INA237 ALERT → 1 ESP32 GPIO (IRQ). Firmware polls all 4 INA237s over I²C to identify which fired.
- **USB**: USB-C connector wired to ESP32-S3 native USB (IO19/IO20) for flash + debug + CDC. **Note for layout: IO19/IO20 are also strap pins for USB_JTAG vs UART download mode** — verify boot mode is unaffected by USB host presence at module reset.
- **SWD**: 1.27 mm 2×5 Cortex-debug header (JTAG on ESP32-S3).
- **No expansion header.** The master has no off-board connector for daughterboards. Future Zigbee/Thread/radio support would require a board rev or soldering wires to test pads on the native UART1/UART2 pins.

## LED set (8 total)

| # | Label | Driven by | Color | Visible without firmware |
|---|---|---|---|---|
| 1 | PWR_48V | Hardwired on 48 V via resistor | Red | ✅ |
| 2 | PWR_3V3 | Hardwired on 3V3 via resistor | Green | ✅ |
| 3 | FAULT | Hardwired on PROT_FAULT_OR node (OR of LM74700 FAULT + 4× eFuse FAULTs) | Red | ✅ |
| 4 | HEARTBEAT | ESP32-S3 GPIO. Encodes firmware liveness + WiFi status via blink pattern: off = dead; 2 Hz fast = booting/connecting; 1 Hz steady = running + WiFi up; 0.5 Hz slow = running + WiFi down/AP mode. | Blue | ❌ |
| 5 | BUS_ACT_1 | MAX14830 GPIO tied to channel-1 TX activity | Green | Partial (TX-time) |
| 6 | BUS_ACT_2 | MAX14830 GPIO tied to channel-2 TX activity | Green | Partial |
| 7 | BUS_ACT_3 | MAX14830 GPIO tied to channel-3 TX activity | Green | Partial |
| 8 | BUS_ACT_4 | MAX14830 GPIO tied to channel-4 TX activity | Green | Partial |

All 0603 SMD, fixed colors (no RGB). No dedicated WIFI LED — status encoded into HEARTBEAT blink pattern.

## Connectors

| Connector | Part class | Count |
|---|---|---|
| Power input | Barrel jack 5.5/2.5 mm, 60 V rated | 1 |
| Bus ports | Shielded THT RJ45, no magnetics | 4 |
| USB | USB-C receptacle | 1 |
| SWD | 1.27 mm 2×5 Cortex-debug header | 1 |
| Buttons | Tactile 6×6 SMD (RESET, BOOT) | 2 |

No expansion header / off-board I²C exposure / daughterboard socket. Master is a closed-function controller.

## GPIO budget (ESP32-S3-WROOM-1-N16R8)

### Available GPIOs on the N16R8 module

- Exposed IO pins on N16R8: IO0–IO21 + IO38–IO48 = 33 physical pins (IO33–IO37 consumed internally by Octal PSRAM).
- Minus hardware-fixed assignments:
  - IO19, IO20 → USB D+/D− (native USB, mandatory)
  - IO39, IO40, IO41, IO42 → JTAG/SWD (mandatory)
  - IO43, IO44 → UART0 console (policy-reserved; not remapped)
  - IO3, IO45, IO46 → strap pins, no copper escape
  - IO48 → glitch-prone, policy-avoided
- **General-purpose GPIOs available: 21.**

### Demand

| Function | Pins |
|---|---|
| SPI to MAX14830 (MOSI, MISO, SCK, CS, IRQ) | 5 |
| I²C bus (SDA, SCL) for INA237 bank | 2 |
| eFuse ENABLE × 4 (direct, firmware-sequenced bus-on) | 4 |
| PROT_FAULT_OR (wired-OR of LM74700 FAULT + 4× eFuse FAULT) | 1 |
| TELEM_ALERT_OR (wired-OR of 4× INA237 ALERT) | 1 |
| HEARTBEAT LED (on S3, not on MAX14830 — independent of downstream chip health) | 1 |
| **Total assigned** | **14** |
| **Spare** | **7** |

Spare pool (7 pins) reserved with 10 kΩ pull-ups + test pads for future signals. No new function gets assigned without a justification commit here.

### GPIO allocation policy (locked)

1. **Single owner per GPIO** unless explicitly a shared bus (SPI, I²C).
2. **UART0 (IO43/IO44) reserved** for boot/recovery/console. Not remapped at runtime.
3. **Strap pins IO3, IO45, IO46 no-route** beyond the module pad.
4. **IO48 unassigned** (policy avoid; acceptable use limited to non-critical test pad).
5. **INA237 ALERT lines wire-OR'd** onto a single TELEM_ALERT_OR pin (not 4 separate pins). Firmware identifies which fired via I²C poll of each INA237.
6. **eFuse FAULTs + LM74700 FAULT wire-OR'd** onto a single PROT_FAULT_OR pin. FAULT LED driven via BSS138 inverter (does NOT load the OR line directly).
7. **Pin numbers locked (2026-04-25)** in `DIGITAL_DESIGN.md` §2. Allocation: SPI to MAX14830 on IO10–14, I²C INA237 bank on IO8/9, eFuse EN on IO4–7, fault aggregation on IO15/16, HEARTBEAT on IO21. Spare pool = 7 pins (IO1, 2, 17, 18, 38, 47 + slack).

## Mechanical decisions (now locked)

- **Board dimensions: 130 × 100 mm** (full derivation in `MECHANICAL_DESIGN.md` §1).
- **Layer count: 4** (1.6 mm FR-4, ENIG finish, 1 oz outer / 0.5 oz inner). **V48 distribution lives on L1 only** — inner layers carry signal/GND only, not V48 (locked 2026-04-25 to keep the 0.5 oz inner thermally safe at 6.8 A fault).
- **Antenna keep-out: 18 × 15 mm** copper-free zone at the top edge, all 4 layers. Module does **not** overhang — kept fully on-board for shipping durability.
- **Mounting: 4× M3 corner holes**, positions (6, 94), (124, 94), (6, 22), (124, 22) measured from the bottom-left of the 130 × 100 board (locked 2026-04-25 — moved inboard from 5/95 to clear the 21 mm RJ45 keep-out and to give 2 mm minimum edge clearance on exclusion rings). Isolated pads, 0 Ω star-ground DNP per corner.
- **Enclosure**: custom user-fabricated, 130 × 100 mm PCB sized for desktop project boxes (Hammond 1455N family fits). Designed-to-fit approach: enclosure follows PCB, not the other way round.

## Prototype / production target

- **Prototype run: 5 boards**, JLC PCBA assembly path, user-fabricated enclosure (project-box class, e.g. Hammond 1455N).
- **Not production-ready.** Parts marked `CHECK` in the BOM are acceptable for the prototype run; LCSC re-verification is delegated to the ChatGPT BOM pass (#75).
- **Schematic capture path**: KiCad preferred to enable the **KiBot + kikit production pipeline** (CI-driven JLCPCB output, LCSC alt-part fields per component). Adopted post-#76 audit from scottbez1 — solves the "BOM numbers known-wrong" failure mode mechanically rather than editorially.

## Design artifacts (in this directory)

- `MASTER_DECISIONS.md` (this file) — source of truth; agents bind to this only.
- `POWER_DESIGN.md` — power subsystem schematic-level detail.
- `DIGITAL_DESIGN.md` — digital subsystem + complete ESP32-S3 pin allocation.
- `MECHANICAL_DESIGN.md` — placement brief, stack-up, zones, diff-pair rules.
- `MASTER_BOM.csv` — JLC-native BOM (Designator, Comment, Footprint, LCSC Part #, MPN, Manufacturer, Qty, JLC_Tier, Populate, EstEUR, DatasheetURL, Notes, BomType).
- `MASTER_BRINGUP.md` — first-power sequence + per-test-point readings + JLC PCBA verification steps.

## Still deferred (non-blocking, resolvable at schematic capture or fab-time)

Most pre-2026-04-25 open items are now resolved by the post-review revision. Remaining:
- **P3 — TPS259827YFFR I_LIM constant (K_ILIM).** Datasheet rev varies; pin R_ILIM at fab-time against the rev current then.
- **M3 closed (enclosure)** — designed-to-fit project-box class.
- **M5 closed (shield bond)** — master solid bond, unit/backplane float.
- **M6 closed (RJ45 pin-1 indicator)** — promoted to silkscreen must-have.
- **M9 closed (surge-clamp chain)** — simplified to single SMAJ51A on V48_RAIL after R_SERIES deletion.

## BOM / sourcing gates from external review

Bound on every part decision below. All notes apply to the master BOM (`MASTER_BOM.csv`) and propagate to schematic-capture and PCBA freeze.

- **C-numbers are not trusted unless marked `REVIEW_VERIFIED`** in the BOM Notes column. Treat any other LCSC entry as advisory only.
- The following remain **hard `CHECK`** items pending live JLC BOM-uploader verification — do not order without explicit confirmation:
  - `LMR36015AFDDA` (U2)
  - `TPS259827YFFR` (U3–U6, primary eFuse)
  - `TPS25981QWRPVRQ1` (U3_ALT–U6_ALT, fallback eFuse)
  - `TPS3839L33DBVR` (U_POR) — `TPS3823-33DBVR = C7719` is **not** a blind drop-in; pinout, reset delay, output topology, and boot sequencing differ
  - `INA237AIDGSR` (U7–U10) — `INA226AIDGSR C49851` is **not** a blind substitute (VBUS/divider/common-mode limits + register map differ)
  - `MAX14830ETJ+` (U12) — **major BOM/sourcing risk**; `MAX14830ETM+T C2653202` is package-mismatched; do not substitute without footprint/pinout review
  - `SQJ148EP` (Q1) — old `C2836025` resolved to a different MOSFET; confirm Rds(on), Vds, package, thermal pad, SOA before order
- **`TPS259827YFFR` DSBGA-10 0.4 mm pitch is a pre-fab JLC PCBA gate**, not a routine detail. Must clear DSBGA acceptance with JLC standard-tier PCBA before tape-out, else swap to the WQFN-12 fallback footprint already placed on the board.
- **If exact parts cannot be sourced, do not silently substitute package variants** — every package change must be re-validated against pinout, footprint, thermal pad, and PCBA process at minimum.

## LAYOUT_CONSTRAINT: master pre-layout checklist

Layout engineer must clear all of these before accepting routing scope:

- **Stackup + impedance**: exact JLC stackup (4-layer 1.6 mm, 1 oz outer / 0.5 oz inner, ENIG) and controlled-impedance targets (RS-485 differential, USB D+/D−) locked before routing — not negotiated mid-route.
- **USB D+/D−** routed as 90 Ω differential pair, length-matched, over solid GND reference, with USBLC6-2SC6 in-line at the connector.
- **RS-485 A/B pair routing** as 120 Ω differential pair, length-matched, on L1 over solid L2 GND, with the Würth 744232601 common-mode choke and SM712 ESD placed close to the RJ45 connector. **Termination + bias resistors close to MAX14830/PHY side or RJ45 side as the SI analysis dictates** — locked before fab.
- **ESP32-S3 antenna keep-out** (18 × 15 mm, all 4 layers, no copper / no traces / no vias) copied **exactly** onto the mechanical/silkscreen layer and onto the enclosure interior.
- **RJ45 shield/ESD return strategy** documented on the layout: master is the sole shield-bond point system-wide; downstream RJ45 shields float; ESD return path explicitly identified.
- **48 V high-current path** width, copper weight, thermal vias, and clearance rules documented for the L1 V48 distribution islands. ≥ 0.4 mm pre-clamp / ≥ 0.2 mm post-clamp creepage. No V48 on inner layers.
- **Test points** (1 mm SMD pads, edge-accessible where possible) on: V48_IN, V48_RAIL, each eFuse VOUT, each EFUSE_EN_n, each PGOOD_n, INA237 I²C SDA/SCL, MAX14830 SPI MOSI/MISO/SCK/CS, MAX14830 IRQ + RESET, each RS-485 TX/RX/DE, 3V3, multiple GND.
- **Fiducials** (≥3, diagonal + asymmetric third), tooling holes, PCBA top/bottom-side allocation, and panelization constraints (kikit-friendly tabs + mouse-bites) documented before tape-out.

## REVIEW_STRONG_OPINION: 4-bus master architecture

The 4-bus MAX14830 architecture is technically workable but expensive and sourcing-risky. If 128 units is not a real near-term requirement, a 2-bus ESP32-S3-native UART master is cheaper and easier (no MAX14830, fewer eFuses, fewer INA237s, smaller PCB). Architecture remains locked unless owner reopens scope.

## REVIEW_SAFETY: passive 48 V over RJ45 labelling

Passive 48 V over RJ45 must be labelled as **NOT Ethernet/PoE**. Required:

- Silkscreen at every RJ45: **"PASSIVE 48V — NOT ETHERNET"**.
- Coloured/keyed cables preferred over generic CAT5e/CAT6 patch cords (e.g. yellow or red jackets) to discourage installation into a shared patch panel.
- Avoid any patch-panel installation language in user-facing docs. The system uses RJ45 connectors but is **not** a structured-cabling product.

---

# Section 2 — POWER_DESIGN.md

# Master PCB v2 — Power Subsystem Design

> Derived solely from `MASTER_DECISIONS.md`. Covers barrel input → V48_RAIL → 3V3_RAIL, per-bus eFuses, INA237 high-side shunts, hardwired health LEDs, PROT_FAULT_OR node. Digital side (MCU, MAX14830, SN65HVD75, USB, SWD) is out of scope — signals crossing the boundary are listed in §4.
>
> Last edited: 2026-04-25 (post-review surge chain simplification + per-bus inrush fix; see issue #76).

## 1. Block diagram

```
 DC_JACK (48 V, 5.5/2.5 mm, 60 V)
   │
   ├── SMDJ58CA (bidir TVS, V_BR=64.4 V, V_C=93 V @ 51 A) — primary surge-facing clamp
   │
   ├── LM74700-Q1 ideal-diode controller (1 kΩ on GATE)
   │   + Q1 external N-MOSFET (SQJ148EP, 100 V, R_DS(on)≈9 mΩ)
   │       │ FAULT ───────────────────────────────────┐
   │       ▼                                          │
 V48_RAIL (reverse-blocked, ~47.5 V typ)              │
   │                                                  │
   ├── D_RAIL: SMAJ51A directly on V48_RAIL ──────────┤  (sole secondary clamp;
   │   (V_BR ~57 V tail; protects eFuse & INA237)     │   per TI SLVA936 — the
   │                                                  │   pre-2026-04-25 R_SERIES
   ├──► BULK: 2× 47 µF / 100 V AL-poly + 4.7 µF MLCC  │   + D_SEC chain is deleted)
   │                                                  │
   ├──► LMR36015 buck (FDDA = HSOIC-8 PowerPAD; FB divider for 3V3) ──► 3V3_RAIL (1.5 A cap, ~750 mA peak)
   │       └── C_BOOT 100 nF / 25 V X7R 0402 from CBOOT to SW (mandatory)
   │                                                  │
   ├──► PWR_48V LED (red) via 22 kΩ                   │
   │                                                  │
   ├──► R_SHUNT1 50 mΩ ─► TPS259827 #1 ─► RJ45_1 VBUS │ FAULT1 ─┐
   ├──► R_SHUNT2 50 mΩ ─► TPS259827 #2 ─► RJ45_2 VBUS │ FAULT2 ─┤
   ├──► R_SHUNT3 50 mΩ ─► TPS259827 #3 ─► RJ45_3 VBUS │ FAULT3 ─┤
   └──► R_SHUNT4 50 mΩ ─► TPS259827 #4 ─► RJ45_4 VBUS │ FAULT4 ─┤
          │   │   │   │   (each: C_dVdT = 100 nF for  │         │
          │   │   │   │    32-unit ~800 µF inrush     │         │
          │   │   │   │    against 1.7 A trip)        │         │
          └───┴───┴───┴──► 4× INA237 (I²C, 0x40..0x43)│         │
                          (VBUS divider 10 k / 1 k)   │         │
                                                      │         │
                              PROT_FAULT_OR ◄─── wired-OR ◄─────┘
                                   │
                                   ├── 10 kΩ pull-up to 3V3
                                   ├── BSS138 inverter ──► FAULT LED
                                   └── ESP32 GPIO (IRQ, input only)

 3V3_RAIL ──► PWR_3V3 LED (green) via 680 Ω
```

## 2. Component selection table

| Ref | Function | Part | LCSC | Package | Key params | €/pc | JLC |
|---|---|---|---|---|---|---|---|
| D1 | Input TVS | SMDJ58CA | C145194 | DO-214AB (SMC) | Bidir, V_WM=58 V, V_BR=64.4 V, V_C=93 V @ 51 A, 3 kW | 0.45 | Extended |
| U1 | Ideal-diode ctrl | LM74700-QDBVRQ1 | C2941042 | SOT-23-6 | 3.2–65 V, 20 µA I_Q, FAULT open-drain | 1.30 | Extended |
| Q1 | Reverse-block N-FET | SQJ148EP-T1_GE3 | CHECK | PowerPAK SO-8 | V_DS=100 V, R_DS(on)=9 mΩ @ V_GS=10 V, Q_g=44 nC | 1.40 | check |
| R_GATE_LM | LM74700 GATE series | 1 kΩ 1% 0603 | C22929 | 0603 | TI SLUA975 stability vs Q_g ringing | 0.01 | Basic |
| D_RAIL | V48_RAIL clamp | SMAJ51A | C8678 | SMA | Sole secondary clamp post-LM74700 (P1 closed 2026-04-25) | 0.20 | Basic |
| U2 | 48→3V3 buck | LMR36015AFDDA | CHECK | HSOIC-8 PowerPAD | 4.2–60 V_in, 1.5 A, 2.1 MHz, adjustable FB | 2.10 | Extended |
| C_BOOT | LMR36015 bootstrap | 100 nF / 25 V X7R 0402 | C1525 | 0402 | CBOOT to SW, ≤2 mm placement | 0.01 | Basic |
| L1 | Buck inductor | XAL5030-333MEB (33 µH, 1.7 A_sat, 245 mΩ) | C2834984 | 5.3×5.3×3.0 mm shielded | I_sat ≥ 1.7 A, DCR ≤ 250 mΩ | 0.90 | Extended |
| C_IN48 | V48 bulk (AL-poly) | 47 µF / 100 V Nichicon PCV | C2843372 | 10×10 SMD | 100 V, 105 °C, ESR ~30 mΩ | 0.75 | check |
| C_IN48x | V48 HF decap | GRM32ER72A475K (4.7 µF / 100 V X7R) | C1778 / C2832225 | 1210 | 100 V rating on unfiltered rail | 0.35 | Extended |
| C_OUT3V3 | 3V3 output cap | GRM188R71A225K (2.2 µF / 25 V X7R) ×2 | C1804 | 0603 | Low ESR | 0.03 | Basic |
| U3..U6 | eFuse (×4) | TPS259827YFFR | CHECK | DSBGA-10 | 4.2–60 V, I_LIM adj, EN/FAULT/PGOOD | 2.50 | Extended |
| U7..U10 | Current monitor (×4) | INA237AIDGSR | CHECK | VSSOP-10 | ±163.84 mV FSR, 16-bit, ALERT, I²C | 1.80 | Extended |
| R_SH1..4 | Shunt (×4) | CSR2512-50-1% (50 mΩ, 3 W, 2512) | C157950 | 2512 Kelvin | 50 mΩ ±1%, 3 W | 0.25 | Extended |
| LED1 | PWR_48V | 0603 red, V_F≈1.9 V, I_F=2 mA | C2286 | 0603 | — | 0.02 | Basic |
| LED2 | PWR_3V3 | 0603 green, V_F≈2.0 V, I_F=2 mA | C72043 | 0603 | — | 0.02 | Basic |
| LED3 | FAULT | 0603 red, V_F≈1.9 V, I_F=2 mA | C2286 | 0603 | — | 0.02 | Basic |
| R_LED_48V | 22 kΩ / 0805 / ≥0.125 W | 22 kΩ 1% 0805 (250 V WV) | C17673 | 0805 | Drops ~46 V, 96 mW | 0.01 | Basic |
| R_LED_3V3 | 680 Ω 1% 0603 | — | C23243 | 0603 | 2 mA @ 3.3 V | 0.01 | Basic |
| R_PULL_PF | 10 kΩ 0603 (PROT_FAULT_OR) | — | C25804 | 0603 | pull-up to 3V3 | 0.01 | Basic |

All parts that sit on V48_RAIL unfiltered are ≥100 V rated except the LM74700-Q1 (65 V abs-max) — **called out in §7**.

## 3. Sub-circuits

### 3a. Input protection (barrel → V48_RAIL)

> **Architecture simplified 2026-04-25 (issue #76 audit).** The earlier R_SERIES + D_SEC secondary-clamp chain has been **deleted**. Reason: 47 Ω in series with the main rail dissipates 47 × 4.5² ≈ 950 W steady at 4.5 A bus current — an architectural error that no part choice could fix. The replacement design relies on LM74700-Q1's native overvoltage protection per TI app note SLVA936 plus a single SMAJ51A (`D_RAIL`) clamping V48_RAIL post-Q1.

- **Topology**: DC jack → SMDJ58CA (shunt to GND) → drain of Q1 (SQJ148EP) → LM74700-Q1 controller → V48_RAIL → D_RAIL (SMAJ51A to GND). No series element in the main current path.
- **TVS**: SMDJ58CA, V_WM=58 V (above 48 V nominal), V_BR=64.4 V min, V_C=93 V @ 51 A peak. At full 3 kW / 1 ms pulse the input node clamps at ~93 V; LM74700's overvoltage protection pulls Q1's GATE low, isolating V48_RAIL from the surge tail. After Q1 turns off, V48_RAIL is held by D_RAIL (SMAJ51A) at ~57 V worst-case tail current — within LMR36015 / TPS259827 / INA237 ratings.
- **Q1**: SQJ148EP chosen for 100 V V_DS, 9 mΩ R_DS(on). At 2 A bus load (worst case: one shorted bus at I_LIM), I²R = 2² × 0.009 = 36 mW. Negligible self-heat; no pour needed.
- **LM74700-Q1 passives**: C_CAP pin → 100 nF X7R to GND (charge-pump reservoir). **GATE → 1 kΩ series resistor (R_GATE_LM)** to Q1 gate per TI SLUA975 (stability vs Q1's 44 nC Q_g ringing); was 0 Ω pre-2026-04-25. 10 kΩ gate-source bleed. FAULT → 10 kΩ pull-up to 3V3 on PROT_FAULT_OR node (§3f).
- **D_RAIL clamp (only secondary clamp)**: SMAJ51A on V48_RAIL within 10 mm of Q1's source pad. V_BR ≈ 56.7 V min, V_C ≈ 82 V at full surge current, drops back to ~51–57 V at low surge-tail current. Catches the residual surge tail that flows forward through Q1's body during the SMDJ58CA clamp event. 400 W pulse rating handles the worst-case tail energy (≤ 30 J).
- **Layout hints**: SMDJ58CA within 5 mm of barrel jack, ground return direct to jack shell ground (do not dump 51 A surge through the main GND pour). Q1 drain-source loop area minimised; keep SMDJ58CA inside the current path loop, not dangling off a stub. D_RAIL within 10 mm of Q1's source pad.

### 3b. 48→3V3 buck (LMR36015FDDA)

- **Topology**: standard sync buck; no external Schottky needed.
- **f_sw**: 2.1 MHz (R_FSET = open, default).
- **Inductor**: L = V_OUT × (V_IN−V_OUT) / (ΔI × f_sw × V_IN). Target ΔI = 30 % of I_max = 0.45 A. L = 3.3 × (48−3.3) / (0.45 × 2.1e6 × 48) = **3.25 µH min**. Datasheet recommends 33 µH at 60 V_in / 2.1 MHz / 3.3 V_out for low-ripple profile → **XAL5030-333** selected. I_sat 1.7 A ≥ load+ripple.
- **C_IN**: 1× 2.2 µF / 100 V X7R 1210 (MLCC, right at VIN pin) + 1× 47 µF / 100 V AL-poly bulk. MLCC tight loop to GND; bulk within 15 mm.
- **C_OUT**: 2× 22 µF / 25 V X7R 0805 (44 µF effective ~30 µF after DC-bias derating at 3.3 V — meets datasheet ≥22 µF min with headroom).
- **Feedback (P2 closed 2026-04-25)**: LMR36015's `FDDA` suffix is the **package code (HSOIC-8 PowerPAD)**, not a fixed/adjustable indicator. The base part is adjustable via FB pin. Populate FB divider unconditionally: **R_FB_TOP = 100 kΩ, R_FB_BOT = 33.2 kΩ** for 3.3 V (V_FB = 1.0 V typical). Confirm against TI orderable code at fab time.
- **Bootstrap (mandatory)**: **C_BOOT = 100 nF / 25 V X7R 0402** between CBOOT pin and SW pin, placed within 2 mm of the IC. Without this, the high-side gate driver does not switch and the part bricks. Was missing pre-2026-04-25.
- **Enable / soft-start**: EN tied to V48_RAIL via 1 MΩ + 100 kΩ divider (EN rising threshold 1.2 V → board wakes at ~15 V input, avoiding brown-in chatter). SS pin: 10 nF to GND → ~4 ms soft-start, limits inrush from 3V3 cap bank.
- **Stress**: V_IN pin abs-max 65 V — protected by D_RAIL SMAJ51A on V48_RAIL (§3a). Light-load behaviour (FPWM vs auto-PFM) varies at high V_IN/V_OUT ratios per datasheet Figure 8-3; verify ripple at minimum load against the 22 µF C_OUT.
- **Thermal**: P_diss ≈ V_in × I_in × (1−η) ≈ 3.3 × 0.75 × (1/0.85 − 1) ≈ 440 mW at 85 % efficiency. HSOIC PowerPAD: ~40 °C/W with 4 thermal vias into a 10×10 mm pour → ΔT ≈ 18 °C, fine.
- **Layout hints**: switch-node trace < 10 mm, kept short and narrow; input MLCC GND return to PGND pin via shortest path; feedback trace away from switch node; thermal pad to GND pour via ≥4 vias (0.3 mm drill).

### 3c. Per-bus eFuse (×4, TPS259827YFFR)

- **I_LIM set**: datasheet `R_ILIM = K_ILIM / I_LIMIT`. For I_LIM ≈ 1.7 A and K_ILIM ≈ 18400 (A·Ω typ), R_ILIM ≈ **10.8 kΩ → use 11.0 kΩ 1 % 0603**. Confirm K from current datasheet rev — open issue P3.
- **EN**: driven from ESP32 GPIO through 0 Ω series; **10 kΩ pull-down to GND** on the eFuse side ensures the part is OFF when the MCU is in reset. EN is 5 V-tolerant logic; 3.3 V drive is fine.
- **FAULT**: open-drain, tied to PROT_FAULT_OR (§3f).
- **PGOOD**: not used in this revision — left as a test pad per bus (optional board-bring-up aid).
- **dV/dt (soft-start)**: **C_dVdT pin → 100 nF to GND** (was 10 nF pre-2026-04-25). Sized for full 32-unit bus inrush against 1.7 A trip. Aggregate downstream cap = 32 × ~25 µF effective = ~800 µF. Inrush = C × dV/dt = 800 µF × (48 V / 28 ms) ≈ **1.4 A** — below 1.7 A trip with margin. The pre-2026-04-25 10 nF gave ~12.8 A peak inrush, well above trip — the master could not bring up a populated chain.
- **Passives**: 0.1 µF / 100 V X7R 0603 at VIN; 0.1 µF / 100 V at VOUT (per-bus).
- **Per-bus enable sequencer (firmware)**: at boot, master enables each EFUSE_EN_n serially, waits for PGOOD assertion, samples INA237 current after 50 ms; if I_settle > 200 mA, declare INRUSH_NOT_SETTLED and disable that bus (open-fault for service). Pattern adopted from scottbez1 Chainlink Base supervisor.
- **Stress**: V_IN abs-max 60 V (transient 65 V ≤ 1 ms). V48_RAIL is clamped by D_RAIL SMAJ51A (§3a) at ~57 V tail current — within the 65 V transient rating. No additional per-bus protection needed.
- **Thermal**: R_DS(on) ~55 mΩ; at 1.5 A → 0.055 × 1.5² = 124 mW per eFuse. DSBGA-10 thermal-resistance ~80 °C/W → ΔT ≈ 10 °C → comfortable. 2×2 thermal via array under each package anyway (manufacturer app note).
- **Layout hints**: each eFuse's input/output caps within 3 mm. Keep the 4 eFuses in a row so their FAULT lines can share a common return/pull-up trace.

### 3d. INA237 high-side shunt (×4)

- **Topology (per bus)**: V48_RAIL → R_SHUNT (50 mΩ, 2512, Kelvin) → eFuse VIN. INA237 VS = 3V3. INA237 IN+ = V48_RAIL side of shunt; IN− = eFuse-side of shunt. VBUS tap goes **after** the eFuse (at eFuse VOUT) so INA237 VBUS reports the bus-facing voltage rather than the pre-fuse V48.
- **Full-scale**: 50 mΩ × 1.7 A = 85 mV → well inside the ±163.84 mV FSR of INA237. Current LSB options: select shunt_cal for 1 mA LSB (firmware decision).
- **VBUS attenuator (revised 2026-04-25)**: 10:1 RC divider, but **10 kΩ / 1 kΩ + 100 pF shunt** (was 100 kΩ / 10 kΩ pre-2026-04-25; high source impedance destroyed INA237's 16-bit accuracy via input-bias current and temperature drift). 8 mW dissipation per bus at 48 V — acceptable. Firmware scales ×11 back in software.
- **IN+/IN− filter**: 10 Ω series in each sense line + 100 nF differential across the INA237 IN+/IN− pins, per datasheet EMC recommendation. Resistors must be **≥100 V rated** (0603 thick-film, 200 V WV typical — confirm).
- **VS decoupling**: 100 nF 0603 X7R at each INA237.
- **Stress**: INA237 common-mode abs-max 85 V. With D_RAIL SMAJ51A on V48_RAIL (§3a), the rail is clamped to ~57 V during surge tail, well under the 85 V CM rating. The 10 Ω + 100 nF input filters on each IN+/IN− line further attenuate any residual fast edge. No separate protection on this subcircuit beyond what D_RAIL provides.
- **Layout hints**: Kelvin traces from each shunt → INA237 IN+/IN− matched in length (mm-level), routed as a tight pair, away from switcher noise. Shunt pad copper minimized beyond Kelvin taps so IR voltage is measured accurately, not diluted by pour resistance.

### 3e. Hardwired LED bank

- **PWR_48V**: 22 kΩ 0805 from V48_RAIL to red LED anode, LED cathode to GND. I_LED = (48 − 1.9) / 22 000 = **2.1 mA**. Power in R = (46.1)² / 22 000 = **97 mW** → 0805 250 V WV rating required (confirm part). At surge 93 V: (91.1)² / 22 k = 377 mW peak for <1 ms — acceptable pulse energy on 0805 thick-film.
- **PWR_3V3**: 680 Ω 0603 from 3V3 to green LED anode. I_LED = (3.3 − 2.0) / 680 = **1.9 mA**. R dissipation 2.5 mW — trivial.
- **FAULT (revised 2026-04-25, P4 closed)**: PROT_FAULT_OR is active-low (open-drain wired-OR). To off-load the LED current from the OR line, drive the LED via a **single SOT-23 PNP transistor (e.g. MMBT3906) configured as a high-side switch**: `3V3 → MMBT3906 emitter; MMBT3906 collector → 680 Ω → LED anode → LED cathode → GND; MMBT3906 base → 10 kΩ → PROT_FAULT_OR`. Idle: PROT_FAULT_OR pulled HIGH by 10 kΩ → base sees 3V3 → BJT off → LED off. Fault: PROT_FAULT_OR pulled LOW → base current ~0.27 mA flows from emitter through 10 kΩ → BJT saturates → LED lit. Total load on the OR line = 10 kΩ pull-up + 10 kΩ base resistor in parallel = ~5 kΩ → 0.66 mA sink at fault — still within LM74700's 1 mA FAULT I_OL spec. Adds one MMBT3906 (~€0.04) + one 10 kΩ. Cleaner than the earlier BSS138-inverter sketch.
- **Layout**: put all 3 LEDs in a row near the RJ45 stack so they're visible with the enclosure open.

### 3f. PROT_FAULT_OR wired-OR

- **Topology**: 5 open-drain FAULT outputs (LM74700-Q1 + 4× TPS259827) commoned onto one net. Single 10 kΩ pull-up to 3V3.
- **Loads on the net (revised 2026-04-25)**:
  1. ESP32 GPIO input (IRQ, high-Z).
  2. MMBT3906 PNP base via 10 kΩ (drives FAULT LED — §3e). Adds ~0.33 mA at fault.
- **Logic**: IDLE = HIGH (~3.3 V, GPIO reads 1, BJT off, LED off). ANY FAULT = LOW (GPIO reads 0, BJT saturates, LED on, firmware IRQ).
- **Sink budget at fault (revised)**: 3.3 V / 10 kΩ pull-up + 3.3 V / 10 kΩ base resistor = **0.66 mA** total. LM74700 FAULT I_OL = 1 mA → 33 % headroom. TPS259827 FAULT I_OL = 4 mA → 6× headroom. P4 closed.
- **Layout**: keep the OR-net short and away from the switch node; 10 kΩ pull-up placed near MCU pin (termination side) for best noise immunity on the IRQ input. MMBT3906 + base resistor placed near the LED, not near the OR pull-up.

## 4. Signal handoff list (power side → digital side)

| Net | Direction | Electrical | MCU pin needed | Pull-up/down | Owner of pull |
|---|---|---|---|---|---|
| PROT_FAULT_OR | Power → MCU (in) | Open-drain, 3V3 logic, idle HIGH, 10 kΩ pull-up, <5 µs edges | Input, IRQ-capable, any GPIO | 10 kΩ to 3V3 | **Power side** (this doc) |
| EFUSE_EN_1..4 | MCU → Power (out) | Push-pull 3V3, driven HIGH to enable bus | Output, any GPIO | 10 kΩ pull-down to GND (fail-safe OFF) | **Power side** (this doc) |
| TELEM_ALERT_OR | Power → MCU (in) | Open-drain, 3V3 logic, 4× INA237 ALERT wired-OR, 10 kΩ pull-up | Input, IRQ-capable | 10 kΩ to 3V3 | **Power side** (this doc) |
| INA237_SDA / _SCL | Bidir I²C | 400 kHz, 3V3 | I²C master pins | 2.2 kΩ to 3V3 on each line | **Digital side** (not in this doc) |
| FAULT_LED | (hardwired, informational) | — | none | — | Power side |

## 5. Bulk cap + inrush analysis

- **Input bulk**: 2× 47 µF AL-poly (100 V) + 1× 4.7 µF 100 V X7R MLCC in parallel = ~100 µF effective.
- **Hot-plug worst case**: barrel plug inserted into a 48 V live supply with the board cold (caps at 0 V). Inrush peak current through an ideal short: I_peak = V / ESR_eff. ESR_AL-poly ≈ 30 mΩ, ESR_MLCC ≈ 5 mΩ, combined parallel ESR ~4 mΩ. Unlimited I_peak would be 48 / 0.004 = 12 kA — but source impedance of a 48 V brick (2 A, 3 m lead) is ≥200 mΩ typ, so real peak ≈ 48 / 0.2 = **240 A for a few µs** → still enough to arc the connector.
- **Mitigation**: LM74700-Q1's current-limited turn-on (slow GATE charge via internal 100 µA charge pump) gates the inrush. GATE-to-source Miller plateau time with Q_g=44 nC and I_gate_typ=100 µA → slew ≈ 44 nC / 100 µA = **440 µs** → inrush current limited to C × dV/dt = 100 µF × (48 V / 440 µs) = **10.9 A peak**. Acceptable on a 2 A supply with a capable brick; graceful brown-in on a marginal brick.
- **Supply sizing recommendation for users**: 48 V / 5 A brick recommended for a fully populated master (128 units × ~30 mA mech avg = 3.8 A, plus per-bus overhead + master = ~4.5 A steady). Board won't exceed 4× 1.7 A = 6.8 A if all buses hit eFuse limit simultaneously (fault scenario).
- **Output bulk on 3V3**: 44 µF effective; handles the 500 mA WiFi TX pulse with <50 mV sag at LMR36015's 2.1 MHz response bandwidth.

## 6. Thermal table (worst-case, ambient 40 °C, still air)

| Part | P_diss worst-case | θ_JA | ΔT | Mitigation |
|---|---|---|---|---|
| Q1 (SQJ148EP) | 2² × 0.009 = 36 mW typ; 6.8² × 0.009 = 416 mW fault | 40 °C/W | 17 °C | Drain pad copper pour ≥ 100 mm² |
| LMR36015FDDA | ~440 mW @ 750 mA | 40 °C/W PowerPAD | 18 °C | Thermal pad → 4× 0.3 mm vias into GND pour ≥ 100 mm² |
| TPS259827 ×4 | 124 mW @ 1.5 A / ea | 80 °C/W DSBGA | 10 °C | 2×2 thermal-via array under each pkg |
| R_SHUNT ×4 | 50 mΩ × 1.7² = 144 mW @ I_LIM | 2512 handles 1 W | negligible | No mitigation needed; keep pads away from INA237 thermal |
| INA237 ×4 | <5 mW (analog) | 170 °C/W VSSOP | <1 °C | None |
| LM74700-Q1 | <1 mW (control only) | — | — | None |
| SMDJ58CA | 0 W steady; 3 kW / 1 ms pulse | per datasheet | — | GND pour on cathode pad |
| R_LED_48V (22 kΩ) | 97 mW steady | 0805 rated 125 mW | fine | Use 250 V WV 0805; confirm derating at 60 °C |

No part sits above 50 % of its rated θ_JA-limited temperature at full steady-state load. Copper-pour callouts are the only thermal mitigations needed.

## 7. Open issues

- ~~**P1**~~ **Resolved 2026-04-25 (issue #76 review).** Surge-clamp chain **simplified**: R_SERIES + D_SEC chain deleted (R_SERIES dissipated 950 W steady — architectural error). Replaced by reliance on LM74700-Q1 native overvoltage protection per TI SLVA936 + single SMAJ51A (D_RAIL) on V48_RAIL. Net BOM saving: ~€0.60.
- ~~**P2**~~ **Closed 2026-04-25.** `FDDA` is the package code (HSOIC-8 PowerPAD), not fixed/adjustable. Base part is adjustable; FB divider is mandatory. C_BOOT 100 nF added (was missing).
- **P3 — TPS259827YFFR I_LIM constant (K_ILIM).** Datasheet rev 1.3 lists K ≈ 18400; newer revs differ. Confirm against the rev current at fab time and pick R_ILIM to land 1.6–1.8 A window. (Non-blocking; component value determined at fab.)
- ~~**P4**~~ **Closed 2026-04-25.** FAULT LED driven via MMBT3906 PNP high-side switch with 10 kΩ base resistor (§3e/§3f). PROT_FAULT_OR sink at fault = 0.66 mA — within LM74700's 1 mA spec.
- **P5 — Barrel jack surge path return.** If the enclosure is metal, the barrel jack shell must be isolated from chassis or the TVS return path will dump surge through the mechanical shield. Flag to mechanical agent. Default desktop project-box class enclosure assumed (plastic) per MASTER_DECISIONS — non-blocking.
- ~~**P6**~~ **(new) Closed 2026-04-25.** Per-bus C_dVdT bumped from 10 nF → 100 nF for 32-unit bus inrush against 1.7 A trip.

## 8. BOM additions (power subsystem)

> **Note (2026-04-25):** This block is informational — the canonical BOM lives in `MASTER_BOM.csv` in the JLC-native schema. The list below is grouped by subcircuit for review. Changes vs. pre-2026-04-25:
> - **Removed**: `RTH1` (R_SERIES NTC) and `D_SEC` (SMAJ51A on IC V_IN feed) — surge chain simplified per #76 audit.
> - **Added**: `C_BOOT` (LMR36015 bootstrap), `R_GATE_LM` (LM74700 GATE series), `Q_FAULT_PNP` (MMBT3906 FAULT LED driver), `R_FAULT_BASE` (BJT base R), bumped `C_DVDT` 10 nF → 100 nF, changed `R_VBUS_T` 100 kΩ → 10 kΩ and `R_VBUS_B` 10 kΩ → 1 kΩ.

```
Ref,Part,LCSC,Package,Qty,Note
J1,Barrel jack 5.5/2.5 mm 60 V THT,check,THT,1,Check stock + footprint at BOM-finalize
D1,SMDJ58CA,C145194,DO-214AB,1,Bidir TVS 58V (primary surge clamp)
D_RAIL,SMAJ51A,C8678,SMA,1,Sole secondary clamp on V48_RAIL post-Q1 (§3a)
U1,LM74700-QDBVRQ1,C2941042,SOT-23-6,1,Ideal-diode controller (REVIEW_VERIFIED)
Q1,SQJ148EP-T1_GE3,CHECK,PowerPAK SO-8,1,100V 9mΩ N-FET (REVIEW_BLOCKER: old C2836025 wrong)
R_GATE_LM,1 kΩ 1%,C22929,0603,1,LM74700 GATE series for Q_g stability (TI SLUA975)
U2,LMR36015AFDDA,CHECK,HSOIC-8 PowerPAD,1,48→3V3 buck (adjustable; FB divider populated) (REVIEW_BLOCKER: old C922105 unverified)
C_BOOT,100 nF 25V X7R,C1525,0402,1,LMR36015 CBOOT-to-SW (mandatory)
L1,XAL5030-333MEB,C2834984,5.3×5.3×3.0,1,33 µH 1.7 A shielded
C_IN48_BULK,Nichicon PCV 47µF/100V,C2843372,SMD 10×10,2,AL-poly input bulk
C_IN48_HF,GRM32ER72A475K,C2832225,1210,1,4.7 µF / 100 V X7R
C_IN_BUCK,GRM32ER72A225K,C1778,1210,1,2.2 µF / 100 V X7R at buck VIN
C_OUT_BUCK,GRM21BR71E225K,C1804,0805,2,22 µF / 25 V X7R
C_SS,100 nF X7R,C14663,0603,1,Buck SS pin
C_CP74700,100 nF X7R,C14663,0603,1,LM74700 CAP pin
R_EN_TOP,1 MΩ 1%,C22935,0603,1,LMR36015 EN divider top
R_EN_BOT,100 kΩ 1%,C25803,0603,1,LMR36015 EN divider bottom
R_FB_TOP,100 kΩ 1%,C25803,0603,1,LMR36015 FB divider top (3V3)
R_FB_BOT,33.2 kΩ 1%,check,0603,1,LMR36015 FB divider bottom (3V3)
R_GATE_BLEED,10 kΩ 1%,C25804,0603,1,Q1 G–S bleed
R_SH1..4,50 mΩ 1% 3 W 2512 Kelvin,C157950,2512,4,Per-bus shunt
U3..U6,TPS259827YFFR,CHECK,DSBGA-10,4,Per-bus eFuse (primary; alternate WQFN-12 footprint also placed) (REVIEW_BLOCKER: DSBGA pre-fab gate; old C2906816 unverified)
R_ILIM1..4,11 kΩ 1%,C23186,0603,4,eFuse I_LIM
C_DVDT1..4,100 nF X7R,C14663,0603,4,eFuse dV/dt — sized for 32-unit bus inrush (was 10 nF)
C_IN_EF1..4,100 nF / 100 V X7R,C123498,0603,4,eFuse VIN decap
C_OUT_EF1..4,100 nF / 100 V X7R,C123498,0603,4,eFuse VOUT decap
R_EN_PD1..4,10 kΩ 1%,C25804,0603,4,eFuse EN pull-down (fail-safe OFF)
C_EN_RC1..4,100 nF X7R,C14663,0603,4,eFuse EN RC filter (τ ≈ 1 ms)
U_POR,TPS3839L33DBVR,C70604,SOT-23-5,1,3V3 POR supervisor — open-drain /RESET
R_POR_PU,10 kΩ 1%,C25804,0603,1,/RESET pull-up
D_POR1..4,BAT54 small-signal Schottky,C2480,SOT-23,4,Anode at /RESET, cathode at EFUSE_EN_n (polarity corrected 2026-04-25) — pulls EN low when 3V3 unhealthy
U7..U10,INA237AIDGSR,CHECK,VSSOP-10,4,Current monitor — LCSC pending ChatGPT pass (#75) (REVIEW_BLOCKER: INA226AIDGSR C49851 not a blind substitute — VBUS divider/CM limits/register map differ)
R_INx_A1..4,10 Ω / 100 V 1%,C25076,0603,4,INA237 IN+ series filter
R_INx_B1..4,10 Ω / 100 V 1%,C25076,0603,4,INA237 IN− series filter
C_INx_FLT1..4,100 nF X7R,C14663,0603,4,INA237 differential filter
R_VBUS_T1..4,10 kΩ 1%,C25804,0603,4,VBUS divider top (revised 2026-04-25 from 100 kΩ)
R_VBUS_B1..4,1 kΩ 1%,C21190,0603,4,VBUS divider bottom (revised 2026-04-25 from 10 kΩ)
C_VBUS1..4,100 pF C0G,C1546,0603,4,VBUS divider shunt
C_VS1..4,100 nF X7R,C14663,0603,4,INA237 VS decap
R_LED_48V,22 kΩ 1% 0805 250 V,C17673,0805,1,PWR_48V LED resistor
R_LED_3V3,680 Ω 1%,C23243,0603,1,PWR_3V3 LED resistor
R_LED_FAULT,680 Ω 1%,C23243,0603,1,FAULT LED collector resistor
LED_48V,LED red 0603,C2286,0603,1,PWR_48V indicator
LED_3V3,LED green 0603,C72043,0603,1,PWR_3V3 indicator
LED_FAULT,LED red 0603,C2286,0603,1,FAULT indicator
Q_FAULT_PNP,MMBT3906 PNP,C8616,SOT-23,1,FAULT LED high-side switch — gates LED off the OR line (P4 closed)
R_FAULT_BASE,10 kΩ 1%,C25804,0603,1,MMBT3906 base resistor on PROT_FAULT_OR
R_PF_PULL,10 kΩ 1%,C25804,0603,1,PROT_FAULT_OR pull-up
R_AL_PULL,10 kΩ 1%,C25804,0603,1,TELEM_ALERT_OR pull-up
```

---

# Section 3 — DIGITAL_DESIGN.md

# Master PCB v2 — Digital & Communications Subsystem

> **Scope:** ESP32-S3 module support, USB-C, SWD, MAX14830 SPI-UART bridge, 4× SN65HVD75 RS-485 PHYs, 4× INA237 I²C telemetry, HEARTBEAT LED, eFuse ENABLE × 4, fault aggregation inputs.
>
> **Boundary:** Power rails, eFuses, TVS, ideal-diode, hardwired LEDs (PWR_48V / PWR_3V3 / FAULT) are owned by the power subsystem. This doc only surfaces the signals that cross the boundary.
>
> **Binding reference:** `MASTER_DECISIONS.md` only. Last edited 2026-04-25 (post-review revisions; see issue #76).

---

## 1. Block diagram

```
                            +---------- USB-C (IO19 D-, IO20 D+) ---- ESD (USBLC6-2SC6)
                            |                                         CC1/CC2: 5k1 pull-down
                            |                                         VBUS -> ferrite + bulk + NC
                            |
              +----- BOOT (IO0 btn) ---+
              |                        |
              | +--- RST (EN btn+RC) --+
              | |
      +-------v-v---------------------------------+
      |         ESP32-S3-WROOM-1-N16R8            |
      |                                           |
      |  SPI1: IO10/CS  IO11/MOSI IO12/MISO       +--SPI-+
      |        IO13/SCK IO14/IRQ                  |      |
      |  I2C0: IO8/SDA  IO9/SCL                   |      v
      |  eFuse EN: IO4, IO5, IO6, IO7             |   +---------------+
      |  PROT_FAULT_OR (in, IRQ): IO15            |   |  MAX14830ETJ+ |
      |  TELEM_ALERT_OR (in, IRQ): IO16           |   |  4× UART/SPI  |
      |  HEARTBEAT LED (out):      IO21           |   |  3.6864 MHz X |
      |  JTAG: IO39/40/41/42                      |   |  GPIO1..4 ->  |
      |  UART0 console: IO43/44                   |   |   BUS_ACT LEDs|
      |  Straps (no route): IO3, IO45, IO46       |   +---+--+--+--+--+
      |  Unassigned (policy): IO48                |       |  |  |  |
      +-------^----+---+---+---+------------------+       |  |  |  |  (TX/RX/DE per ch)
              |    |   |   |   |                          v  v  v  v
              |    |   |   |   |                     +----+----+----+----+
              |    |   |   |   |                     |  4× SN65HVD75D    |
    PROT_FAULT_OR  |   |   |   |                     |  half-duplex 3V3  |
      (wired-OR    |   |   |   |                     +-+----+----+----+--+
       open-drain) |   |   |   |                       | A/B per bus
                   |   |   |   |                       v
              eFuse_EN1..4 (to power subsystem)    CM choke + TVS (SM712)
                                                   + 120R term + 390/390 bias
                                                   -> 4× shielded RJ45

          I²C (IO8/IO9) -----> [INA237 ×4: 0x40..0x43]
                                 ALERTs wired-OR -> TELEM_ALERT_OR (IO16)

                                                      SWD 2x5 1.27mm header
                                                      -> IO39/40/41/42 + EN
```

---

## 2. ESP32-S3 pin budget (complete, IO0–IO48)

Legend — **Dir**: I=input, O=output, IO=bidir, USB=native USB PHY, X=not routed.
**Pull**: internal/external as noted. **Strap**: boot-time strap pin behaviour.

| IO# | Net               | Dir | Pull            | Strap / Boot notes                          | Rationale |
|-----|-------------------|-----|------------------|---------------------------------------------|-----------|
| 0   | BOOT_BTN          | I   | 10k ext PU to 3V3 | Strap: boot mode (0=DL, 1=SPI). Button to GND. | Standard Espressif boot button. |
| 1   | (spare)           | -   | 10k PU, test pad | ADC-capable                                 | Reserve. |
| 2   | (spare)           | -   | 10k PU, test pad | -                                           | Reserve. |
| 3   | NC (no route)     | X   | -                | **Strap (JTAG sel). No copper escape.**     | Policy: no-route. |
| 4   | EFUSE_EN1         | O   | 10k PD + 100nF RC + POR-Schottky to /RESET (power side) | Held LOW until 3V3 is healthy AND MCU drives high. eFuse cannot turn on at brown-in. | Bus 1 enable, firmware-sequenced. |
| 5   | EFUSE_EN2         | O   | 10k PD + 100nF RC + POR-Schottky (power side) | "                                          | Bus 2 enable. |
| 6   | EFUSE_EN3         | O   | 10k PD + 100nF RC + POR-Schottky (power side) | "                                          | Bus 3 enable. |
| 7   | EFUSE_EN4         | O   | 10k PD + 100nF RC + POR-Schottky (power side) | "                                          | Bus 4 enable. |
| 8   | I2C_SDA           | IO  | 4k7 ext PU to 3V3 | -                                           | INA237 bank shared bus. |
| 9   | I2C_SCL           | IO  | 4k7 ext PU to 3V3 | -                                           | INA237 bank shared bus. |
| 10  | SPI_CS_MAX        | O   | 10k ext PU to 3V3 | Idle-high at boot so MAX14830 stays deselected. | CS to MAX14830. |
| 11  | SPI_MOSI          | O   | none             | -                                           | SPI to MAX14830. |
| 12  | SPI_MISO          | I   | none             | -                                           | SPI from MAX14830. |
| 13  | SPI_SCK           | O   | none             | -                                           | SPI clock. |
| 14  | MAX_IRQ           | I   | 10k ext PU to 3V3 | Active-low open-drain from MAX14830 IRQ.    | Edge-triggered UART RX/status. |
| 15  | PROT_FAULT_OR     | I   | 10k ext PU to 3V3 (owned here) | Active-low, wired-OR open-drain from LM74700 FAULT + 4× eFuse FAULT. | IRQ input + drives hardwired FAULT LED (pull owned digital side, LED branch owned power side). |
| 16  | TELEM_ALERT_OR    | I   | 10k ext PU to 3V3 | Active-low, wired-OR from 4× INA237 ALERT. | IRQ; firmware polls all 4 INA237 to identify source. |
| 17  | (spare)           | -   | 10k PU, test pad | ADC-capable, DAC1                           | Reserve. |
| 18  | (spare)           | -   | 10k PU, test pad | ADC-capable, DAC2                           | Reserve. |
| 19  | USB_DM            | USB | -                | **Fixed: native USB D−.** No other use.     | USB-C. |
| 20  | USB_DP            | USB | -                | **Fixed: native USB D+.** No other use.     | USB-C. |
| 21  | HEARTBEAT_LED     | O   | none (LED+R to GND) | Must idle low at boot (LED off) — no PU.  | Blue LED, firmware blink pattern. |
| 22–25 | —               | -   | -                | **Do not exist on WROOM-1 module.**         | Not bonded out. |
| 26–32 | FLASH internal  | X   | -                | **Internal SPI flash; do not route.**       | N16R8 internal. |
| 33–37 | PSRAM internal  | X   | -                | **Internal Octal PSRAM; do not route.**     | N16R8 internal. |
| 38  | (spare)           | -   | 10k PU, test pad | -                                           | Reserve. |
| 39  | JTAG_MTCK         | IO  | per SWD header   | **Fixed JTAG.**                             | SWD. |
| 40  | JTAG_MTDO         | IO  | per SWD header   | **Fixed JTAG.**                             | SWD. |
| 41  | JTAG_MTDI         | IO  | per SWD header   | **Fixed JTAG.**                             | SWD. |
| 42  | JTAG_MTMS         | IO  | per SWD header   | **Fixed JTAG.**                             | SWD. |
| 43  | UART0_TXD         | O   | -                | **Reserved console TXD. Not remapped.**     | Boot log / recovery. |
| 44  | UART0_RXD         | I   | -                | **Reserved console RXD. Not remapped.**     | Boot log / recovery. |
| 45  | NC (no route)     | X   | -                | **Strap (VDD_SPI). No copper escape.**      | Policy: no-route. |
| 46  | NC (no route)     | X   | -                | **Strap (boot mode). No copper escape.**    | Policy: no-route. |
| 47  | (spare)           | -   | 10k PU, test pad | -                                           | Reserve. |
| 48  | NC (policy avoid) | X   | -                | **Unassigned. Test pad only, not a signal.**| Policy: avoid. |

**Totals:** Assigned = 15 (IO0 BOOT + IO4–16 + IO21). Spare = 7 (IO1, IO2, IO17, IO18, IO38, IO47, + slack). Matches MASTER_DECISIONS budget within IO0-is-strap-plus-button counting convention.

---

## 3. Sub-circuits

### 3a. Module support — decoupling, EN, BOOT

- **Decoupling (revised 2026-04-25 per WROOM-1 hardware design guide)**: bulk = **22 µF X5R 0805 + 10 µF X5R 0805 + 100 nF X7R 0402**, all three placed **within 5 mm of the module's pin 2 (3V3 entry)**. Additional 100 nF X7R 0402 on every other module VDD pad pair. The pre-2026-04-25 spec used a single 22 µF MLCC which has X5R high-Q resonance issues at the buck's 2.1 MHz harmonics — replaced with the WROOM-1 reference cap stack.
- **EN pin**: 10 kΩ pull-up to 3V3 + 1 nF cap to GND. RESET button SW_RST shorts EN to GND; 100 nF across for contact debounce.
- **IO0 (BOOT)**: 10 kΩ pull-up to 3V3 (strap = 1 = SPI boot). BOOT button to GND. 100 nF debounce across the switch.
- **IO3 / IO45 / IO46 strap pads**: module-pad only; no copper escape. Note: WROOM-1 module-internal pulls already set the strap state — these pads exist but are not floating MCU pins. No external connection needed; clarification from #76 audit.
- **IO19 / IO20 (USB-CDC) layout note**: native USB pins also act as boot-mode straps for USB_JTAG vs UART download. Layout must verify boot mode is unaffected by USB host attach during reset (per ESP32-S3 datasheet §2.4).
- **Antenna keep-out**: copper, ground pour, and tall components must respect Espressif keep-out. Mechanical agent owns dimensioning.

### 3b. USB-C

- Receptacle: USB-C 2.0-only 16-pin SMD (e.g. GCT USB4085 / LCSC C165948 class — needs both CC1/CC2).
- CC1, CC2: each 5.1 kΩ to GND (UFP role).
- D+/D−: route to IO20 / IO19. USBLC6-2SC6 (C7519, REVIEW_VERIFIED — old C7415 was wrong) ESD clamp on the D± pair close to the connector.
- VBUS handling: VBUS → ferrite bead (BLM18PG600SN1) → 4.7 µF bulk → **NC (not routed to 3V3 rail)**. Test pad post-ferrite.
- Shield: USB-C shell tied to GND via 0 Ω populated by default. Hybrid (1 MΩ ∥ 10 nF) left as DNP pad.

### 3c. Reset + Boot buttons

- 2× tactile 6×6 mm SMD, ~160 gf.
- SW_RST across EN–GND; 10k PU + 100 nF debounce.
- SW_BOOT across IO0–GND; 10k PU + 100 nF debounce.

### 3d. SWD / JTAG header

- 2×5 1.27 mm Cortex-Debug header.
- Pinout (ARM 10-pin standard):
  1. VTref → 3V3
  2. TMS → IO42
  3. GND
  4. TCK → IO39
  5. GND
  6. TDO → IO40
  7. KEY (NC)
  8. TDI → IO41
  9. GNDDetect → GND
  10. nRESET → EN through **0 Ω, DNP by default** (populate only when a debugger's nSRST is explicitly needed).
- Optional 33 Ω series on TCK/TDO (DNP) for long-cable SI trim.

### 3e. MAX14830 interface

- IC: MAX14830ETJ+ (TQFN-32, **CHECK** — REVIEW_BLOCKER: old C2683133 unverified, ETJ+ package not cleanly mapped on JLC). 3V3 operation.
- Crystal: 3.6864 MHz fundamental (ABLS-3.6864MHZ-B4-T, C70581). **Load caps must match the crystal's specified C_L** — for an 18 pF C_L crystal: C_load_cap = 2 × (C_L − C_stray) = 2 × (18 − 3) = **30 pF C0G 0402** on each of XTAL1, XTAL2 to GND. Verify crystal C_L spec at BOM-finalize before fixing cap value.
- SPI wiring: MOSI↔DIN, MISO↔DOUT, SCK↔SCLK, CS↔/CS (IO10). IRQ↔IO14 (open-drain, 10 kΩ PU to 3V3 on digital side).
- **VEXT pin (I/O level reference) tied to 3V3** with its own 100 nF X7R decoupling cap. Locked 2026-04-25.
- Decoupling: 100 nF per VDD + 10 µF bulk.
- /RESET: to 3V3 through 10 kΩ. DNP pad to GND for forced reset.
- GPIO 0..3 (chip GPIOs): configured as outputs driving BUS_ACT_1..4 LEDs (see §3h).
- **Mode-select pins (revised 2026-04-25)**: in SPI mode, the MAX14830's mode-select / chip-select pins are determined by datasheet — A0/A1 are NOT address straps in SPI mode (that was the I²C-mode behaviour). Confirm exact pin handling per MAX14830 datasheet §"SPI mode" before tape-out. The pre-2026-04-25 wording "A0/A1 tied to GND" was a hold-over from I²C-mode docs and needs schematic-capture verification.

### 3f. SN65HVD75D per-bus RS-485 PHY (×4 identical)

- IC: SN65HVD75DR (SOIC-8, C57928 REVIEW_VERIFIED_LCSC). Baud locked to **500 kbaud 8N1**.
- D (TX in) ← MAX14830 TXn; R (RX out) → MAX14830 RXn.
- DE + /RE tied together ← MAX14830 per-channel DE output (hardware auto-direction).
- A / B → common-mode choke (Würth 744232601, **CHECK** — REVIEW_BLOCKER: old C191126 resolved to Vishay VEMD5510C photodiode, 600 Ω @ 100 MHz) → RJ45.
- Transient: SM712-02HTG (C169123) across A–GND / B–GND.
- Termination: 120 Ω 1 % 0805 A↔B, populated (master is chain end).
- **Fail-safe bias (revised 2026-04-25): 1 kΩ 1 % A→3V3, 1 kΩ 1 % B→GND** (was 390 Ω each leg). Idle differential ≈ 280 mV — comfortably above SN65HVD75 200 mV failsafe threshold; idle current per bus 1.6 mA (was 4.2 mA at 390 Ω → 17 mA across 4 buses).
- RJ45 shield: bonded **solid to GND at master only**. Unit/backplane RJ45 shields float (locked 2026-04-25 to avoid ground-loop hunting across 32 parallel RC paths).
- RJ45: shielded THT, no magnetics. Cabling spec: **shielded CAT5e or CAT6 (S/FTP or F/UTP), straight-through, T568B**. Max chain length 32 m total / 3 m per hop / ≤7 V worst-case IR drop.
- **Wire format**: COBS(payload || CRC16-BE) 0x00 framing per `firmware/lib/common/`. Includes broadcast and batched-update message types (`BROADCAST_SET_POSITION`, `BATCH_UPDATE`) for sync animation across all units, plus a `LOOPBACK` message for end-to-end chain integrity check at boot.
- **Pin-1 indicator on RJ45**: silkscreen `1` next to pin-1 of every RJ45. Required (M6 closed 2026-04-25).

### 3g. INA237 telemetry bank + TELEM_ALERT_OR

- IC: INA237AIDGSR (VSSOP-10, **CHECK** — REVIEW_BLOCKER: exact LCSC unverified; INA226 C49851 not a blind substitute). ×4 on shared I²C.
- Address straps:
  - U_INA1: A1=GND A0=GND → 0x40
  - U_INA2: A1=GND A0=VS   → 0x41
  - U_INA3: A1=GND A0=SDA  → 0x42
  - U_INA4: A1=GND A0=SCL  → 0x43
- I²C pull-ups: 4.7 kΩ to 3V3 on SDA (IO8) and SCL (IO9). Single pair for the bus.
- ALERT wired-OR: 4× ALERT open-drain → one TELEM_ALERT_OR net → IO16. 10 kΩ PU to 3V3 on the shared node.
- Decoupling: 100 nF per IC.
- Shunt + input filter network owned by power subsystem.

### 3h. BUS_ACT LED drive from MAX14830

- LEDs: 4× 0603 green, ~2 mA nominal.
- Topology: 3V3 → LED → 1 kΩ 0603 → MAX_GPIOn (active-low sink, preferred). Confirm at schematic capture (O4).
- Firmware or hardware TX-activity mirror stretches blinks to ≥ 20 ms for visibility.

### 3i. HEARTBEAT LED

- Blue 0603.
- 3V3 → LED → 1 kΩ → IO21 (sink).
- No external pull. Firmware owns the pin from reset. Blink pattern per MASTER_DECISIONS.

### 3j. EFUSE_EN POR gating (cross-boundary, owned power-side)

> Mandatory — without this, eFuses can briefly enable during 48 V brown-in before the MCU is alive to sequence them.

- **U_POR**: TPS3839L33DBVR, monitors 3V3, threshold 3.08 V (typ), open-drain /RESET output, asserted LOW when 3V3 is below threshold.
- **/RESET pull-up**: 10 kΩ to 3V3.
- **Per-EN gating (×4)**: BAT54 Schottky diode anode-at-EFUSE_EN_n / cathode-at-/RESET. When /RESET is asserted (3V3 unhealthy), each diode forward-biases and pulls its EN line to ≈ 0.3 V — well below the TPS259827 EN threshold (1.35 V typ). When /RESET is released (3V3 healthy), diodes reverse-bias and EN follows the MCU GPIO normally.
- **Per-EN RC filter**: 100 nF MLCC from each EN to GND, forming τ ≈ 1 ms with the 10 kΩ pull-down. Rejects brown-in supply noise and any sub-millisecond GPIO glitch during boot. Does not slow legitimate enable transitions noticeably (firmware enables buses in sequence with > 10 ms gaps).
- **Layout**: place U_POR within 5 mm of the LMR36015 V_OUT pin so it senses the same node the digital logic actually runs on. BAT54 diodes near the eFuse EN pins, not near the supervisor.

---

## 4. Signal handoff list (power ⇄ digital boundary)

| Signal | Direction (relative to digital) | Owner of pull | Pull value | Notes |
|---|---|---|---|---|
| EFUSE_EN1..4 | Digital → Power | Power side | 10 kΩ PD to GND | Default OFF at boot. |
| PROT_FAULT_OR | Power → Digital | Digital side | 10 kΩ PU to 3V3 | Wired-OR open-drain. Also drives FAULT LED. |
| TELEM_ALERT_OR | Power → Digital | Digital side | 10 kΩ PU to 3V3 | Wired-OR of 4× INA237 ALERT. |
| INA237 I²C (SDA/SCL) | Digital ↔ Power | Digital side | 4.7 kΩ PU to 3V3 | INA237 shunt + filter owned by power. |
| 3V3 rail | Power → Digital | — | — | |
| 48 V rail | Power → (not used by digital) | — | — | Never enters digital subsystem. |
| USB VBUS | Connector → (isolated) | — | — | Ferrite + bulk + NC. |

---

## 5. Open issues

- **O1 — MAX14830 TX-activity LED mirror mode.** Hardware pulse-stretch mode behaviour must be re-checked at datasheet-read time. Firmware mirror is the fallback (ISR sets GPIO on TX non-empty, one-shot timer clears after 20 ms). Non-blocking.
- ~~**O2**~~ **Closed 2026-04-25.** RJ45 pinout locked in `MASTER_DECISIONS.md`: pin 1/2 = NC reserved, pin 3/6 = RS-485 A/B (T568B green pair, true twisted pair), pin 4/5 = +48V (paralleled), pin 7/8 = GND (paralleled). Cable spec: T568B straight-through only.
- ~~**O3**~~ **Closed 2026-04-25.** JTAG nRESET stays 0 Ω DNP — populated only when a debugger's nSRST is explicitly needed.
- ~~**O4**~~ **Closed 2026-04-25.** BUS_ACT LED drive: active-low sink (3V3 → LED → 1 kΩ → MAX_GPIOn).
- ~~**O5**~~ **Closed 2026-04-25.** USB-C shield bond: 0 Ω direct to GND. Hybrid pad pattern remains DNP for future tuning.
- **O6 — Spare GPIO policy**. 7 spares reserved with 10 kΩ PU + test pads, no pre-assigned role. Persist.

---

## 6. BOM additions (digital subsystem)

| Ref | Part | LCSC | Package | Qty | Note |
|---|---|---|---|---|---|
| U1 | ESP32-S3-WROOM-1-N16R8 | C2913202 | Module | 1 | 16 MB flash, 8 MB Octal PSRAM |
| U2 | MAX14830ETJ+ | CHECK | TQFN-32 | 1 | 4-UART SPI bridge (REVIEW_BLOCKER: old C2683133 unverified) |
| U3..U6 | SN65HVD75DR | C57928 | SOIC-8 | 4 | RS-485 PHY 3V3 (REVIEW_VERIFIED_LCSC) |
| U7..U10 | INA237AIDGSR | CHECK | VSSOP-10 | 4 | I²C addr 0x40..0x43 (REVIEW_BLOCKER: INA226 C49851 not a substitute) |
| U11 | USBLC6-2SC6 | C7519 | SOT-23-6 | 1 | USB D± ESD (REVIEW_VERIFIED — old C7415 wrong) |
| Y1 | 3.6864 MHz XTAL, 18 pF | C70581 | 3.2×2.5 | 1 | MAX14830 clock |
| J_USB | USB-C 2.0 receptacle 16-pin | C165948 | SMD | 1 | UFP |
| J_SWD | 2×5 1.27 mm header | C72408 | SMD | 1 | Cortex-debug |
| J_BUS1..4 | Shielded THT RJ45 no-mag | CHECK | THT | 4 | RS-485 bus ports (REVIEW_BLOCKER: old C150877 wrong; lock exact MPN consistent with backplane before fab) |
| SW_RST, SW_BOOT | Tactile 6×6 SMD 160 gf | C318884 | SMD | 2 | — |
| D_HB | LED blue 0603 | C72041 | 0603 | 1 | HEARTBEAT |
| D_ACT1..4 | LED green 0603 | C72043 | 0603 | 4 | BUS_ACT |
| L_CM1..4 | CM choke 744232601 | CHECK | SMD | 4 | RS-485 pair (REVIEW_BLOCKER: old C191126 wrong) |
| TVS_B1..4 | SM712-02HTG | C169123 | SOT-23 | 4 | RS-485 transient |
| R_TERM1..4 | 120 Ω 1 % 0805 | C22787 | 0805 | 4 | Termination |
| R_BIAS_H1..4 | 1 kΩ 1 % 0603 | C21190 | 0603 | 4 | Fail-safe bias high (revised 2026-04-25 from 390 Ω) |
| R_BIAS_L1..4 | 1 kΩ 1 % 0603 | C21190 | 0603 | 4 | Fail-safe bias low (revised 2026-04-25 from 390 Ω) |
| R_I2C_SDA, R_I2C_SCL | 4.7 kΩ 0402 | C25900 | 0402 | 2 | I²C pull-ups |
| R_ALERT_OR, R_FAULT_OR | 10 kΩ 0402 | C25744 | 0402 | 2 | Wired-OR pull-ups (digital-owned) |
| R_MAX_IRQ, R_MAX_RST | 10 kΩ 0402 | C25744 | 0402 | 2 | MAX14830 IRQ PU, /RESET PU |
| R_CS_PU | 10 kΩ 0402 | C25744 | 0402 | 1 | SPI CS idle-high |
| R_BOOT_PU, R_EN_PU | 10 kΩ 0402 | C25744 | 0402 | 2 | IO0 + EN pull-ups |
| R_CC1, R_CC2 | 5.1 kΩ 1 % 0402 | C127584 | 0402 | 2 | USB-C UFP |
| R_HB, R_ACT1..4 | 1 kΩ 0402 | C11702 | 0402 | 5 | LED series |
| R_SPARE1..7 | 10 kΩ 0402 | C25744 | 0402 | 7 | Spare-GPIO pull-ups |
| FB_VBUS | BLM18PG600SN1 ferrite | C1017 | 0603 | 1 | USB VBUS bead |
| C_VBUS | 4.7 µF 10 V X5R 0603 | C19666 | 0603 | 1 | USB VBUS bulk |
| C_BULK_S3 | 22 µF 10 V X5R 0805 | C45783 | 0805 | 1 | ESP32 bulk |
| C_BULK_S3b | 10 µF 10 V X5R 0805 | C15850 | 0805 | 1 | ESP32 bulk |
| C_DEC_* | 100 nF 25 V X7R 0402 | C1525 | 0402 | ~20 | Per-VDD decoupling across all ICs |
| C_XTAL1..2 | 30 pF C0G 0402 (assumes 18 pF C_L crystal) | check | 0402 | 2 | MAX14830 XTAL load — verify against crystal C_L spec |
| C_VEXT_MAX | 100 nF 25V X7R 0402 | C1525 | 0402 | 1 | MAX14830 VEXT decoupling (added 2026-04-25) |
| C_DEB_EN, C_DEB_BOOT | 100 nF 0402 | C1525 | 0402 | 2 | EN + BOOT debounce |
| C_EN_RC | 1 nF 0402 | C1614 | 0402 | 1 | EN RC filter |

Quantities are minimums; layout pass may add redundant decoupling. LCSC part numbers are for guidance — confirm JLC stock + basic/extended at fab-submit time.

---

# Section 4 — MECHANICAL_DESIGN.md

# Master PCB v2 — Mechanical / Placement Brief

> **Scope:** board dimensions, layer count, stack-up, placement zones, edge-connector layout, antenna keep-out, mounting holes, copper-pour strategy, differential-pair rules, silkscreen requirements. This is a **placement brief** for a layout engineer (JLCPCB EasyEDA service or a freelancer), not a finished layout.
>
> **Binding references (only):** `MASTER_DECISIONS.md`, `POWER_DESIGN.md`, `DIGITAL_DESIGN.md`. Last edited 2026-04-25 (post-review revisions; see issue #76).

---

## 1. Proposed board dimensions + layer count

**Headline: 130 mm × 100 mm, 4-layer, 1.6 mm FR-4, ENIG, 1 oz outer / 0.5 oz inner.**

### Area math (component footprint budget)

| Block | Approx footprint (mm²) |
|---|---|
| 4× RJ45 shielded THT (16 × 21 mm each) | 1344 |
| ESP32-S3-WROOM-1 module (18 × 25.5) | 459 |
| Per-bus cluster overhead × 4 (shunt + eFuse + INA237 + SN65HVD75 + CMC + TVS + passives, ~200 mm² ea.) | 800 |
| Input power zone (jack + TVS + LM74700 + Q1 + secondary clamp + buck IC + inductor + bulk caps + MLCCs) | 700 |
| MAX14830 + crystal + load caps + decoupling | 120 |
| USB-C receptacle + ESD + ferrite + bulk | 150 |
| SWD header + debounce RCs | 60 |
| Buttons (2× 6×6) | 72 |
| LEDs (8×) + series resistors | 40 |
| Misc decoupling / pull-up / wire-OR passives (~60× 0402/0603) | 250 |
| **Component footprint subtotal** | **~4000** |
| + 30 % routing overhead for inner/outer signal layers | +1200 |
| + courtyard, keep-out, zone-isolation clearance (1.8× practical layout factor) | ×1.8 |
| **Required board area** | **~9400 mm²** |

9400 mm² ≈ 97 × 97 mm minimum. **The four RJ45 jacks on one edge are the dominant horizontal constraint**: 4 × 16.5 mm (body+pitch) + 2× 5 mm edge margin ≈ **76 mm edge minimum** just for the jack row. The per-bus signal chain (shunt → eFuse → INA237 → SN65HVD75 → CMC → TVS → RJ45) needs ~30 mm depth perpendicular to that edge. Add the ESP32-S3 + MAX14830 + power input zone on the opposite half and ~130 × 100 mm falls out naturally with comfortable routing channels.

**Dimensions: 130 mm × 100 mm (13,000 mm²)** — 38 % headroom over the minimum, which covers antenna keep-out (which removes ~350 mm² of usable area), mounting-hole exclusion rings, and sane zone separation. Fits on JLC's "≤ 150 × 150 mm" cheapest tier.

### Layer count: 4

2-layer is infeasible here. Specifically:
- **SMPS + antenna + RS-485 diff pairs + 48 V power + sensitive INA237 Kelvin sensing on one board** demands a continuous uninterrupted GND reference plane. Achievable only with a dedicated GND layer.
- **4× RS-485 A/B differential pairs** need controlled 120 Ω differential impedance routed over a solid reference plane. On 2-layer the reference is swiss-cheesed by the bottom-side traces; impedance control becomes a fiction.
- **USB 2.0 D± (90 Ω differential)** has the same reference-plane requirement.
- **V48 distribution** (up to 6.8 A worst case, 4×1.7 A fault) wants a dedicated power-plane slab or wide poured island; not easy to share a single bottom layer with GND return.
- **LMR36015 switch-node + 2.1 MHz edges** need tight input-loop + GND-return geometry; can't be done cleanly on 2-layer.

4-layer is a ~€30 uplift per board at JLC 5-board prototype tier. Accepted.

6-layer is not justified — no dense BGA (S3 is on a module, MAX14830 is TQFN-32, eFuses are DSBGA-10 but only 10 balls), no high-speed signaling beyond USB 2.0 full-speed.

---

## 2. Stack-up (4-layer, 1.6 mm)

| Layer | Name | Cu wt | Thickness | Purpose |
|---|---|---|---|---|
| L1 | TOP signal | 1 oz (35 µm) | — | All SMD components. Most signal routing. Power-zone top pours (V48, 3V3 islands). |
| — | Prepreg | — | ~0.2 mm | — |
| L2 | GND | 0.5 oz (17 µm) | — | **Solid uninterrupted GND reference.** One and only one split — only to isolate 48 V TVS return if the surge-path analysis (POWER_DESIGN §3a) dictates. Default: no split. |
| — | Core | — | ~1.1 mm | — |
| L3 | PWR (mixed) | 0.5 oz | — | V48 poured island under power zone; 3V3 poured island under MCU/MAX/INA237/SN65HVD75 zone; remainder GND pour stitched to L2 with ≥1 via / cm². |
| — | Prepreg | — | ~0.2 mm | — |
| L4 | BOTTOM signal | 1 oz (35 µm) | — | Short cross-unders only (BGA escape for TPS259827 DSBGA-10, MAX14830 TQFN-32 fan-out, diff-pair crossings). Most of the bottom is GND pour with stitching vias. |

**Why 0.5 oz inner / 1 oz outer:** JLC's standard 4-layer 1.6 mm stack-up; cheapest option. 1 oz outer is required for the V48 current path on TOP (up to 6.8 A) and the buck switch node.

**V48 distribution rule (locked 2026-04-25):** V48 fan-out lives **on L1 (top, 1 oz) only**. L3 inner pour is signal/GND only — no V48 island. Reason: 0.5 oz inner copper carrying 1.7 A per branch under fault leaves only ~10 °C rise margin, which is borderline once layout-dependent voltage drops accumulate. Keeping V48 on L1 sidesteps the inner-layer thermal question entirely.

**Target impedances** (controlled by the layout engineer against JLC's stack-up calculator, tuned at tape-out):
- **100 Ω differential** (single-ended 50 Ω) for USB D± on L1 over L2 GND: approx. 0.22 mm trace / 0.15 mm gap, to be confirmed against JLC's impedance calculator for the exact dielectric chosen.
- **120 Ω differential** for RS-485 A/B on L1 over L2 GND: approx. 0.2 mm trace / 0.3 mm gap, tight pair, to be confirmed.

Surface finish: **ENIG** (gold). Required because DSBGA-10 (TPS259827) soldering is unreliable on HASL — the pads are too small for HASL's thickness variation. ENIG adds ~€5 per 5-board order; worth it.

---

## 3. Floorplan sketch (ASCII, top view)

```
                  ┌─ 100 mm ─┐
   ┌──────────────────────────────────────────────────────────┐  ─┐
   │ J1_DC   [TVS][2ndclamp]  [LM74700][Q1]  [BULK 47µF×2]    │   │
   │ (barrel)                                                  │   │
   │                       [LMR36015][L1][C_OUT]   [MCU-3V3]   │   │
   │  MH1●                                                 MH2●│   │  power / left edge
   │                                                           │   │
   │    ┌─────────────────┐      ┌──────────────────────────┐  │   │
   │    │  ESP32-S3       │      │    MAX14830 + XTAL       │  │   │
   │    │  (antenna KO    │      │                          │  │   │
   │    │   faces ←)      │      │    [BUS_ACT 1 2 3 4]     │  │   │
   │    │                 │      └──────────────────────────┘  │   │  130 mm
   │    │  decap, bulk    │       ↕ SPI                        │   │
   │    └─────────────────┘                                    │   │
   │    [HB LED][PWR_48V][PWR_3V3][FAULT]    [INA237×4 row]    │   │
   │                                                           │   │
   │    [BOOT][RST]       [SWD 2x5]      [USB-C J_USB]          │   │
   │                                                           │   │
   │  MH3●                                                 MH4●│   │
   │                                                           │   │
   │  BUS1     │  BUS2     │  BUS3     │  BUS4                 │   │
   │ [SHUNT]   │ [SHUNT]   │ [SHUNT]   │ [SHUNT]               │   │
   │ [eFuse]   │ [eFuse]   │ [eFuse]   │ [eFuse]               │   │
   │ [INA src] │ [INA src] │ [INA src] │ [INA src]             │   │
   │ [HVD75]   │ [HVD75]   │ [HVD75]   │ [HVD75]               │   │
   │ [CMC+TVS] │ [CMC+TVS] │ [CMC+TVS] │ [CMC+TVS]             │   │
   │ ┌──────┐  │ ┌──────┐  │ ┌──────┐  │ ┌──────┐              │   │
   │ │ RJ45 │  │ │ RJ45 │  │ │ RJ45 │  │ │ RJ45 │              │   │
   │ │  #1  │  │ │  #2  │  │ │  #3  │  │ │  #4  │              │   │
   │ └──┬───┘  │ └──┬───┘  │ └──┬───┘  │ └──┬───┘              │   │
   └────┴──────┴────┴──────┴────┴──────┴────┴──────────────────┘  ─┘
        ▲ front edge: 4× RJ45, cable-exit direction
```

**Edge assignments**
- **Front (bottom in sketch, long edge, 130 mm):** 4× RJ45 in a row. This is the user-facing edge when the unit is rack-mounted or wall-hung; bus cables exit here.
- **Left edge (short, 100 mm):** barrel DC jack. Power cable exits opposite to bus cables so they don't tangle.
- **Right edge (short, 100 mm):** USB-C receptacle. Service port; flush with enclosure edge for easy plug access.
- **Top edge:** no connectors. Hosts the ESP32-S3 module with antenna keep-out extending off-board (see §5).
- **Back (inside):** SWD header + buttons + LEDs arranged mid-board for visibility when cover is off; they do not exit an enclosure edge.

---

## 4. Placement zones

### Zone A — Power input (top-left, ~30 × 30 mm = 900 mm²)

**Contents (revised 2026-04-25):** J1 barrel jack, D1 SMDJ58CA TVS, U1 LM74700-Q1 controller, Q1 SQJ148EP N-MOSFET, LM74700 passives (C_CP charge-pump cap, R_GATE_LM 1 kΩ series, R_GATE_BLEED 10 kΩ), **D_RAIL SMAJ51A on V48_RAIL post-Q1 source**. The pre-2026-04-25 RTH1 inrush NTC and D_SEC SMAJ51A secondary clamp on IC V_IN are deleted (#76 audit).

**Zone shrunk** from 40 × 35 mm to 30 × 30 mm — 500 mm² freed up by the surge-chain simplification.

**Placement constraint:** J1 on the left edge. SMDJ58CA **within 5 mm of J1's + pin** (POWER_DESIGN §3a); its GND return is a short dedicated trace straight to the jack shell GND pad — the TVS surge return **must not** flow through the main board GND pour (it will dump 51 A through the reference plane and crash every IC for the surge duration). Q1's drain-source loop area minimised (POWER_DESIGN §3a layout hint).

**Critical adjacency:** LM74700 within 10 mm of Q1 (gate drive integrity). **D_RAIL within 10 mm of Q1's source pad** — clamps surge tail flowing forward through Q1 body diode.

### Zone B — Buck converter (top-center, ~25 × 30 mm = 750 mm²)

**Contents:** U2 LMR36015FDDA, L1 XAL5030-333, C_IN_BUCK (2.2 µF 1210), C_IN48_HF (4.7 µF 1210), C_IN48_BULK (2× 47 µF AL-poly), C_OUT_BUCK (2× 22 µF 0805), C_SS, EN divider, FB divider.

**Placement constraint:** Switch-node trace (SW pin → L1) **< 10 mm** and kept narrow (POWER_DESIGN §3b). Input MLCC within 3 mm of U2 VIN pin, GND return on same layer direct to PGND pin. L1 oriented so its terminals face SW and VOUT nodes (no jogs).

**Critical adjacency:** Bulk AL-poly caps within 15 mm of U2 VIN; MLCC tight loop to PGND.

**Thermal:** U2 thermal pad → ≥ 4× 0.3 mm vias into L2 GND pour; top-side copper pour ≥ 100 mm² around U2 (POWER_DESIGN §6).

### Zone C — Per-bus cluster (bottom half, ×4, each ~25 × 55 mm = 1375 mm²)

**Contents (one per bus):** R_SHUNT (2512 Kelvin), TPS259827 eFuse (DSBGA-10) + I_LIM, dV/dt, EN pull-down, VIN/VOUT decap, INA237 (VSSOP-10) + filter network + VBUS 10:1 divider + VS decap, SN65HVD75D (SOIC-8), 120 Ω termination, 2× 390 Ω bias, CM choke (SMD), SM712 TVS, RJ45 shielded THT.

**Layout spine (top → bottom / inside → board-edge):**
V48 bus → shunt → eFuse → INA237 sensing → (eFuse VOUT continues as per-bus +48 V going out to RJ45 pins 4/5). RS-485 A/B path runs in parallel: MAX14830 per-channel → SN65HVD75D → CM choke → SM712 TVS → RJ45 pins 3/6. Termination (120 Ω) + bias (2× 390 Ω) at the transceiver end of the choke, between the SN65HVD75D and the CM choke.

**Placement constraint:** **One bus cluster = one column**. Four columns, pitch ~25 mm, align with the four RJ45 footprints on the front edge. Cluster width constrained by RJ45 pitch. No cross-bus signal sharing above the MAX14830 (see §8 diff-pair rules).

**Critical adjacency:**
- R_SHUNT Kelvin taps **matched-length, tight-pair** to INA237 IN+/IN− (POWER_DESIGN §3d).
- SN65HVD75D **within 15 mm** of RJ45 so A/B trace length from transceiver to connector is minimal and well-referenced to GND.
- SM712 TVS **within 5 mm** of RJ45 data pins.
- CM choke between SM712 and RJ45 (TVS clamps before the bus leaves the board).
- RJ45 shield tied **solid** to GND through its mounting tabs (DIGITAL_DESIGN §3f).

**Thermal:** Each eFuse (DSBGA-10) needs a 2×2 thermal-via array under the package (POWER_DESIGN §6). Each shunt (2512) copper minimized beyond the Kelvin taps so IR voltage is measured, not diluted.

### Zone D — MCU (top-center-left, ~40 × 35 mm = 1400 mm²)

**Contents:** ESP32-S3-WROOM-1 module, EN pull-up + RC, BOOT pull-up + debounce, module decoupling (100 nF per VDD + 10 µF + 22 µF bulk), HEARTBEAT LED + R.

**Placement constraint:** Module placed so its **antenna end faces an outer edge of the board** — specifically the **top edge** in the floorplan. Module long axis parallel to the 100 mm edge. No traces, no pour, no components inside the antenna keep-out (see §5). Decoupling caps **on top layer** immediately below each VDD pad on the module.

**Critical adjacency:** SPI lines to MAX14830 (~20 mm run). USB-C on the opposite short edge (right) — route D± diff pair as a single pair along the bottom of Zone D (see §8).

### Zone E — Comms hub (right of MCU, ~25 × 25 mm = 625 mm²)

**Contents:** MAX14830ETJ+ (TQFN-32), 3.6864 MHz crystal, 2× 18 pF load caps, /RESET pull-up, IRQ pull-up, 4× BUS_ACT LEDs + series resistors.

**Placement constraint:** Between MCU (zone D) and the per-bus-cluster row (zone C), so SPI goes east from MCU to hub, and 4× (TX, RX, DE) go south from hub to the four SN65HVD75D transceivers with minimal crossings. Crystal **within 3 mm** of XTAL1/XTAL2 pins; 18 pF caps symmetrical on either side; GND island under crystal tied to MAX14830 GND pin via short trace (not through plane stitching).

**BUS_ACT LEDs** placed along the bottom edge of zone E so they sit roughly above the 4 RJ45 jacks — visually they line up with the bus they indicate.

### Zone F — USB (right edge, ~20 × 25 mm = 500 mm²)

**Contents:** USB-C 16-pin SMD receptacle, USBLC6-2SC6 ESD clamp, 2× 5.1 kΩ CC pull-downs, ferrite bead, 4.7 µF VBUS bulk, shield-bond 0 Ω, hybrid DNP.

**Placement constraint:** Receptacle on the right short edge, flush with board outline. ESD clamp **within 3 mm** of D± pins (before any other component). D± diff pair runs from receptacle west to MCU IO19/IO20 — kept on top layer over solid GND, length matched, <25 mm total (well under USB 2.0 limits).

**Critical adjacency:** VBUS ferrite + cap **within 5 mm** of receptacle VBUS pin. CC pulldowns within 2 mm of CC1/CC2 pins.

### Zone G — Debug (mid-board, ~20 × 15 mm = 300 mm²)

**Contents:** SWD 2×5 1.27 mm header, optional 0 Ω nRESET (DNP), optional 33 Ω series TCK/TDO (DNP), BOOT button, RST button, their debounce caps.

**Placement constraint:** SWD and buttons together, mid-board, accessible with an enclosure cover removed. Not on an edge — they don't exit the enclosure. Button tops 6×6 mm — allow 10 mm clearance in front of each for finger actuation.

### Zone H — LED indicators (mid-board, above RJ45 row, ~30 × 5 mm strip)

**Contents:** PWR_48V (red), PWR_3V3 (green), FAULT (red), HEARTBEAT (blue) in a row. BUS_ACT 1..4 are in zone E above their respective buses.

**Placement constraint:** Row visible through the enclosure cover opening or by pointing the board "label side up" on a bench. Aligned horizontally with silkscreen labels below each LED.

---

## 5. Antenna keep-out

ESP32-S3-WROOM-1's onboard PCB antenna is on the **short end** of the module. Per Espressif's **ESP32-S3-WROOM-1 Hardware Design Guidelines**, the keep-out area must be:

- **Minimum 15 mm × 15 mm** free of copper on **all layers** extending **outward from the antenna end of the module**, with no components, no traces, no via, no pour, no mounting hardware, and no metal enclosure within this volume.
- Espressif recommends the module be placed so the antenna end **protrudes beyond the PCB edge** (module overhangs), or if not possible, the keep-out lives on-PCB.

**Placement decision:** ESP32-S3 module placed in zone D with its antenna end facing the **top edge** of the board. The module footprint sits ~6 mm in from the top edge; the antenna end of the module extends the last ~6 mm toward the top edge. **Keep-out zone: 18 mm (width of module) × 15 mm, on all 4 layers, starting at the antenna end of the module and extending to the top board edge.** This 15 mm zone sits partially on-board (~9 mm) and partially off-board (~6 mm, since we do not overhang — an overhang is fragile). The 9 mm on-board portion is fully copper-free on all layers; no mounting hole, no silkscreen text inside this area (silkscreen is fine but no solder-mask openings or tented vias).

**Cost of keep-out:** ~160 mm² lost to the area budget, already factored into the 130 × 100 dimensioning.

**Mechanical agent flag:** if the enclosure is metal, the metal wall adjacent to the antenna must be **≥ 15 mm away** from the antenna end of the module, or RF performance degrades sharply. See §10.

---

## 6. Mounting holes

- **Count: 4** — one per corner.
- **Diameter: 3.2 mm plated through-hole (M3 clearance).**
- **Annular pad: 6.5 mm OD, unconnected** (isolated island of copper on TOP and BOTTOM that does not connect to the GND pour). Avoids ground-loop issues when the board is bolted to a metal chassis. If chassis-bonding is desired, populate a 0 Ω from the pad to GND on a single corner (the "star-ground" corner) at assembly — leave a DNP pad pattern on all 4.
- **Position (revised 2026-04-25, measured from bottom-left corner of the 130 × 100 board):**
  - MH1: (6, 94)  — top-left
  - MH2: (124, 94) — top-right
  - MH3: (6, 22)   — bottom-left (moved inboard from y=5 to clear the 21 mm RJ45 keep-out)
  - MH4: (124, 22) — bottom-right (same)
- **Exclusion ring: 2 mm** around each hole (no traces, no components). The plated pad itself is 6.5 mm, so the exclusion zone is effectively 8.5 mm diameter. Corner positions give ≥2 mm board-edge clearance on the exclusion rings (was 0.75 mm pre-2026-04-25).
- **No 5th center hole** — the 130 × 100 board is stiff enough at 1.6 mm FR-4 without mid-span support, and there's no heavy THT component mid-board to torque a corner.

---

## 7. Copper-pour strategy

### L1 (TOP)
- **GND pour** in all unused space, stitched to L2 GND with ≥ 1 via / cm².
- **V48 islands** on TOP under zone A → zone B, then branching to four shunt inputs in the per-bus columns (zone C). Width per branch ≥ 2 mm (for 2 A continuous at 1 oz copper, 10 °C rise — standard IPC-2221 table).
- **3V3 island** on TOP under zones D / E plus the INA237 row; not continuous to per-bus transceivers (those get 3V3 via short traces).

### L2 (GND — solid)
- **One uninterrupted plane.** This is the reference for all diff pairs (RS-485 and USB), the MCU decoupling return, the switch-node return for the buck, and the INA237 Kelvin sensing return.
- **No splits** under the diff pair routes — ever.
- **Single conditional split**: TVS surge-return island (a cutout isolating the SMDJ58CA anode pad's return path and tying it directly to the barrel jack's GND shell pin via a dedicated ≥3 mm-wide trace on L1). Only implement this if the layout engineer's surge-path analysis shows the main plane is otherwise impacted. Default: no split; just a direct L1 trace for TVS return, with L2 untouched.

### L3 (PWR — signal/GND only, no V48 pour) — revised 2026-04-25
- **No V48 island on L3.** V48 distribution is L1 only (1 oz top) per stack-up note in §2.
- **3V3 poured slab** under zones D (MCU) and E (MAX14830) and the INA237 row. Connected to L1 3V3 islands with ≥ 1 via / cm².
- **Remainder: GND pour**, stitched to L2 GND via ≥ 1 via / cm² across the whole layer. This gives a second effective GND reference and reduces impedance of the return path for high-frequency signals.

### L4 (BOTTOM)
- **GND pour everywhere** except short cross-under signal segments.
- Stitched to L2 GND with dense via pattern (≥ 2 vias / cm² near high-frequency zones: buck switch node, MCU, MAX14830, USB D±, RS-485 A/B segments).

### Hot-IC thermal pour callouts

| Part | Top-side thermal pour | Thermal vias | Inner-layer connection |
|---|---|---|---|
| U2 LMR36015FDDA | ≥ 100 mm² copper under + around exposed pad | 4× 0.3 mm drill under pad | L2 GND + L4 GND |
| Q1 SQJ148EP (PowerPAK SO-8) | ≥ 100 mm² on drain pad | 4× 0.3 mm under pad | L3 drain island (NOT GND — Q1 drain is a net, pour is for heat spreading on that net) |
| U3..U6 TPS259827 eFuse × 4 | modest pour under package | 2×2 array of 0.3 mm thermal vias per pkg | L2 GND + L4 GND |
| R_SH1..4 shunts (2512) | **minimal pour** — just Kelvin pads | none | N/A (minimize IR loss in the sense path) |
| SMDJ58CA | ≥ 30 mm² pour on cathode pad | 2× 0.3 mm | L2 GND |

### High-voltage clearance rules (V48 nets)

- V48-nominal is 48 V; under surge, up to 93 V momentarily (before the secondary clamp); downstream of the secondary clamp, ≤ 65 V. All nets downstream of the secondary clamp: **≥ 0.2 mm (8 mil) clearance** to signal nets. Upstream of the secondary clamp (TVS node to LM74700 VIN): **≥ 0.4 mm (16 mil) clearance**, IPC-2221 internal-conductor Class 1 for ≤ 100 V.
- No V48 routing under the ESP32-S3 module or its antenna keep-out.
- V48 and GND net clearance on L1 and L3 under the per-bus columns: **≥ 0.3 mm** (headroom).

---

## 8. Critical differential-pair routing rules

### RS-485 A/B (×4 pairs, one per bus)

- **Impedance target: 120 Ω differential.** Tune trace width and intra-pair gap against JLC's stack-up calculator at tape-out (approx 0.2 mm / 0.3 mm for the proposed stack-up; layout engineer confirms).
- **Reference plane: L2 GND, uninterrupted** along the entire path from SN65HVD75D A/B pins → termination + bias network → CM choke → SM712 TVS → RJ45.
- **Length: < 30 mm per pair** (SN65HVD75D is placed within 15 mm of RJ45 per §4 zone C; 30 mm includes the routing through CM choke and TVS).
- **Intra-pair skew: < 1 mm.** RS-485 is half-duplex 3.3 V; bit rate ≤ 1 Mbps in this system, so skew tolerance is generous, but keep it tight to preserve common-mode rejection.
- **Inter-pair spacing: ≥ 3× trace width between adjacent bus pairs.** Four buses in parallel columns are already separated by ~25 mm cluster pitch — ample.
- **No stubs.** Termination (120 Ω) placed directly across A/B at the transceiver side of the CM choke. Fail-safe bias (2× 390 Ω) placed at the same node.
- **Route on L1.** Do not use L4 for diff pairs — L4 is short cross-unders only.

### USB 2.0 D± (single pair)

- **Impedance target: 90 Ω differential** (USB 2.0 spec; single-ended 45 Ω).
- **Reference plane: L2 GND, uninterrupted** from USB-C receptacle → USBLC6-2SC6 → ESP32-S3 IO19/IO20.
- **Length: < 25 mm.**
- **Intra-pair skew: < 0.5 mm.**
- **No vias on the D± pair.** Route entirely on L1 from receptacle to ESD to module.
- **Spacing to other signals: ≥ 3× diff-pair gap (~0.9 mm).** USB D± has no noisy neighbors in this layout since USB is on the right edge and the buck switch node is far away on the top-center.

### Kelvin sense pairs (R_SHUNT → INA237, ×4)

- Matched length within 1 mm.
- Tight pair (intra-pair gap ≤ trace width).
- Route on L1, referenced to L2 GND.
- Do not share reference plane with the buck switch-node area (< 5 mV noise target on the sense line; the INA237 LSB option at 1 mA × 50 mΩ = 50 µV, so plane noise matters).

---

## 9. Silkscreen requirements

**Must-have labels (top side):**

- **RJ45 ports:** `BUS 1`, `BUS 2`, `BUS 3`, `BUS 4` above each jack.
- **RJ45 pin-1 indicator (M6 closed 2026-04-25):** silkscreen `1` next to pin-1 of each RJ45, on the same side of all 4 jacks (e.g. all pin-1 on the left when viewed from the cable-entry face).
- **RJ45 pinout note:** `48V: pin 4/5 (blue) | RS485 A/B: pin 3/6 (green) | GND: pin 7/8 (brown) | T568B STRAIGHT-THROUGH ONLY` — compact text on the silkscreen inside the per-bus column or as a legend block near the jacks. Rationale: MASTER_DECISIONS lock-in is Mode B + T568B (so RS-485 A/B sit on a true twisted pair). A T568A or crossover cable will mis-pair the differential.
- **Barrel jack:** `48V DC` and a `⊕—●—⊖` polarity symbol (center-positive). Also: `60 V MAX` below for over-voltage warning.
- **USB-C:** `USB-C` + small `Service / flash` subtitle.
- **SWD header:** `SWD` + pin-1 triangle marker. Pinout reference card printed near (too dense for the header footprint itself, include on a nearby silkscreen patch).
- **Buttons:** `BOOT` and `RST` labels next to each button.
- **LEDs:** individual labels `48V`, `3V3`, `FAULT`, `HB` (HEARTBEAT), `BUS1`..`BUS4` (activity).
- **Fiducials:** 3× 1 mm copper fiducials (diagonal corners + asymmetric third) for JLC PCBA pick-and-place.
- **Board title block:** top-right corner — `SPLIT-FLAP MASTER v2 REV A`, git SHA placeholder `{{GIT_SHA}}`, date placeholder `{{DATE}}`. **Substitute placeholders at gerber-export time** (CI / KiBot pipeline does this automatically; manual export must do it manually). Documented in fab-handoff checklist.
- **Orientation marker:** `↑ ANTENNA` arrow at the top edge above the ESP32-S3 keep-out, plus `DO NOT ENCLOSE IN METAL WITHIN 15mm` micro-text.
- **Mounting-hole markings:** `M3` next to each corner hole.
- **48 V SELV note:** small text near the barrel jack: `48V SELV — touch-safe; no chassis bond required`.

**Bottom-side silkscreen:** minimal — just a git-SHA re-print and `MADE WITH JLCPCB` credit (optional).

---

## 10. Open issues

- ~~**M3**~~ **Closed 2026-04-25.** Enclosure: designed-to-fit project-box class (Hammond 1455N family or similar). Plastic cover, no chassis bond required (48 V SELV). 4-corner M3 mounting pattern.

- **M4 — Board thickness.** Proposed 1.6 mm (JLC standard, cheapest). 2.0 mm would add stiffness under the 4× RJ45 insertion forces but costs more. Acceptable at 1.6 mm given the 4-corner mounting and the RJ45 jacks' THT leads anchored through the board.

- ~~**M5**~~ **Closed 2026-04-25.** RJ45 shield: solid bond to GND at master only. Backplane and unit shields float. Single bond point eliminates ground-loop hunting across 32 parallel RC paths.

- ~~**M6**~~ **Closed 2026-04-25.** Pin-1 indicator promoted to silkscreen must-have (§9). All 4 jacks have pin-1 on the same side.

- **M7 — Test points.** Layout engineer to sprinkle 1 mm test pads for: each PGOOD (×4), each eFuse VOUT, 3V3, V48, GND (multiple), PROT_FAULT_OR, TELEM_ALERT_OR, SPI CS/MOSI/MISO/SCK. Non-blocking.

- **M8 — Fiducial count and location.** Three fiducials (diagonal corners + one asymmetric) are the JLC PCBA minimum. Layout engineer to place.

- ~~**M9**~~ **Closed 2026-04-25.** Surge-clamp chain simplified: only `D_RAIL` (SMAJ51A) on V48_RAIL within 10 mm of Q1's source pad. R_SERIES + D_SEC chain is deleted (#76 audit).

- **M10 — Overhanging the ESP32-S3 antenna.** Espressif prefers the module overhanging the PCB edge for best RF. Here we do **not** overhang (fragile, ships break during transport). User may override if an injection-moulded enclosure with antenna pocket is used.

---

## 11. Fab-handoff summary (for paste-into-email)

> Master PCB v2 for a split-flap display controller. **130 × 100 mm, 4-layer, 1.6 mm FR-4, ENIG finish, 1 oz outer / 0.5 oz inner.** Stack-up: TOP signal (V48 distribution lives on L1 only — 1 oz copper) / GND solid / PWR (3V3 island + GND, no V48) / BOTTOM signal-plus-GND-pour. Four RJ45 shielded THT jacks on one long edge form the bus-output face; barrel DC jack on one short edge, USB-C on the opposite short edge, SWD + buttons + LEDs mid-board. ESP32-S3-WROOM-1 module is placed with its antenna end at the top edge, requiring an 18 × 15 mm copper-free, component-free, via-free keep-out zone extending to the board edge on all 4 layers. Four M3 mounting holes at corners (6,94)/(124,94)/(6,22)/(124,22), 3.2 mm plated, isolated pads. V48 nets require ≥ 0.2 mm clearance to signal. RS-485 A/B pairs routed as 120 Ω differential over solid L2 GND, USB D± as 90 Ω differential. Per-bus clusters (shunt → eFuse → INA237 → SN65HVD75 → CM choke → TVS → RJ45) are arranged as four parallel columns aligned to the RJ45 footprints. Surge protection: SMDJ58CA at the barrel jack, ideal-diode LM74700-Q1 + Q1 SQJ148EP, single SMAJ51A on V48_RAIL post-Q1 within 10 mm of Q1 source. Thermal vias specified under LMR36015, SQJ148EP, and each TPS259827 eFuse. Silkscreen must call out bus numbering, RJ45 pinout (T568B Mode B: 48 V on pin 4/5, RS-485 A/B on pin 3/6, GND on pin 7/8), pin-1 indicator on every RJ45, "T568B STRAIGHT-THROUGH ONLY" cable warning, LED labels, antenna keep-out warning, 48V SELV note. Electrical design is frozen in `POWER_DESIGN.md` and `DIGITAL_DESIGN.md`; do not substitute parts or change topology. All previously-open issues except M4, M7, M8, M10 are now closed (2026-04-25).

---

# Section 5 — MASTER_BRINGUP.md

# Master PCB v2 — Bring-up procedure

> First-power sequence + per-test-point readings + JLC PCBA verification. Created 2026-04-25.

## Pre-power inspection

1. Visual: verify barrel-jack polarity silkscreen matches your PSU (center-positive).
2. Visual: confirm the antenna keep-out zone is genuinely copper-free on all 4 layers (use the JLC fab-output PDF).
3. Verify all 4 RJ45 shielded jacks are populated and shield tabs are soldered.
4. Verify the BSS138 / MMBT3906 FAULT LED transistor is populated (P4 fix).
5. Verify D_RAIL (SMAJ51A) is within 10 mm of Q1's source pad.
6. Check that R_SERIES + D_SEC are NOT present (they were deleted in #76 — if your fab board has them, you have a stale gerber).

## Step 1 — 3V3 standalone (no 48 V)

Disconnect 48 V. Apply 3.3 V externally to the SWD pin 1 (VTref).

Expected at test pads:
- 3V3 rail: 3.30 V ± 50 mV
- All 4 EFUSE_EN_n pins: 0 V (POR-gated low through BAT54)
- PROT_FAULT_OR: 3.30 V (idle high via 10 kΩ pull-up)
- TELEM_ALERT_OR: 3.30 V (idle high)
- ESP32-S3 VDD pads: 3.30 V

Healthy outcome:
- PWR_3V3 LED on.
- PWR_48V LED off (no 48 V applied).
- FAULT LED off (PROT_FAULT_OR is high; MMBT3906 is off).
- HEARTBEAT LED off (firmware not running yet).

If any deviation, **do not proceed to step 2**.

## Step 2 — 48 V applied, no firmware

Apply 48 V from the recommended PSU through the barrel jack.

Expected:
- LM74700 conducts; V48_RAIL ≈ 47.5 V (drop across Q1 R_DS(on) is negligible at no-load).
- LMR36015 buck wakes (EN divider crosses 1.2 V at ~15 V V48); 3V3 rail still 3.30 V (now self-powered).
- ESP32-S3 boots (will likely sit in download mode if no firmware flashed).
- All 4 eFuses remain disabled (EFUSE_EN_n still low — firmware controls them).
- D_RAIL idle reverse-biased.

Test-pad readings:
- TP_V48: 47.5 V ± 0.5 V
- TP_3V3: 3.30 V ± 30 mV
- TP_PROT_FAULT_OR: 3.30 V (idle high)
- TP_TELEM_ALERT_OR: 3.30 V

Surge / fault behavior to verify on bench (optional, with a bench-DPS):
- Apply 60 V briefly: D_RAIL clamps at ~57 V tail current; LM74700's OVP turns Q1 off.
- Apply reverse polarity (−48 V): LM74700 detects, Q1 stays off, no current draw.

## Step 3 — Flash firmware via USB-C CDC

Plug USB-C from host. ESP32-S3 enumerates as a CDC + JTAG class device. Flash the master firmware via the standard `pio run -t upload` (PlatformIO) or `idf.py flash` workflow.

Verify in firmware boot log:
- HEARTBEAT LED transitions from off to 2 Hz fast (booting) to 1 Hz steady (running + WiFi up) or 0.5 Hz slow (running + WiFi down/AP mode).

## Step 4 — Per-bus enable + INA237 telemetry

Firmware sequences each bus enable in turn:
1. Set EFUSE_EN_n high.
2. Wait for PGOOD_n to assert (TPS259827 indicator — exposed as a test pad).
3. Read INA237_n V_BUS reading. Should be ~47.5 V (rail) at the eFuse output.
4. Read INA237_n current. Should be < 50 mA with no cable plugged in.
5. If INRUSH_NOT_SETTLED (INA237 still > 200 mA after 50 ms), declare bus-fault and disable the eFuse — log to firmware error queue.

Connect a single CAT6 patch cable to bus 1 with a CAT6-to-bare-wires terminator at the far end (just A/B + GND). Verify SN65HVD75_1 idle differential ≈ 280 mV (failsafe bias).

## Step 5 — System-level: master + first case

With a populated case backplane (1 segment + 1 unit slot, minimum) connected to bus 1:
1. Verify INA237_1 current ramps smoothly (~28 ms rise) on EFUSE_EN_1 assertion — no eFuse hiccup.
2. Verify the unit's status LED enters 2 Hz blink (awaiting address).
3. Master firmware initiates UID-based discovery; unit gets an address and LED transitions to solid (idle).
4. Master sends a test step command; unit moves the stepper a fixed amount.

Pass: unit responds within ~100 ms of master command, no bus errors.

## Common bring-up faults

| Symptom | Likely cause |
|---|---|
| 3V3 not present | C_BOOT cap missing or wrong value — LMR36015 high-side gate driver bricked |
| 3V3 brown-in chatter at low V48 | EN divider wrong; check R_EN_TOP / R_EN_BOT values |
| FAULT LED stuck on at boot | MMBT3906 base resistor missing → BJT default-on |
| eFuse hiccups on enable with bus connected | C_dVdT too small (must be 100 nF, not the pre-2026-04-25 10 nF) |
| INA237 reads scaled wrong (~10× off) | VBUS divider — must be 10 k / 1 k (not pre-2026-04-25 100 k / 10 k) |
| BAT54 conducts with 3V3 healthy | BAT54 polarity reversed (anode must be at /RESET, cathode at EFUSE_EN_n) |
| MAX14830 doesn't enumerate over SPI | VEXT not tied to 3V3, or A0/A1 strap pins wrong (verify SPI-mode handling) |
| ESP32-S3 stuck in download mode after USB-C unplug | IO19/20 strap interaction at boot; verify BOOT button + EN debounce |
